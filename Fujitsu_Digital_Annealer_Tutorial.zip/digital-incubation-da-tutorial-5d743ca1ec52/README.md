Tutorial for Quantum-Inspired Computing
=======================================

This tutorial introduces you to combinatorial optimization problems, how to describe them as a formula and finally solve them,
especially with Fujitsu's Digital Annealer.

It is based on the software development kit `dadk`. This is a python library that contains classes for creation and manipulation
of binary polynomials, access to Digital Annealer services, an emulation of the Digital Annealer annealing algorithm and a framework
for structured Jupyter notebooks for solving optimization tasks.

Prerequisites
-------------

Python 3, recommended is Python 3.9.

Recommended installation is using Anaconda. Go to the Anaconda page

```url
https://www.anaconda.com/products/individual
```

and select the installation for your operating system. After installation is completed, try to start an Anaconda prompt.
On Windows you have an entry in the start menu in the Anaconda folder.

Library installation
--------------------

IMPORTANT: Please make sure to use conda's default channels for installing packages! If you have different channels or a different order of them in your `.condarc`, please add `--channel defaults` to the commands below.  

Creating a dedicated environment for testing new software is a common practice. Please open the Anaconda prompt from the start menu. In the Anaconda prompt type the following commands to create a new Python 3.9 environment:

```bash
conda create --name dadk-39 --yes python=3.9 
conda activate dadk-39
conda install jupyter --yes
conda install numba --yes
```

The library can be found in the folder `Software`, and is installed using pip. So please navigate to the tutorial folder in our prompt.

For Python 3.9 please install (or update) `dadk` with the following command:

```bash
pip install -U Software\dadk_light_3.9.tar.bz2
```

Then please enable the following Jupyter extensions:

You can also use the `dadk` versions for Python 3.8 or 3.10. You'll find them in the folder `Software`, too.

In the already open Anaconda prompt you can start now the jupyter notebook with the following command:

```bash
jupyter notebook
```

**Hints:**

* MacOS (ARM) not working at the moment. Planned for next version.
* Python 3.11 is not supported right now. Planned for next version.
* If you are experiencing errors in the rendering of Markdown, then you may be suffering from the following but: `https://github.com/jupyter/notebook/issues/7002`. In this case, please install a lower version of `Jupyter notebook`, e.g. version 6.

Getting started
---------------

Navigate with your webbrowser to the `Tutorial` folder and open `Introduction.ipynb`. There you find more information about the tutorial
and how to use it. Assuming the notebook service is running under localhost:8888 on you PC and you have extracted the `Tutorial` folder
directly into the notebook root folder, then go to the following link:

```url
http://localhost:8888/tree/[Your_Path]/Tutorial
```

Now you see the content of the `Tutorial` folder in the browser. A click onto `Introduction.ipynb` will open the start page with more information, which is also the first notebook. This gives you information about and links to all further content.

```url
http://localhost:8888/notebooks/[Your_Path]/Tutorial/Introduction.ipynb
```

To read the library documentation open `Tutorial/Development_KIT_Documentation/index.html`. This can be done navigating
the folder structure directly with a web browser or via Jupyter notebook URL.

```url
http://localhost:8888/view/[Your_Path]/Tutorial/Development_KIT_Documentation/index.html
```

Using this way, only Firefox displays the style correctly.

Folder structure
----------------

````text
+-- README.md
+-- Software
|  +-- dadk_light_3.10.tar.bz2
|  +-- dadk_light_3.9.tar.bz2
|  +-- dadk_light_3.8.tar.bz2
|  +-- LICENSE_DADK.txt
+-- Tutorial
   +-- Introduction.ipynb
   +-- LICENSE_DA_TUTORIALS.txt
   +-- Development_KIT_Introduction
   |  +-- ...
   +-- Development_KIT_Miscellaneous
   |  +-- ...
   +-- Digital_Annealer_Examples
   |  +-- ...
   +-- Digital_Annealer_vs_Human
   |  +-- ...
   +-- Optimizer_I
   |  +-- ...
   +-- Optimizer_II
   |  +-- ...
   +--Development_KIT_Documentation
      +-- index.html
      +-- ...
````

Questions or feedback?
----------------------

Thank you very much for your interest in our tutorials. Please, don't hesitate to share your feedback and ideas with us: <digital.incubation@fujitsu.com>.
