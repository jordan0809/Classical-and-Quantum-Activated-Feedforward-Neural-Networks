# general settings
# sizing of map
plan_size_x = 5.0  # size in km
plan_size_y = 15.0  # size in km

from random import seed as rd_seed
import pandas as pd
from dadk.Optimizer import *
from random import random
from .SymmetricModel import *
from .AsymmetricModel import *
from .cars_requests import *

class Darp(OptimizerModelComplex):
    def __init__(self, persistent_file="DARP_ASYMETRIC_NY_0.pps"):
        self.requests = []
        self.cars = []
        self.plan_default()

        OptimizerModelComplex.__init__(self,
                                       name='Dial a Ride',
                                       load_parameter=[
                                           {'name': 'filename',
                                            'value': '',
                                            'type': 'file_selector',
                                            'suffix': 'csv',
                                            'label': 'Data File',
                                            'description': 'Filename of Car csv data',
                                            'tags': ['normal']},
                                           {'name': 'number_cars', 'value': 3, 'type': 'int_slider', 'min': 1, 'max': 12,
                                            'description': 'Number of cars'},
                                           {'name': 'requests_per_car', 'value': 2, 'type': 'int_slider', 'min': 1,
                                            'max': 10, 'description': 'Maximum requests per cars'},
                                           {'name': 'speed', 'value': 36.0, 'type': 'float_slider', 'min': 1.0,
                                            'max': 100.0, 'step': 0.5, 'description': 'Speed of cars [km/h]'},
                                           {'name': 'costs_per_km', 'value': 1.0, 'type': 'float_slider', 'min': 0.0,
                                            'max': 10.0, 'step': 0.01, 'description': 'Costs per distance [$/km]'},
                                           # {'name': 'test_planning', 'value': 'default', 'type': 'select',
                                           # 'options': ['default', 'nearest_car']},
                                           {'name': 'price_per_km', 'value': 2.0, 'type': 'float_slider', 'min': 0.0,
                                            'max': 20.0, 'step': 0.01, 'description': 'Price per distance [$/km]'},
                                           {'name': 'base_price', 'value': 10.0, 'type': 'float_slider', 'min': 0.0,
                                            'max': 50.0, 'step': 0.1, 'description': 'Base price [$]'},
                                           {'name': 'dissatisfaction_costs', 'value': 10.0, 'type': 'float_slider',
                                            'min': 0.0, 'max': 50.0, 'step': 0.1,
                                            'description': 'Maximum dissatifaction costs [$]'},
                                           {'name': 'tolerance_model', 'value': 'no_tolerance', 'type': 'select',
                                            'options': ['no_tolerance', 'flat_linear', 'flat_halflinear'],
                                            'description': 'Tolerance phase model'},
                                           {'name': 'tolerance_interval', 'value': 5, 'type': 'int_slider',
                                            'min': 0, 'max': 30, 'step': 1,
                                            'description': 'Duration of phases  [min]'},
                                           {'name': 'rejection_costs', 'value': 10.0, 'type': 'float_slider',
                                            'min': 0.0, 'max': 100.0, 'step': 0.1,
                                            'description': 'Cost for rejection [$]'},
                                       ],
                                       compose_model_parameter=[{'name': 'solution_approach', 'value': 'asymmetric_symmetric', 'type': 'select',
                                                                 'options': ['asymmetric_symmetric', 'asymmetric', 'symmetric'],
                                                                 'description': 'Solution approach(es) for optimization'}, ],
                                       compose_model_break_after_statement='pass',
                                       build_qubo_templates={'asymmetric': {'parameter': [
                                           {'name': 'weight_cost', 'value': 50.0, 'type': 'float_bounded', 'min': 0.0,
                                            'max': 10 ** 10, 'description': 'Weight for minimization of net cost'},
                                           {'name': 'weight_waiting', 'value': 1000.0, 'type': 'float_bounded',
                                            'min': 0.0, 'max': 10 ** 10, 'description': 'Weight for minimization of waiting times / rejections'},
                                           {'name': 'weight_penalties', 'value': 1500.0, 'type': 'float_bounded',
                                            'min': 0.0, 'max': 10 ** 10, 'description': 'Weight for minimization of penalties'},
                                           {'name': 'bit_precision', 'value': 16, 'type': 'select',
                                            'options': [16, 32, 64]}
                                       ]},
                                           'symmetric': {'parameter': [{'name': 'A', 'value': 500.0, 'type': 'float_bounded', 'min': 0.0, 'max': 10 ** 10, 'description': 'Constraint 1 (A)'},
                                                                       {'name': 'B', 'value': 500.0, 'type': 'float_bounded', 'min': 0.0, 'max': 10 ** 10, 'description': 'Constraint 2 (B)'},
                                                                       {'name': 'C', 'value': 10.0, 'type': 'float_bounded', 'min': 0.0, 'max': 10 ** 10, 'description': 'Minimize (C)'},
                                                                       ]}},
                                       solve_templates={'asymmetric': {'prep_result': self.prep_result_asymmetric},
                                                        'symmetric': {'prep_result': self.prep_result_symmetric}},
                                       report_title_list=['Report Asymmetric', "Report Symmetric",
                                                          "Visualization Asymmetric", "Visualization Symmetric"],
                                       persistent_file=persistent_file
                                       )

    def load(self, number_cars=3, requests_per_car=2,
             speed=36.0, costs_per_km=1.0, price_per_km=2.0, base_price=5.0,
             dissatisfaction_costs=50.0,
             tolerance_model='no_tolerance',
             tolerance_interval=4.0,
             rejection_costs=100.0,
             filename='',
             silent=False
             ):
        if filename == '':
            print('Please provide a data file.')
            return
        df = pd.read_csv(filename, sep=';')
        requests = df[['PU time', 'PU x-coord', 'PU y-coord', 'DO x-coord', 'DO y-coord']]
        cars = df[['x-coord', 'y-coord']].loc[0:number_cars - 1]

        self.requests = []
        self.cars = []
        start_time = datetime.now()
        self.start_time = start_time
        for index, row in cars.loc[0:number_cars - 1].iterrows():
            self.add_car(
                Car(start_location=(float(row['x-coord']) / 100.0,
                                    float(row['y-coord']) / 100.0),
                    speed=speed, base_price=base_price, price_per_km=price_per_km, costs_per_km=costs_per_km,
                    dissatisfaction_costs=dissatisfaction_costs, tolerance_model=tolerance_model,
                    tolerance_interval=tolerance_interval,
                    rejection_costs=rejection_costs,
                    start_time=start_time
                    )
            )

        for index, row in requests.loc[0:requests_per_car * number_cars - 1].iterrows():
            self.add_request(
                Request(pickup_earliest=start_time + timedelta(seconds=int(row['PU time'])),
                        pickup_location=(float(row['PU x-coord']) / 100.0, float(row['PU y-coord']) / 100.0),
                        dropoff_location=(float(row['DO x-coord']) / 100.0, float(row['DO y-coord']) / 100.0),
                        rejection_costs=rejection_costs
                        )
            )
        self.symmetric_model = SymmetricModel(self.cars, self.requests, self.start_time)
        self.asymmetric_model = AsymmetricModel(self.cars, self.requests, self.start_time)

        if not silent:
            print('Model was initialized for %d car(s) and %d requests.' % (number_cars, requests_per_car * number_cars))

    def compose_model(self, solution_approach='asymmetric_symmetric'):
        if solution_approach == 'asymmetric_symmetric':
            self.build_and_solve('symmetric')
            self.build_and_solve('asymmetric')
        elif solution_approach == 'asymmetric':
            self.build_and_solve('asymmetric')
        elif solution_approach == 'symmetric':
            self.build_and_solve('symmetric')

    def clear_planning(self):
        for car in self.cars:
            car.clear_requests()
        for request in self.requests:
            request.set_planned_trip()

    def plan_default(self):
        self.clear_planning()
        for car in self.cars:
            car.assign_request(self.get_request(2 * car.get_car_number()))
            car.assign_request(self.get_request(2 * car.get_car_number() + 1))
            car.evaluate_tour()

    def plan_nearest_car(self):
        self.clear_planning()
        for request in self.requests:
            nearest_car = None
            best_arrival_time = None
            for car in self.cars:
                if len(car.requests) < 2:
                    arrival_time = car.estimated_arrival(request.pickup_location)
                    if nearest_car is None or arrival_time < best_arrival_time:
                        nearest_car = car
                        best_arrival_time = arrival_time
            if nearest_car is not None:
                nearest_car.assign_request(request)
                nearest_car.evaluate_tour()

    def add_request(self, request=None):
        self.requests.append(request if request is not None else Request())
        self.requests[-1].set_request_number(len(self.requests) - 1)

    def get_request(self, index):
        return self.requests[index] if index < len(self.requests) else None

    def add_car(self, car=None):
        self.cars.append(car if car is not None else Car())
        self.cars[-1].set_car_number(len(self.cars) - 1)

    def report(self, silent=False):
        self.asymmetric_model.report(silent)

    def report1(self, silent=False):
        self.symmetric_model.report(silent)

    def report2(self, case=''):
        self.asymmetric_model.draw(case)

    def report3(self, case=''):
        self.symmetric_model.draw(case)

    def build_qubo_symmetric(self, A=500.0, B=500.0, C=10.0, silent=False):
        self.symmetric_model.build_qubo(A, B, C, silent)
        self.HQ = self.symmetric_model.HQ

    def build_qubo_asymmetric(self,
                              weight_cost=10.0,
                              weight_waiting=1000.0,
                              weight_penalties=1500.0,
                              bit_precision=16,
                              silent=False
                              ):
        self.asymmetric_model.build_qubo(weight_cost=weight_cost,
                                         weight_waiting=weight_waiting,
                                         weight_penalties=weight_penalties,
                                         bit_precision=bit_precision,
                                         silent=silent)
        self.HQ = self.asymmetric_model.HQ.clone()

    def build_qubo_symmetric(self, A=500.0, B=500.0, C=10.0, silent=False):
        self.symmetric_model.build_qubo(A=A, B=B, C=C, silent=silent)
        self.HQ = self.symmetric_model.HQ.clone()

    def prep_result_asymmetric(self, solution_list: SolutionList, silent=False):

        self.asymmetric_model.prep_result(solution_list, silent=silent)

    def prep_result_symmetric(self, solution_list: SolutionList, silent=False):

        self.symmetric_model.prep_result(solution_list, silent=silent)
