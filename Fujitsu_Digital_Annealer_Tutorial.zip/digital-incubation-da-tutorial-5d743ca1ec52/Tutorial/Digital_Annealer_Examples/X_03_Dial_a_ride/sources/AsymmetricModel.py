from .cars_requests import *
from dadk.BinPol import *
from dadk.Solution_SolutionList import *

class AsymmetricModel:
    def __init__(self, cars, requests, start_time):
        import copy
        self.cars = copy.deepcopy(cars)
        self.requests = copy.deepcopy(requests)
        self.start_time = start_time

    def clear_planning(self):
        for car in self.cars:
            car.clear_requests()
        for request in self.requests:
            request.set_planned_trip()

    def plan_default(self):
        self.clear_planning()
        for car in self.cars:
            car.assign_request(self.get_request(2 * car.get_car_number()))
            car.assign_request(self.get_request(2 * car.get_car_number() + 1))
            car.evaluate_tour()

    def plan_nearest_car(self):
        self.clear_planning()
        for request in self.requests:
            nearest_car = None
            best_arrival_time = None
            for car in self.cars:
                if len(car.requests) < 2:
                    arrival_time = car.estimated_arrival(request.pickup_location)
                    if nearest_car is None or arrival_time < best_arrival_time:
                        nearest_car = car
                        best_arrival_time = arrival_time
            if nearest_car is not None:
                nearest_car.assign_request(request)
                nearest_car.evaluate_tour()

    def add_request(self, request=None):
        self.requests.append(request if request is not None else Request())
        self.requests[-1].set_request_number(len(self.requests) - 1)

    def get_request(self, index):
        return self.requests[index] if index < len(self.requests) else None

    def add_car(self, car=None):
        self.cars.append(car if car is not None else Car())
        self.cars[-1].set_car_number(len(self.cars) - 1)

    def build_qubo(self,
                   weight_cost=10.0,
                   weight_waiting=1000.0,
                   weight_penalties=1500.0,
                   bit_precision=16,
                   silent=False,
                   ):
        rejection_time = 2 * int(self.cars[0].tolerance_interval)
        self.rejection_time = rejection_time
        self.var_shape_set = None
        self.cost = None
        self.waiting_times = None
        self.each_pickup_max_once = None
        self.max_to_one_request = None
        self.used_cars = None
        self.invalid = None
        self.H = None
        self.HQ = None

        def weighting_cost(t):
            return self.cars[0].dissatisfaction_measure(timedelta(minutes=0), timedelta(minutes=t))

        self.var_shape_set = VarShapeSet(*([BitArrayShape(name="route_of_car " + str(car.car_number),
                                                          shape=(len(self.requests) + 1, len(self.requests), rejection_time)) for
                                            car in self.cars]
                                           + [BitArrayShape(name="Car " + str(car.car_number) + " not_used", shape=(1,)) for car
                                              in self.cars]
                                           ))
        speed = self.cars[0].speed
        costs_per_km = self.cars[0].costs_per_km
        price_per_km = self.cars[0].price_per_km

        # cost in service time
        self.cost = BinPol(self.var_shape_set)
        for request2 in self.requests:
            costs_for_request2 = self.cars[0].distance_metric(request2.dropoff_location,
                                                              request2.pickup_location) * (costs_per_km - price_per_km)
            for car in self.cars:
                costs_to_request2 = self.cars[0].distance_metric(car.start_location,
                                                                 request2.pickup_location) * costs_per_km
                for t_r in range(rejection_time):
                    self.cost.set_term(
                        costs_to_request2 + costs_for_request2
                        , (("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),)
                    )
                for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                self.requests.index(request2) + 1:]:
                    costs_to_request2 = self.cars[0].distance_metric(request1.dropoff_location,
                                                                     request2.pickup_location) * costs_per_km
                    for t_r in range(rejection_time):
                        self.cost.set_term(
                            costs_to_request2 + costs_for_request2
                            , (("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                self.requests.index(request2), t_r),)
                        )

        # customer dissatisfaction in terms of waiting times / rejection
        self.waiting_times = BinPol(self.var_shape_set)
        for request2 in self.requests:
            # if request2 is not serviced, penalise with rejection cost
            pickup_zero = BinPol(self.var_shape_set)
            pickup_zero.set_term(-1)
            for car in self.cars:
                for t_r in range(rejection_time):
                    pickup_zero.add_term(1, (
                        ("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))
                    for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                    self.requests.index(request2) + 1:]:
                        pickup_zero.set_term(1, (("route_of_car " + str(car.car_number),
                                                  1 + self.requests.index(request1), self.requests.index(request2),
                                                  t_r),))
            pickup_zero.multiply(pickup_zero)
            pickup_zero.multiply_scalar(weighting_cost(rejection_time + 1))
            self.waiting_times.add(pickup_zero)

            # else, penalise with dissatisfaction cost:
            pickup_one = BinPol(self.var_shape_set)
            for car in self.cars:
                for t_r in range(rejection_time):
                    weighting_cost_requ = weighting_cost(t_r + 1)
                    pickup_one.add_term(weighting_cost_requ, (
                        ("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))
                    for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                    self.requests.index(request2) + 1:]:
                        pickup_one.set_term(weighting_cost_requ, (("route_of_car " + str(car.car_number),
                                                                   1 + self.requests.index(request1),
                                                                   self.requests.index(request2), t_r),))
            self.waiting_times.add(pickup_one)

        # each request is serviced at most once
        self.each_pickup_max_once = BinPol(self.var_shape_set)
        for request2 in self.requests:
            pickup_one = BinPol(self.var_shape_set)
            pickup_one.set_term(-1)
            pickup_zero = BinPol(self.var_shape_set)

            for car in self.cars:
                for t_r in range(rejection_time):
                    pickup_zero.add_term(1, (
                        ("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))
                    pickup_one.add_term(1, (
                        ("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))
                    for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                    self.requests.index(request2) + 1:]:
                        pickup_one.set_term(1, (("route_of_car " + str(car.car_number),
                                                 1 + self.requests.index(request1), self.requests.index(request2),
                                                 t_r),))
                        pickup_zero.set_term(1, (("route_of_car " + str(car.car_number),
                                                  1 + self.requests.index(request1), self.requests.index(request2),
                                                  t_r),))
            pickup_one.multiply(pickup_zero)

            self.each_pickup_max_once.add(pickup_one)

        # after terminal or each request, at most one request is serviced
        self.max_to_one_request = BinPol(self.var_shape_set)
        for car in self.cars:
            to_one = BinPol(self.var_shape_set).add_term(-1)
            to_zero = BinPol(self.var_shape_set)
            for request2 in self.requests:
                for t_r in range(rejection_time):
                    to_zero.add_term(1,
                                     (("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))
                    to_one.add_term(1,
                                    (("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))
            to_zero.multiply(to_one)
            self.max_to_one_request.add(to_zero)

            for request1 in self.requests:
                to_one = BinPol(self.var_shape_set).add_term(-1)
                to_zero = BinPol(self.var_shape_set)
                for request2 in self.requests[:self.requests.index(request1)] + self.requests[
                                                                                self.requests.index(request1) + 1:]:
                    for t_r in range(rejection_time):
                        to_zero.add_term(1, (("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                              self.requests.index(request2), t_r),))
                        to_one.add_term(1, (("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                             self.requests.index(request2), t_r),))
                to_zero.multiply(to_one)
                self.max_to_one_request.add(to_zero)

        # for each car, either a request is serviced from terminal, or the car is not used
        self.used_cars = BinPol(self.var_shape_set)
        for car in self.cars:
            car_used = BinPol(self.var_shape_set).add_term(-1)
            car_used.add_term(1, (("Car " + str(car.car_number) + " not_used", 0),))
            for request2 in self.requests:
                for t_r in range(rejection_time):
                    car_used.add_term(1,
                                      (("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),
                                       ))
            car_used.multiply(car_used)

            self.used_cars.add(car_used)

            car_not_used = BinPol(self.var_shape_set)
            for request1 in self.requests:
                for request2 in self.requests[:self.requests.index(request1)] + self.requests[
                                                                                self.requests.index(request1) + 1:]:
                    for t_r in range(rejection_time):
                        car_not_used.add_term(1, (("route_of_car " + str(car.car_number),
                                                   1 + self.requests.index(request1), self.requests.index(request2),
                                                   t_r),
                                                  ("Car " + str(car.car_number) + " not_used", 0)))
            self.used_cars.add(car_not_used)

        # invalid route combinations
        self.invalid = BinPol(self.var_shape_set)

        for car in self.cars:
            # don't stay at a request
            for request1 in self.requests:
                for t_r in range(rejection_time):
                    self.invalid.add_term(1, (("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                               self.requests.index(request1), t_r),))

        for request2 in self.requests:
            # don't return to a request directly
            for t_r in range(rejection_time):
                for car in self.cars:
                    for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                    self.requests.index(request2) + 1:]:
                        for t_s in range(rejection_time):
                            self.invalid.set_term(1, (("route_of_car " + str(car.car_number),
                                                       1 + self.requests.index(request1), self.requests.index(request2),
                                                       t_r),
                                                      ("route_of_car " + str(car.car_number),
                                                       1 + self.requests.index(request2), self.requests.index(request1),
                                                       t_s)))

            # don't continue route with a different car
            for car in self.cars:
                new_pol = BinPol(self.var_shape_set)
                for t_r in range(rejection_time):
                    new_pol.set_term(1,
                                     (("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))

                    for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                    self.requests.index(request2) + 1:]:
                        new_pol.set_term(1, (("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                              self.requests.index(request2), t_r),))

                new_pol2 = BinPol(self.var_shape_set)
                for car2 in self.cars[:self.cars.index(car)] + self.cars[self.cars.index(car) + 1:]:
                    for request3 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                    self.requests.index(request2) + 1:]:
                        for t_s in range(rejection_time):
                            new_pol2.set_term(1, (("route_of_car " + str(car2.car_number),
                                                   1 + self.requests.index(request2), self.requests.index(request3),
                                                   t_s),))
                new_pol.multiply(new_pol2)

                self.invalid.add(new_pol)

            # different cars cannot service the same request
            for car in self.cars:
                new_pol = BinPol(self.var_shape_set)
                for t_r in range(rejection_time):
                    new_pol.set_term(1,
                                     (("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))

                    for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                    self.requests.index(request2) + 1:]:
                        new_pol.set_term(1, (("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                              self.requests.index(request2), t_r),))

                for car2 in self.cars[self.cars.index(car) + 1:]:
                    new_pol2 = BinPol(self.var_shape_set)
                    for t_r in range(rejection_time):
                        new_pol2.set_term(1, (
                            ("route_of_car " + str(car2.car_number), 0, self.requests.index(request2), t_r),))

                        for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                        self.requests.index(
                                                                                            request2) + 1:]:
                            new_pol2.set_term(1, (("route_of_car " + str(car2.car_number),
                                                   1 + self.requests.index(request1), self.requests.index(request2),
                                                   t_r),))

                    new_pol3 = BinPol(self.var_shape_set).add_term(-1)
                    new_pol3.add(new_pol).add(new_pol2)
                    new_pol3.multiply(new_pol.add(new_pol2))

                    self.invalid.add(new_pol3)

            # if a request is serviced after request2, then request2 must have been serviced before
            for car in self.cars:
                new_pol = BinPol(self.var_shape_set)
                new_pol2 = BinPol(self.var_shape_set)

                for t_r in range(rejection_time):
                    new_pol.set_term(1,
                                     (("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))

                    for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                    self.requests.index(request2) + 1:]:
                        new_pol.set_term(1, (("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                              self.requests.index(request2), t_r),))
                        new_pol2.set_term(-1, ((
                                                   "route_of_car " + str(car.car_number), 1 + self.requests.index(request2),
                                                   self.requests.index(request1), t_r),))
                new_pol3 = BinPol(self.var_shape_set).add_term(-1)
                new_pol3.add(new_pol).add(new_pol2)
                new_pol3.multiply(new_pol.add(new_pol2))

                self.invalid.add(new_pol3)

            # invalid timing is not allowed
            new_pol = BinPol(self.var_shape_set)
            for car in self.cars:
                time_to_request2 = self.cars[0].distance_metric(car.start_location,
                                                                request2.pickup_location) / speed * 60
                for t_r in range(rejection_time):
                    if request2.pickup_earliest + timedelta(minutes=t_r) < self.start_time + timedelta(minutes=time_to_request2):
                        new_pol.set_term(1, (
                            ("route_of_car " + str(car.car_number), 0, self.requests.index(request2), t_r),))

                for request1 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                self.requests.index(request2) + 1:]:
                    time_for_request1 = self.cars[0].distance_metric(request1.dropoff_location,
                                                                     request1.pickup_location) / speed * 60
                    time_to_request2 = self.cars[0].distance_metric(request1.dropoff_location,
                                                                    request2.pickup_location) / speed * 60
                    for t_r in range(rejection_time):
                        for t_s in range(rejection_time):
                            if request2.pickup_earliest + timedelta(minutes=t_r) < \
                                    request1.pickup_earliest + timedelta(minutes=t_s + time_for_request1 + time_to_request2):
                                new_pol.set_term(1, (
                                    ("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                     self.requests.index(request2), t_r),
                                    ("route_of_car " + str(car.car_number), 0, self.requests.index(request1), t_s)
                                ))
                                for request3 in self.requests[:self.requests.index(request2)] + self.requests[
                                                                                                self.requests.index(
                                                                                                    request2) + 1:]:
                                    if request3 == request1:
                                        continue
                                    new_pol.set_term(1, (
                                        ("route_of_car " + str(car.car_number), 1 + self.requests.index(request1),
                                         self.requests.index(request2), t_r),
                                        ("route_of_car " + str(car.car_number), 1 + self.requests.index(request3),
                                         self.requests.index(request1), t_s)
                                    ))
            self.invalid.add(new_pol)

        self.HQ = BinPol(self.var_shape_set)
        if self.cost.qubo_matrix_array is not None:
            self.HQ.add(
                self.cost.clone().multiply_scalar(weight_cost / np.max(np.absolute(self.cost.qubo_matrix_array))))
        else:
            self.HQ.add(
                self.cost.clone().multiply_scalar(weight_cost / np.max(np.absolute(list(self.cost.p.values())))))
        if self.waiting_times.qubo_matrix_array is not None:
            self.HQ.add(self.waiting_times.clone().multiply_scalar(
                weight_waiting / np.max(np.absolute(self.waiting_times.qubo_matrix_array))))
        else:
            self.HQ.add(self.waiting_times.clone().multiply_scalar(
                weight_waiting / np.max(np.absolute(list(self.waiting_times.p.values())))))

        self.HQ.add(self.each_pickup_max_once.clone().multiply_scalar(
            weight_penalties))
        self.HQ.add(self.max_to_one_request.clone().multiply_scalar(
            weight_penalties))
        self.HQ.add(
            self.used_cars.clone().multiply_scalar(weight_penalties))  # /max(np.absolute(used_cars.p.values()))))
        self.HQ.add(self.invalid.clone().multiply_scalar(weight_penalties))  # /max(np.absolute(invalid.p.values()))))

        if self.HQ.N >= 4000:
            bit_precision = 16
        else:
            bit_precision = bit_precision

        if (self.HQ.qubo_matrix_array is not None and max(np.max(self.HQ.qubo_matrix_array),
                                                          -np.min(self.HQ.qubo_matrix_array)) > 2 ** (
                bit_precision - 1) - 1):
            self.HQ.multiply_scalar(
                (2.0 ** (bit_precision - 1) - 1) /
                max(np.max(self.HQ.qubo_matrix_array), -np.min(self.HQ.qubo_matrix_array))
            )

        elif np.max(np.absolute(list(self.HQ.p.values()))) > 2 ** (bit_precision - 1) - 1:
            self.HQ.multiply_scalar(
                (2.0 ** (bit_precision - 1) - 1) /
                np.max(np.absolute(list(self.HQ.p.values()))
                       )
            )

        if not silent:
            print('Number of bits: %d' % self.HQ.N)

    def prep_result(self, solution_list: SolutionList, silent=False):

        configuration = solution_list.min_solution.configuration

        rejection_time = self.rejection_time
        self.clear_planning()

        if not silent:
            print("Requests to service: ", [request.request_number for request in self.requests])
        serviced_requests = []
        cars_not_used = []
        for car in self.cars:
            if solution_list.min_solution.extract_bit_array("Car " + str(car.car_number) + " not_used").data[0] == 1:
                cars_not_used.append(car.car_number)
        if not silent:
            print("Unused cars: ", cars_not_used)

        for car in self.cars:
            if car.car_number not in cars_not_used:
                if not silent:
                    print("Route of car %d:" % car.car_number)
                route_matrix = solution_list.min_solution.extract_bit_array("route_of_car " + str(car.car_number)).data
                location = None
                route = [0]
                times = []
                iterations = 0
                end_of_route = False
                while not end_of_route and iterations <= len(self.requests):
                    end_of_route = True
                    for t_r in range(rejection_time):
                        if np.sum(route_matrix[:, :, t_r][route[-1]]) == 1:
                            location = route_matrix[:, :, t_r][route[-1]].dot(np.arange(len(self.requests))) + 1
                            route += [location]
                            times += [t_r]
                            iterations += 1
                            end_of_route = False
                            break

                if not silent:
                    print("Depot ", "->", end="")
                for location in route[1:]:
                    car.assign_request(self.requests[location - 1])
                    if not silent:
                        print("Request ", self.requests[location - 1].request_number, "-> ", end="")
                if not silent:
                    print("Depot ")
                    print("")
                for i, location in enumerate(route[1:]):
                    if not silent and location > 0:
                        print("Request ", self.requests[location - 1].request_number, ": ")
                        print("Waiting time: ", times[i] + 1)
                if not silent:
                    print("")
                serviced_requests += route[1:]
                car.evaluate_tour()

        not_serviced = []
        for request_nr in range(len(self.requests)):
            if request_nr + 1 not in serviced_requests:
                not_serviced.append(self.requests[request_nr].request_number)

        if not silent:
            print("Request ID's which where not serviced: ", not_serviced)
            print("\n")

            print("Net cost: ", self.cost.compute(configuration))
            print("Waiting / Rejection penalties: ", self.waiting_times.compute(configuration))

            print("Penalties due to:")
            print("Requests serviced more than once: ", self.each_pickup_max_once.compute(configuration))
            print("More than one request serviced from a location: ",
                  self.max_to_one_request.compute(configuration))
            print("Unused cars: ", self.used_cars.compute(configuration))
            print("Invalid paths: ", self.invalid.compute(configuration))

    def report(self, silent=False):
        def format_time(t):
            return t.strftime("%H:%M:%S") if t is not None else '-'

        def plus_avg_sum(lst):
            return list(lst) + [sum(lst) / len(lst), sum(lst)]

        if len(self.requests) == 0:
            return

        results = zip(
            list(map(lambda x: x.request_number, self.requests)) + ['Avg', 'Sum'],
            list(map(lambda x: format_time(x.pickup_earliest), self.requests)) + ['-', '-'],
            list(map(lambda x: str(x.car.get_car_number()) if x.car is not None else 'rejected', self.requests)) + ['-',
                                                                                                                    '-'],
            list(map(lambda x: format_time(x.pickup_time), self.requests)) + ['-', '-'],
            list(map(lambda x: format_time(x.dropoff_time), self.requests)) + ['-', '-'],
            plus_avg_sum(list(map(lambda x: (x.price or 0.0), self.requests))),
            plus_avg_sum(list(map(lambda x: (x.costs or 0.0), self.requests))),
            plus_avg_sum(list(map(lambda x: (x.win or 0.0), self.requests))),
            plus_avg_sum(list(map(lambda x: (x.dissatisfaction or 0.0), self.requests))),
            plus_avg_sum(list(map(lambda x: (x.rejection or 0.0), self.requests))),
            plus_avg_sum(list(map(lambda x: (x.rejection_costs or 0.0), self.requests))),
            plus_avg_sum(list(map(lambda x: (x.contribution or 0.0), self.requests))),
        )
        headers = ['#', 'Pickup request', 'Car', 'Pickup time', 'Dropoff time',
                   'Price', 'Costs', 'Win', 'Dissatisfaction', 'Rejection', 'Rejection costs', 'Contribution']
        if not silent:
            display(HTML(tabulate(results, headers=headers, tablefmt='html', floatfmt=".2f")))
        else:
            summary_list = list(results)[-2:]
            summary_object = {}
            for c in range(5, len(headers), 1):
                col_obj = {}
                summary_object[headers[c]] = col_obj
                for i, name in enumerate(['average', 'sum']):
                    col_obj[name] = summary_list[i][c]
            return summary_object

    def draw(self, case=''):
        import matplotlib.pyplot as plt
        fig = plt.figure('Ride Planning (created %s)' % datetime.now(), figsize=(9, 7))
        ax = fig.add_subplot(1, 1, 1)
        ax.set_aspect('equal')

        for c in self.cars:
            plt.plot(c.start_location[0], c.start_location[1], 'o', color=c.color, linewidth=2, zorder=1)
            plt.annotate(c.get_tour_label(),
                         (c.start_location[0], c.start_location[1]),
                         xytext=(5, 0),
                         textcoords='offset points',
                         color=c.color
                         )
            tour = c.get_tour()
            p_x = [point["location"][0] for point in tour]
            p_y = [point["location"][1] for point in tour]
            for p_i in range(len(p_x) // 4):
                plt.plot(p_x[4 * p_i: 4 * p_i + 3], p_y[4 * p_i: 4 * p_i + 3], '--', color=c.color, linewidth=2,
                         zorder=1)
                plt.plot(p_x[4 * p_i + 2: 4 * p_i + 5], p_y[4 * p_i + 2: 4 * p_i + 5], '-', color=c.color, linewidth=2,
                         zorder=1)
            for point in tour:
                if point["time"] is not None:
                    plt.annotate(point["time"].strftime('%H:%M'), point["location"],
                                 xytext=(-40, 0),
                                 textcoords='offset points',
                                 color='white',
                                 backgroundcolor=c.color
                                 )
        for r in self.requests:
            plt.plot([r.pickup_location[0], r.dropoff_location[0]],
                     [r.pickup_location[1], r.dropoff_location[1]],
                     ':', color='grey', linewidth=3, zorder=0)
            plt.annotate('$request_{%d}$: %s-%s' % (r.get_request_number(),
                                                    r.pickup_earliest.strftime('%H:%M'),
                                                    r.pickup_latest.strftime('%H:%M')),
                         (r.pickup_location[0], r.pickup_location[1]),
                         xytext=(5, 0),
                         textcoords='offset points',
                         color='black'
                         )
        plt.show()
