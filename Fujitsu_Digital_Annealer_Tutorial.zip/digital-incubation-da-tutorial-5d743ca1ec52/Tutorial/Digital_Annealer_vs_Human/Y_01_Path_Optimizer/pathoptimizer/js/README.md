Display and game for coordinated optimized motion along paths

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save pathoptimizer
```
