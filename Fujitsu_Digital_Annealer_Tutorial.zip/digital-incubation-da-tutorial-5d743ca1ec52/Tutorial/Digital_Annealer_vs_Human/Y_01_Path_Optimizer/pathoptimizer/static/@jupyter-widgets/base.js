console.log('start widgets ...');
var extend = function ( defaults ) {
    var base = this;
    class extended extends base {};
    var prop;
    for (prop in defaults) {
        if (extended.prototype.hasOwnProperty.call(defaults, prop)) {
            extended.prototype[prop] = defaults[prop];
        }
    }
    return extended;
};

var DOMWidgetModel = class {
    constructor(){
        this.event_handler = {change:{}};
        var prop;
        for(prop in this.defaults) {
            Object.defineProperty(this, prop, {
                set: eval('function f(x) {\n' +
                    'var is_changed = this._' + prop + ' != x;\n'+
                    'this._' + prop + ' = x;\n' +
                    'if(is_changed && this.event_handler.change.' + prop + '){\n'+
                    '  const handlers = this.event_handler.change.' + prop + ';\n'+
                    '  for(var i in handlers){\n'+
                    '    const unbounded = handlers[i].call_back;\n'+
                    '    const bounded = unbounded.bind(handlers[i].target_object);\n'+
                    '    bounded();\n}}} f'),
                get: eval('function f() {\n' +
                    'return this._' + prop + ';\n} f')
            });
            this[prop] = JSON.parse(JSON.stringify(this.defaults[prop]));
        }
    }

    get(prop){
        return this[prop];
    }

    set(prop, value){
        this[prop] = value;
    }

    on(event_str, call_back, target_object ) {
        var parts = event_str.split(':');
        if(!this.event_handler[parts[0]])
            this.event_handler[parts[0]] = {};
        if(this.event_handler[parts[0]][parts[1]])
            this.event_handler[parts[0]][parts[1]].push({call_back:call_back, target_object:target_object})
        else
            this.event_handler[parts[0]][parts[1]] = [{call_back:call_back, target_object:target_object}];
    }

    reset_model() {
        this.event_handler = {change:{}};
    }

    load_model(properties) {
        var prop;
        for(prop in this.defaults)
            this[prop] = JSON.parse(JSON.stringify(this.defaults[prop]));
        for(var prop in properties)
            this.set(prop, JSON.parse(JSON.stringify(properties[prop])));
    }

    defaults()  {
        return {};
    }
}
DOMWidgetModel.extend = extend;

var DOMWidgetView = class {
    constructor(model, el){
        this.model = model;
        this.el = el;
        this.render();
    }


    defaults()  {
        return {};
    }
}
DOMWidgetView.extend = extend;

define(['lodash'], function(_){
    var retvalue =  {
        DOMWidgetModel: DOMWidgetModel,
        DOMWidgetView: DOMWidgetView
    };
    return retvalue
});

console.log('completed widgets !!!');
