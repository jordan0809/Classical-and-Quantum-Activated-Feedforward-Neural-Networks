import ipywidgets as widgets
from traitlets import Unicode, Bool, Int, Float, Dict, List, validate, TraitError
from IPython.display import display, Javascript

# See js/lib/board.js for the frontend counterpart to this file.

@widgets.register
class Board(widgets.DOMWidget):
    _view_name = Unicode('BoardView').tag(sync=True)
    _view_module = Unicode('pathoptimizer').tag(sync=True)
    _view_module_version = Unicode('0.1.0').tag(sync=True)

    # Attributes
    width = Int(default_value=5, help='Width of board').tag(sync=True)
    height = Int(default_value=5, help='Height of board').tag(sync=True)
    excluded = List(default_value=[], help='Excluded fields').tag(sync=True)
    title = Unicode(default_value='New board', help='Title displayed inside board').tag(sync=True)
    org = List(default_value=[], help='Robot origins (field indices numbered line wise starting at bottom left corner)').tag(sync=True)
    dest = List(default_value=[], help='Robot destinations (field indices numbered line wise starting at bottom left corner)').tag(sync=True)
    paths = List(default_value=[], help='Robot paths is a list of path lists per robot  (field indices numbered line wise starting at bottom left corner)').tag(sync=True)
    scale = Float(default_value=100.0, help='Scaling of board').tag(sync=True)
    aura = Float(default_value=0.3, help='Opacity of robot aura').tag(sync=True)
    time_tick = Int(default_value=0, help='Current time tick').tag(sync=True)
    max_time_tick = Int(default_value=0, help='Maximum possible time tick').tag(sync=True)
    value = Dict(default_value={'not_set': True}, help='Setting and return variable for edit mode').tag(sync=True)
    level_finished = Bool(default_value=False, help='Boolean value set to true, when a level was finished successfully.').tag(sync=True)
    game_over = Bool(default_value=False, help='Boolean value set to true when game is over. For success check level_finished.').tag(sync=True)

    # Basic validator for the chart dictionary
    @validate('value')
    def _validate_board(self, proposal):
        if 'not_set' not in proposal['value'] and 'title' not in proposal['value']:
            raise TraitError('Invalid board data: dictionary must contain a key "title" or "not_set".')
        return proposal['value']

    @validate('scale')
    def _validate_data(self, proposal):
        return proposal['value']

try:
    from dadk.Optimizer import WidgetGui
    WidgetGui.register_widget_class(Board)
except:
    print('failure in registration of widget')

def load_view():
    display(Javascript('''
    var href = window.location.href;
    var path = href.substr(0, href.lastIndexOf("/"));
    require.config({paths: {pathoptimizer: path + "/pathoptimizer/js/lib/board", 
                            'd3': path + "/pathoptimizer/js/lib/d3.min"}});
    '''))