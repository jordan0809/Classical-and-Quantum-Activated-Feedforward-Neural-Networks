Search.setIndex({
    "docnames": ["BinPol", "BinPolGen", "Internal", "Introduction", "JupyterTools", "Optimizer", "Solution_SolutionList", "Solvers", "Utils", "_Constants", "index"],
    "filenames": ["BinPol.rst", "BinPolGen.rst", "Internal.rst", "Introduction.rst", "JupyterTools.rst", "Optimizer.rst", "Solution_SolutionList.rst", "Solvers.rst", "Utils.rst", "_Constants.rst", "index.rst"],
    "titles": ["Polynomials", "Generate Polynomials and Description", "Internal", "Introduction", "JupyterTools", "Optimizer", "Optimization Solutions", "Solvers", "Utils", "Other", "Digital Annealer Development Kit"],
    "terms": {
        "especi": [0, 2, 7],
        "qubo": [0, 2, 4, 5, 6, 7, 8, 9, 10],
        "ar": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        "us": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "specifi": [0, 1, 2, 4, 5, 6, 7, 8],
        "model": [0, 2, 5, 7],
        "digit": [0, 2, 3, 4, 7, 8, 9],
        "anneal": [0, 2, 3, 4, 5, 6, 7, 8, 9],
        "thi": [0, 1, 2, 4, 5, 6, 7, 8, 9, 10],
        "chapter": [0, 3],
        "describ": [0, 1, 3, 4, 7, 8],
        "all": [0, 2, 3, 4, 5, 7, 8, 9],
        "class": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        "creat": [0, 1, 2, 3, 4, 5, 6, 7, 8],
        "It": [0, 2, 3, 4, 5, 6, 7, 8],
        "start": [0, 2, 3, 4, 5, 6, 7, 8, 10],
        "base": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "repres": [0, 1, 4, 5, 6, 7, 8, 9],
        "float": [0, 2, 4, 5, 6, 7, 8, 9],
        "coeffici": [0, 2, 5, 7, 9],
        "i": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        "special": [0, 4, 5],
        "linear": [0, 2, 7],
        "an": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "less": 0,
        "equal": [0, 2, 6],
        "zero": [0, 2, 4, 7],
        "which": [0, 2, 3, 4, 5, 6, 7, 8, 9],
        "can": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        "addit": [0, 2, 4, 5, 6, 7, 8, 9],
        "constraint": [0, 2, 6, 7, 8],
        "further": [0, 1, 4, 7, 8],
        "restrict": [0, 4, 5, 8],
        "dadk": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        "var_shape_set": [0, 6, 10],
        "none": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "qubo_matrix_arrai": 0,
        "ndarrai": [0, 2, 6],
        "one_hot": [0, 8, 9, 10],
        "dict": [0, 2, 5, 6, 7, 8, 9, 10],
        "str": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "list": [0, 2, 4, 5, 6, 7, 8, 9],
        "int": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "constant": [0, 2, 6, 7, 10],
        "0": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "object": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "run": [0, 2, 4, 6, 7, 9, 10],
        "A": [0, 1, 2, 4, 5, 6, 7, 9],
        "afterward": 0,
        "chang": [0, 2, 4, 5, 7, 8],
        "multipl": [0, 4, 5, 6, 7, 9],
        "wai": [0, 6],
        "order": [0, 2, 4, 5, 6],
        "intend": [0, 4],
        "from": [0, 2, 4, 5, 6, 7, 8, 9],
        "current": [0, 2, 4, 5, 6, 7, 8, 9],
        "busi": [0, 5, 6],
        "input": [0, 1, 4, 5, 6, 7],
        "data": [0, 2, 4, 5, 6, 7, 8, 9],
        "besid": [0, 5],
        "other": [0, 2, 4, 5, 8, 10],
        "follow": [0, 1, 2, 4, 5, 7, 8],
        "help": [0, 2, 5, 7, 10],
        "To": [0, 1, 3, 5, 7, 8],
        "certain": [0, 4, 5, 6, 8],
        "doe": [0, 2, 6, 7],
        "similar": [0, 2, 4, 5, 7],
        "clear": [0, 4, 5],
        "previous": 0,
        "set": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "same": [0, 2, 4, 5, 6, 7, 8],
        "have": [0, 2, 4, 5, 6, 7, 8],
        "unintend": 0,
        "effect": 0,
        "when": [0, 2, 4, 5, 7, 8],
        "fix": [0, 2, 4, 5, 7, 8],
        "therefor": [0, 2, 4],
        "usag": [0, 3, 4, 5, 8],
        "recommend": [0, 2, 3, 7],
        "case": [0, 2, 4, 5, 7, 8],
        "avail": [0, 2, 3, 4, 5, 7, 8],
        "arithmet": 0,
        "mai": [0, 2, 3, 4, 7, 8],
        "formul": [0, 7],
        "al": 0,
        "well": [0, 1, 5, 6],
        "With": [0, 1, 4, 5, 7],
        "degre": [0, 7, 10],
        "n": [0, 1, 9, 10],
        "one": [0, 2, 4, 5, 6, 7, 8],
        "check": [0, 1, 2, 4, 5, 7, 8, 9],
        "number": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "optim": [0, 2, 3, 4, 7, 9, 10],
        "problem": [0, 2, 5, 7, 8, 9],
        "ha": [0, 4, 5, 6, 7, 8, 9],
        "support": [0, 4, 5, 7],
        "construct": [0, 4, 5],
        "combin": [0, 2, 5, 7, 8],
        "ani": [0, 2, 4, 5, 6, 7, 8, 9],
        "offer": [0, 4, 5],
        "quadrat": [0, 2, 7],
        "minima": [0, 2, 7],
        "origin": [0, 5],
        "higher": [0, 6],
        "import": [0, 1],
        "sinc": [0, 4],
        "quantum": 0,
        "onli": [0, 2, 4, 5, 6, 7, 8, 9],
        "process": [0, 2, 4, 5, 6, 7],
        "unconstrain": 0,
        "reduct": [0, 7],
        "hobo": 0,
        "often": 0,
        "avoid": 0,
        "appropri": [0, 5, 8],
        "definit": [0, 1, 4, 5, 7, 8],
        "though": 0,
        "typic": [0, 5, 6],
        "increas": [0, 2, 5, 7],
        "compar": [0, 8],
        "gener": [0, 2, 4, 5, 6, 7, 8, 10],
        "better": 0,
        "than": [0, 2, 4, 7, 9],
        "automat": [0, 2, 4, 5, 7, 9],
        "helper": [0, 2, 6],
        "intern": [0, 1, 3, 4, 5, 6, 7, 8, 9, 10],
        "call": [0, 2, 4, 5, 6, 7, 8, 9],
        "constructor": [0, 2, 4, 5, 6, 7, 8],
        "new": [0, 2, 4, 5, 6, 7, 8, 9],
        "initi": [0, 1, 2, 4, 5, 7],
        "step": [0, 2, 4, 5, 6, 7, 10],
        "provid": [0, 2, 4, 6, 7, 8],
        "paramet": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "possibl": [0, 2, 4, 5, 6, 7, 8, 9],
        "complet": [0, 2, 4, 5, 6, 7, 9],
        "allow": [0, 1, 2, 4, 5, 6],
        "symbol": [0, 4],
        "argument": [0, 4, 5, 6, 7],
        "vector": [0, 3, 6],
        "underli": [0, 5, 6, 8],
        "If": [0, 1, 2, 4, 5, 6, 7, 8],
        "overrid": [0, 5],
        "hot": [0, 8],
        "possibli": [0, 5],
        "given": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "group": [0, 4, 5, 8],
        "plain": [0, 2, 4, 5, 7, 8, 9],
        "address": [0, 2, 4, 5, 7, 8],
        "declar": [0, 4, 5, 6, 7, 8],
        "rang": [0, 4, 5, 6, 9],
        "section": 0,
        "1": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "dimension": 0,
        "integ": [0, 2, 4, 6, 7, 8],
        "one_wai": [0, 9],
        "l1": 0,
        "l2": 0,
        "l3": 0,
        "ln": 0,
        "give": [0, 2, 4],
        "length": [0, 2, 4, 5, 7],
        "respect": [0, 2, 4, 5, 7],
        "2": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "pair": [0, 2, 4, 5, 7, 9],
        "two_wai": [0, 8, 9],
        "w_1": 0,
        "h_1": 0,
        "w_2": 0,
        "h2": 0,
        "w_n": 0,
        "h_n": 0,
        "w_i": 0,
        "h_i": 0,
        "stand": [0, 2, 6, 7],
        "width": [0, 2, 4, 5],
        "height": [0, 4],
        "rectangl": 0,
        "cover": 0,
        "map": [0, 2],
        "shape": [0, 4, 6, 10],
        "instanc": [0, 5, 6, 8],
        "store": [0, 1, 2, 4, 5, 6, 7, 8],
        "attribut": [0, 1, 4, 5, 6, 7, 8],
        "via": [0, 2, 5, 7, 8],
        "correspond": [0, 2, 4, 5, 6, 7, 8, 9],
        "name": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "consist": [0, 1, 2, 4, 5, 8],
        "indic": [0, 2, 7, 8, 9],
        "numpi": [0, 6],
        "matrix": [0, 5, 7],
        "must": [0, 2, 4, 5, 7],
        "type": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "dictionari": [0, 2, 4, 5, 6, 7, 8, 9],
        "kei": [0, 2, 4, 5, 6, 7, 8, 9],
        "area": [0, 6],
        "valu": [0, 2, 4, 5, 6, 7, 8, 9, 10],
        "arg": [0, 5, 9],
        "singl": [0, 2, 4, 5, 6, 7, 8, 9],
        "monomi": 0,
        "e": [0, 2, 4, 5, 7, 8],
        "g": [0, 4, 5, 8],
        "42": [0, 2],
        "x_2": 0,
        "x_3": 0,
        "x_7": 0,
        "ad": [0, 1, 4, 5],
        "two": [0, 1, 2, 4, 5, 7, 8],
        "statement": [0, 4, 5],
        "3": [0, 2, 4, 5, 7, 8, 9],
        "7": [0, 1, 2, 5, 6],
        "return": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "chain": [0, 5],
        "index": [0, 2, 4, 5, 6, 8, 9],
        "caveat": 0,
        "replac": [0, 4, 5, 8],
        "might": 0,
        "eras": 0,
        "even": [0, 5],
        "formal": 0,
        "differ": [0, 1, 2, 4, 5, 7, 8],
        "refer": [0, 4, 5, 7, 8],
        "ident": [0, 2, 4, 7],
        "x_0": 0,
        "x_1": 0,
        "correctli": [0, 2, 7],
        "while": [0, 2, 4, 5, 7],
        "deliv": [0, 8],
        "expect": [0, 2, 4, 5, 6, 7, 8],
        "result": [0, 1, 2, 4, 5, 6, 7, 8],
        "empti": [0, 2, 4, 5, 8],
        "tupl": [0, 2, 4, 5, 6, 8, 9],
        "scalar": 0,
        "contain": [0, 1, 2, 3, 4, 5, 6, 8, 9, 10],
        "extens": 0,
        "latter": [0, 5, 9],
        "merg": [0, 9],
        "access": [0, 2, 4, 7, 8],
        "exceed": [0, 4],
        "yield": 0,
        "error": [0, 2, 3, 5, 7, 9],
        "maxim": [0, 2, 4, 7],
        "moreov": 0,
        "inherit": 0,
        "otherwis": [0, 1, 2, 4, 5, 6, 7, 8],
        "take": [0, 4, 5, 7, 8],
        "place": [0, 4, 5, 8],
        "without": [0, 2, 4, 5, 7, 9],
        "option": [0, 1, 4, 5, 6, 7, 8, 9],
        "factor": [0, 1, 2, 7, 8, 9],
        "self": [0, 4, 5],
        "instead": [0, 2, 4, 5, 6],
        "penalti": [0, 2, 5, 6, 7, 10],
        "slack": [0, 6, 9],
        "under": [0, 3, 4, 5, 8],
        "should": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        "befor": [0, 2, 4, 5, 7, 8],
        "encod": [0, 2, 7, 8, 9],
        "form": [0, 4, 5, 6, 7, 9],
        "desir": 0,
        "copi": [0, 1, 4, 5, 6, 8, 9],
        "clamped_configur": 0,
        "bool": [0, 2, 4, 5, 6, 7, 8, 9],
        "state": [0, 2, 4, 6, 7],
        "clamp": 0,
        "configur": [0, 2, 4, 5, 6, 7, 9, 10],
        "reduc": [0, 2, 7],
        "clamping_bit": 0,
        "deriv": [0, 2, 5],
        "some": [0, 5, 7],
        "arrai": [0, 4, 5, 6, 8, 9],
        "its": [0, 2, 4, 5, 7, 8],
        "size": [0, 2, 4, 5, 6, 7, 8, 9],
        "coincid": 0,
        "element": [0, 2, 4, 5, 8],
        "entri": [0, 4, 5, 6, 7, 8, 10],
        "stai": 0,
        "subspac": 0,
        "seach": 0,
        "simpli": [0, 6, 8],
        "drop": 0,
        "care": [0, 5],
        "between": [0, 2, 4, 7, 8, 9],
        "see": [0, 2, 4, 5, 6, 7, 8, 9],
        "union": [0, 2, 4, 5, 6, 7, 8],
        "rais": [0, 5, 8, 9],
        "valueerror": [0, 8],
        "inappropri": 0,
        "r": [0, 2, 7, 9],
        "expon": 0,
        "calcul": [0, 2, 4, 5, 7],
        "squar": 0,
        "so": [0, 2, 3, 4, 5, 7, 9],
        "far": [0, 2, 7],
        "driven": [0, 5],
        "manipul": [0, 3],
        "sumar": 0,
        "tabl": [0, 4, 5, 6, 7],
        "operand": 0,
        "exampl": [0, 4, 5, 6, 7],
        "plu": [0, 4, 5],
        "p": [0, 5, 7, 10],
        "q": 0,
        "minu": 0,
        "time": [0, 2, 4, 5, 6, 7, 8, 9],
        "ineq": 0,
        "greater": [0, 2],
        "bit_valu": 0,
        "start_stop": 0,
        "altern": [0, 4, 9],
        "choos": [0, 2, 4, 5, 7],
        "In": [0, 2, 4, 5, 6, 7, 8],
        "those": [0, 4, 5, 7, 8],
        "keyword": [0, 2, 5, 6],
        "stop": [0, 4, 5, 6, 8, 10],
        "true": [0, 2, 4, 5, 6, 7, 8],
        "fals": [0, 2, 4, 5, 6, 7, 8],
        "more": [0, 4, 7, 8],
        "string": [0, 1, 4, 5, 7, 8, 9],
        "consid": [0, 1],
        "both": [0, 2, 4],
        "": [0, 2, 4, 5, 7, 9],
        "upper_triangular": 0,
        "dtype": 0,
        "classvar": 0,
        "int64": 0,
        "float64": 0,
        "collect": [0, 2, 8, 9],
        "upper": [0, 2, 4, 5, 7],
        "triangular": 0,
        "symmetr": 0,
        "For": [0, 2, 4, 5, 7],
        "2x_1": 0,
        "weight": [0, 2, 7, 8],
        "default": [0, 2, 4, 5, 6, 7, 8, 9],
        "np": [0, 2],
        "scipi": 0,
        "spars": 0,
        "coo_matrix": 0,
        "use_qubo_matrix": [0, 5, 7, 10],
        "use_compact": [0, 5, 7, 10],
        "json": [0, 2, 4, 5, 7, 8],
        "file": [0, 2, 4, 5, 6, 7, 8, 9, 10],
        "been": [0, 4, 5, 6, 8],
        "explicit": [0, 7],
        "format": [0, 4, 5, 7, 9],
        "rest": [0, 2, 7, 8, 9],
        "servic": [0, 2, 4, 7, 8],
        "depend": [0, 4, 5],
        "version": [0, 2, 4, 7, 8, 9],
        "enabl": [0, 2, 4, 5, 7, 8, 9],
        "enforc": [0, 7, 8],
        "creation": [0, 4, 7, 8],
        "compact": [0, 7, 8],
        "dau": [0, 7],
        "webapi": [0, 7],
        "v3": [0, 7],
        "c": [0, 1, 4, 5, 7],
        "document": [0, 1, 2, 3, 4, 5, 6, 7, 8],
        "compat": [0, 6],
        "api": [0, 2, 5, 7, 8, 9],
        "char": 0,
        "sort": [0, 6, 8],
        "latex": [0, 1, 4],
        "present": [0, 4, 5, 6, 8],
        "descript": [0, 4, 5, 8, 9, 10],
        "3f": 0,
        "after": [0, 2, 4, 5, 7, 8, 9],
        "decim": 0,
        "point": [0, 2, 4, 5, 6],
        "dimod": 0,
        "binaryquadraticmodel": 0,
        "pattern": [0, 4, 5, 8],
        "d": [0, 1, 4],
        "qbsolv": 0,
        "http": [0, 2, 3, 7, 8, 9],
        "doc": 0,
        "ocean": 0,
        "dwavesi": 0,
        "com": [0, 3],
        "project": 0,
        "en": 0,
        "latest": [0, 5],
        "html": [0, 4, 5],
        "formatt": 0,
        "specif": [0, 2, 4, 5, 7, 8],
        "x": [0, 1, 2, 4, 8, 9],
        "chosen": [0, 7],
        "binary_polynomial_kei": 0,
        "binary_polynomi": [0, 6],
        "qubo_matrix_kei": 0,
        "qubo_matrix": 0,
        "bit_precis": [0, 2, 7],
        "64": [0, 2, 7],
        "check_number_of_bit": [0, 7],
        "report_prefix": [0, 9],
        "report_round_to_zero": 0,
        "report_hol": [0, 7],
        "represent": [0, 1, 4, 5, 8],
        "either": [0, 2, 4, 5, 7, 8],
        "each": [0, 2, 4, 5, 7, 8],
        "row": [0, 4, 5, 6, 10],
        "qubo_row": 0,
        "output": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "dav2": [0, 2, 5, 7, 9],
        "precis": [0, 2, 7],
        "16": [0, 2, 7, 8],
        "32": [0, 2, 7],
        "requir": [0, 2, 5, 7],
        "against": [0, 4],
        "report": [0, 4, 5, 7],
        "messag": [0, 5, 8],
        "indentifi": 0,
        "issu": 0,
        "round": [0, 4, 9],
        "within": [0, 4, 5, 6],
        "convers": 0,
        "found": [0, 2, 4, 5, 6, 8],
        "hole": [0, 7],
        "unus": 0,
        "parallel": [0, 2, 4, 7, 9],
        "mean": [0, 2, 4, 8],
        "callabl": [0, 4, 5, 6, 7, 8],
        "iter": [0, 2, 5, 7],
        "produc": [0, 2, 4, 5, 7, 8],
        "implicitli": [0, 4, 7],
        "qubosolverbas": [0, 2, 10],
        "qubosolverbasev2": [0, 10],
        "minim": [0, 2, 4, 5, 6, 7, 8],
        "qubosolverdav2": [0, 10],
        "th": 0,
        "line": [0, 4, 5, 9],
        "extend": [0, 2, 4],
        "sting": 0,
        "identifi": [0, 4, 8],
        "until": [0, 2, 7],
        "overwritten": [0, 8],
        "start_index": 0,
        "work": [0, 2, 3, 4, 5, 7, 8],
        "end": [0, 2, 4, 7, 9],
        "increment": [0, 2, 4, 5, 7],
        "lowest": [0, 2, 6],
        "penalty_factor": 0,
        "wa": [0, 2, 4, 5, 6, 7, 8],
        "convert": [0, 4, 6, 7, 8, 9],
        "prescrib": 0,
        "penal": 0,
        "mismatch": 0,
        "second": [0, 2, 4, 5, 7, 8],
        "pol": 0,
        "yet": 0,
        "also": [0, 2, 4, 5, 6, 7, 8],
        "poli": 0,
        "particular": [0, 5, 7, 8],
        "highest": [0, 2],
        "coupl": 0,
        "attain": [0, 2],
        "iff": 0,
        "cdot": 0,
        "would": [0, 5, 8],
        "y": [0, 4, 8],
        "where": [0, 2, 4, 5, 6, 7, 8, 9],
        "larger": [0, 2, 7],
        "being": [0, 4, 8],
        "10": [0, 2, 4, 5, 7, 8],
        "clone_warning_count": 0,
        "threshold": [0, 2, 7],
        "trigger": [0, 4, 5],
        "warn": [0, 2, 4, 7, 8, 10],
        "limit": [0, 2, 4, 5, 7, 9],
        "hash_step_s": 0,
        "do_sort": 0,
        "md5": 0,
        "hash": 0,
        "equival": 0,
        "later": [0, 4, 5, 8],
        "anoth": [0, 1, 4, 5],
        "machin": [0, 2, 7, 8],
        "granular": [0, 5],
        "whole": [0, 5, 6],
        "first": [0, 2, 4, 5, 6, 7, 8, 9],
        "code": [0, 1, 3, 4, 5, 7],
        "doubl": 0,
        "hexadecim": 0,
        "titl": [0, 4, 5, 6],
        "max_weight": 0,
        "circular": [0, 8],
        "visual": [0, 2, 4, 5, 6],
        "connect": [0, 2, 7, 8, 9],
        "accord": [0, 2, 4, 5, 7, 8],
        "implement": [0, 2, 5, 7],
        "red": [0, 4, 6],
        "edg": 0,
        "posit": [0, 4],
        "blue": [0, 4, 6],
        "neg": [0, 8],
        "node": 0,
        "grei": 0,
        "non": [0, 2, 4, 8],
        "ignor": [0, 1, 2, 4],
        "plot": [0, 2, 4, 5, 6, 8],
        "maximum": [0, 2, 4, 5, 7, 8, 9],
        "thick": 0,
        "num_bin": 0,
        "100": [0, 2, 4, 5, 7, 8, 9],
        "histogram": 0,
        "bin": 0,
        "bucket": 0,
        "target_valu": 0,
        "determin": [0, 2, 4, 5, 7, 8, 9],
        "interv": [0, 2, 7],
        "adapt": [0, 2, 5, 7],
        "linear_term_bit_precis": 0,
        "largest": 0,
        "just": [0, 1, 4],
        "below": [0, 4],
        "separ": [0, 7, 8],
        "among": [0, 5],
        "NOT": 0,
        "modifi": [0, 4, 5, 7],
        "inplac": 0,
        "els": [0, 4, 5, 6, 7, 8],
        "up": [0, 4, 5, 7],
        "sum_": [0, 1],
        "minimum": [0, 2, 4, 5, 6, 7, 8],
        "exactli": [0, 8],
        "absolut": [0, 2, 4, 8, 9],
        "like": [0, 4, 5, 8, 9],
        "4": [0, 1, 4, 5, 6, 7, 9],
        "off": [0, 2, 6, 7],
        "ob": [0, 5],
        "most": [0, 8],
        "filenam": [0, 2, 4, 5, 6, 7, 8],
        "load": [0, 4, 8, 9, 10],
        "dwavesystem": 0,
        "readonli": [0, 1, 2, 4, 5, 6, 7, 8],
        "select": [0, 2, 4, 5, 7, 8, 9],
        "flat": 0,
        "lambda_valu": [0, 10],
        "da": [0, 2, 7],
        "left": [0, 4, 5],
        "hand": [0, 5],
        "side": [0, 4, 5],
        "leq": 0,
        "necessarili": 0,
        "satisfi": [0, 7],
        "solut": [0, 2, 5, 7, 10],
        "larg": 0,
        "probabl": [0, 2, 7],
        "1_000_000_000": 0,
        "control": [0, 1, 2, 4, 5],
        "valid": [0, 1, 4, 7, 9],
        "violat": [0, 7],
        "boolean": [0, 5, 6],
        "accordingli": [0, 4, 5, 8],
        "shorter": [0, 4],
        "remain": [0, 4],
        "similarli": [0, 5, 7],
        "assum": [0, 4],
        "part": [0, 2, 4, 6, 7],
        "treat": 0,
        "longer": 0,
        "One": [0, 4, 8],
        "1000000000": 0,
        "makequbo_precis": [0, 10],
        "left_qubo": [0, 10],
        "sign": [0, 9, 10],
        "inequalitysign": [0, 10],
        "right_qubo": [0, 10],
        "contrast": 0,
        "express": [0, 1, 4, 5, 8],
        "along": [0, 2, 4, 7],
        "right": [0, 4],
        "decid": [0, 2, 4],
        "mathrm": 0,
        "_qubo": 0,
        "geq": 0,
        "mainli": [0, 4],
        "overload": [0, 5],
        "__ge__": 0,
        "__le__": 0,
        "qubo1": 0,
        "qubo2": 0,
        "nbsp": [0, 1, 2, 4, 5, 6, 7, 9],
        "Ising": 0,
        "over": [0, 2, 4, 5],
        "mani": [0, 2, 4, 5, 7],
        "common": [0, 1, 2, 4, 7, 8],
        "abstract": [0, 2, 7],
        "_pol": 0,
        "main": [0, 1, 4, 5, 8],
        "note": [0, 5],
        "concept": 0,
        "appli": [0, 2, 4, 5, 6, 7, 9],
        "sai": 0,
        "y_i": 0,
        "x_i": 0,
        "substitut": 0,
        "5": [0, 1, 2, 4, 5, 7, 8, 9],
        "paragraph": 0,
        "about": [0, 3, 6],
        "introduc": 0,
        "var_def": 0,
        "one_hot_group": 0,
        "lai": 0,
        "sequenc": [0, 2],
        "disjoint": [0, 8],
        "multidimension": [0, 6],
        "scheme": 0,
        "retriev": [0, 2, 4, 5, 6, 7, 8],
        "read": [0, 4, 5, 7, 8],
        "uniqu": [0, 7, 8],
        "thei": [0, 4, 5],
        "duplic": 0,
        "termin": [0, 2, 7, 8],
        "execut": [0, 4, 5, 6, 7],
        "except": [0, 5, 10],
        "no_wai": [0, 9],
        "wrong": 0,
        "discontinu": 0,
        "across": 0,
        "done": [0, 4, 5, 7, 8],
        "index_filt": 0,
        "And": 0,
        "filter": [0, 4, 5, 7],
        "could": [0, 4, 5, 6],
        "accept": [0, 2, 4, 7],
        "dimens": [0, 4, 6],
        "abov": [0, 2, 4, 5, 7, 8, 9],
        "technic": 0,
        "locat": [0, 8, 9],
        "ascend": 0,
        "begin": [0, 7],
        "explain": 0,
        "var": 0,
        "constant_bit": 0,
        "onehot": [0, 7, 8, 10],
        "call_back": [0, 6, 10],
        "axis_nam": [0, 6],
        "index_offset": 0,
        "insid": [0, 2, 4, 5, 7],
        "organ": 0,
        "int8": 0,
        "itself": [0, 4],
        "sent": [0, 2, 4, 5, 7, 8],
        "solver": [0, 2, 4, 5, 6, 8, 9, 10],
        "attach": [0, 2],
        "solution_solutionlist": [0, 6, 7],
        "bitarrai": [0, 10],
        "extract_bit_arrai": [0, 10],
        "match": [0, 4, 6],
        "characterist": 0,
        "belong": [0, 5, 8],
        "variat": 0,
        "last": [0, 2, 4, 7, 9],
        "everi": [0, 2, 4, 5, 7],
        "column": [0, 4, 5, 10],
        "axi": [0, 2, 4, 6],
        "previou": 0,
        "routin": [0, 5, 6],
        "categor": [0, 5],
        "numer": [0, 4, 5],
        "realiz": [0, 2, 4, 6],
        "omit": 0,
        "includ": [0, 4, 5, 7],
        "exclud": 0,
        "base10": [0, 9],
        "next": [0, 2, 7],
        "299": 0,
        "awai": [0, 2],
        "9": [0, 1, 2, 4, 5, 6],
        "90": 0,
        "third": [0, 4, 5],
        "200": [0, 5, 7],
        "l_": 0,
        "lfloor": 0,
        "frac": 0,
        "log_": 0,
        "rfloor": 0,
        "y_l": 0,
        "k": 0,
        "m": 0,
        "l": [0, 4],
        "y_": 0,
        "b": [0, 4],
        "a_": 0,
        "need": [0, 2, 4, 5, 6, 7, 8, 9],
        "h_": 0,
        "yconstraint": 0,
        "here": [0, 4, 5, 8, 9],
        "we": [0, 2, 3, 4, 7, 8],
        "show": [0, 4, 5, 6],
        "mathbb": 0,
        "z": [0, 1, 4],
        "back": [0, 5, 6, 8, 9],
        "li": 0,
        "turn": 0,
        "lceil": 0,
        "rceil": 0,
        "No": [0, 2, 5, 7, 9],
        "make": [0, 2, 4, 5],
        "fibonacci": [0, 1, 9],
        "log": [0, 2, 4, 7, 9, 10],
        "sqrt": 0,
        "phi": 0,
        "smallest": 0,
        "gauss": 0,
        "summat": 0,
        "formula": 0,
        "littl": 0,
        "8": 0,
        "sequenti": [0, 1, 2, 7, 9],
        "ensur": [0, 8],
        "taken": [0, 2, 4, 6, 7],
        "account": [0, 2, 4, 7, 8],
        "unari": [0, 1, 9],
        "auto_fill_cold_bit": 0,
        "algorithm": [0, 2, 5, 7, 8],
        "temper": [0, 2, 7, 9],
        "flatten": 0,
        "level": [0, 1, 5, 6, 8, 9],
        "offset": [0, 2, 6, 7],
        "directli": [0, 2, 4, 5, 7, 8],
        "known": [0, 2, 7],
        "do": [0, 4],
        "adjust": [0, 2, 5, 7],
        "global": [0, 2, 7],
        "consider": 0,
        "two_hot": 0,
        "build": [0, 4, 5, 8],
        "rule": 0,
        "dure": [0, 2, 4, 5, 6, 7, 8],
        "typeerror": [0, 8],
        "relat": [0, 2, 4, 6, 7],
        "cold": 0,
        "were": [0, 5],
        "alreadi": [0, 4, 7, 8],
        "user": [0, 2, 4, 5, 6, 7, 8, 9],
        "fill": [0, 4],
        "randomli": [0, 2, 7],
        "align": 0,
        "random": [0, 2, 7],
        "python": [0, 1, 2, 4, 7, 8, 9],
        "thrown": [0, 9],
        "castabl": 0,
        "obtain": [0, 7],
        "coordin": [0, 4, 8],
        "pass": [0, 4, 5, 6],
        "switch": [0, 2, 5, 7],
        "set_bit_tupl": 0,
        "built": [0, 4, 5],
        "floor": 0,
        "achiev": [0, 4, 5, 7],
        "request": [0, 2, 4, 5, 7, 8, 9],
        "admiss": [0, 5, 8],
        "discret": 0,
        "approxim": 0,
        "best": [0, 2, 7, 9],
        "fit": [0, 5],
        "math": 0,
        "ceil": 0,
        "smaller": [0, 2],
        "bigger": [0, 5, 7, 9],
        "closest": 0,
        "set_slack_tupl": 0,
        "sever": [0, 5, 7],
        "least": [0, 9],
        "upper_limit": [0, 7, 10],
        "sampl": [0, 2, 5, 7, 9, 10],
        "final": [0, 4, 5, 6, 7],
        "member": [0, 4, 8],
        "penalty_qubo": [0, 2, 6, 7, 8, 10],
        "simpl": [0, 1, 2, 4, 5, 7, 8, 9],
        "hdf5": [0, 7],
        "dav3": [0, 2, 4, 5, 6, 7],
        "fjj": 0,
        "verbos": [0, 2, 4, 7, 8, 9],
        "save": [0, 4, 5, 7, 8],
        "summari": [0, 4, 5],
        "slack_typ": 0,
        "slacktyp": [0, 6, 10],
        "cr": 0,
        "w_coef": 0,
        "w_irow": 0,
        "w_jcol": 0,
        "lambda": [0, 4],
        "bia": 0,
        "sourc": [1, 4, 5, 10],
        "defin": [1, 2, 4, 5, 7, 8, 9, 10],
        "binari": [1, 2, 3, 7, 9, 10],
        "variabl": [1, 3, 4, 6, 7, 9, 10],
        "readabl": [1, 7],
        "The": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "purpos": [1, 7],
        "script": [1, 5],
        "binpol": [1, 2, 6, 7, 8, 10],
        "w": [1, 2, 7, 9],
        "bit_arrai": 1,
        "bit_factor": 1,
        "bit_prod": 1,
        "bit_mlt": 1,
        "bit_div": 1,
        "bit_nam": 1,
        "poly_term": 1,
        "add": [1, 5, 10],
        "sub": [1, 2, 4, 6, 7],
        "poly_factor": 1,
        "mlt": 1,
        "div": 1,
        "bit_var": 1,
        "sum": [1, 4, 5, 10],
        "exp": [1, 2],
        "poly_brc": 1,
        "term": [1, 4, 5, 10],
        "var_nam": [1, 4],
        "slack_nam": 1,
        "var_imp": 1,
        "mod": 1,
        "var_arrai": 1,
        "brc": 1,
        "za": 1,
        "9a": 1,
        "z_": 1,
        "i_1": 1,
        "i_2": 1,
        "textbf": 1,
        "_": [1, 4, 5],
        "c_": 1,
        "anchor": 1,
        "pars": [1, 8],
        "text": [1, 4, 5, 8, 9],
        "tree": [1, 8, 10],
        "param": [1, 5, 9],
        "indent": [1, 4, 8],
        "prettifi": 1,
        "pretti": [1, 4, 8],
        "function_nam": 1,
        "gen_poli": 1,
        "indent_level": [1, 4],
        "function": [1, 5, 6, 10],
        "blank": [1, 4],
        "per": [1, 2, 5, 6, 7],
        "depth": 1,
        "optimization_method": [2, 7],
        "number_iter": [2, 7],
        "number_run": [2, 7],
        "number_replica": [2, 7],
        "temperature_start": [2, 5, 7, 9],
        "temperature_end": [2, 7, 9],
        "temperature_mod": [2, 7],
        "temperature_interv": [2, 7],
        "temperature_decai": [2, 7],
        "offset_increase_r": [2, 7, 9],
        "pt_temperature_model": [2, 7],
        "pt_replica_exchange_model": [2, 7],
        "solution_mod": [2, 7],
        "graphic": [2, 5, 6, 7, 9],
        "graphicsdetail": [2, 7, 10],
        "parallel_temp": [2, 7, 9],
        "gui": [2, 3, 4, 5, 7, 8, 9],
        "total": [2, 5, 6, 7, 8],
        "stochast": [2, 7],
        "independ": [2, 7, 8],
        "replica": [2, 7],
        "temperatur": [2, 7, 9],
        "cool": [2, 7],
        "curv": [2, 4, 5, 7],
        "exponenti": [2, 7],
        "_decai": [2, 7],
        "invers": [2, 7],
        "inverse_root": [2, 7],
        "mode": [2, 4, 5, 7, 9],
        "keep": [2, 7],
        "decai": [2, 7],
        "dynam": [2, 7],
        "bit": [2, 3, 5, 6, 7, 9, 10],
        "energi": [2, 5, 6, 7, 10],
        "featur": [2, 7],
        "rate": [2, 7],
        "furnac": [2, 7],
        "distribut": [2, 7],
        "exchang": [2, 7],
        "how": [2, 4, 6, 7, 8],
        "quick": [2, 7, 9],
        "overal": [2, 7, 8, 9],
        "plot_temperature_curv": 2,
        "5000": 2,
        "figsiz": [2, 4, 5, 6, 8, 10],
        "dpi": [2, 8],
        "300": [2, 8],
        "figur": [2, 4, 5, 6, 8],
        "inch": [2, 4, 6, 8],
        "png": [2, 6, 8],
        "imag": [2, 8],
        "resolut": [2, 8],
        "temperature_mode_txt": 2,
        "time_limit_sec": [2, 5, 7],
        "target_energi": [2, 7],
        "num_group": [2, 7],
        "num_solut": [2, 7],
        "num_output_solut": [2, 7],
        "gs_num_iteration_factor": [2, 7],
        "gs_num_iteration_cl": [2, 7],
        "gs_penalty_auto_mod": [2, 7],
        "gs_penalty_coef": [2, 7],
        "gs_penalty_inc_r": [2, 7],
        "gs_max_penalty_coef": [2, 7],
        "sec": [2, 4, 7, 8],
        "fast": [2, 7],
        "exit": [2, 7],
        "max": [2, 4, 7, 10],
        "lower": [2, 4, 5, 7],
        "min": [2, 4, 7, 10],
        "target": [2, 5, 7, 8],
        "maintain": [2, 7],
        "updat": [2, 4, 5, 7, 8],
        "epoch": [2, 7],
        "search": [2, 3, 4, 5, 6, 7, 8, 10],
        "improv": [2, 3, 7],
        "continu": [2, 5, 7],
        "veri": [2, 5, 7, 8],
        "deep": [2, 7],
        "local": [2, 7, 8, 9],
        "low": [2, 7],
        "cutoff": [2, 7],
        "whether": [2, 4, 7],
        "polynomi": [2, 3, 4, 5, 6, 7, 10],
        "multipli": [2, 4, 7, 9, 10],
        "repeatedli": [2, 7],
        "reach": [2, 4, 7],
        "auto": [2, 7, 9],
        "63": [2, 7],
        "ohs_xw1h_internal_penalti": [2, 7],
        "gs_ohs_xw1h_num_iteration_factor": [2, 7],
        "gs_ohs_xw1h_num_iteration_cl": [2, 7],
        "dav4": [2, 5, 7],
        "1hot": [2, 7],
        "1wai": [2, 7],
        "2wai": [2, 7],
        "connection_method": [2, 7, 8],
        "annealer_protocol": [2, 7, 8],
        "annealer_address": [2, 7, 8],
        "annealer_port": [2, 7, 8],
        "8080": [2, 7, 8],
        "annealer_path": [2, 7, 8],
        "rest_version_enforc": [2, 7, 8],
        "request_mod": [2, 7, 8],
        "requestmod": [2, 7, 8, 10],
        "stream": [2, 7, 8, 9],
        "storage_account_typ": [2, 7, 8],
        "storageaccounttyp": [2, 7, 8, 10],
        "noth": [2, 5, 7, 8, 9],
        "storage_account_nam": [2, 7, 8],
        "storage_connection_str": [2, 7, 8],
        "sas_token": [2, 7, 8],
        "container_nam": [2, 7, 8],
        "prolog_filenam": [2, 7, 8],
        "prolog": [2, 7, 8, 10],
        "prolog_blob_nam": [2, 7, 8],
        "qubo_filenam": [2, 7, 8],
        "qubo_blob_nam": [2, 7, 8],
        "penalty_qubo_filenam": [2, 7, 8],
        "penalty_qubo_blob_nam": [2, 7, 8],
        "inequalities_filenam": [2, 7, 8],
        "inequ": [2, 6, 7, 8, 9, 10],
        "inequalities_blob_nam": [2, 7, 8],
        "api_kei": [2, 7, 8],
        "clientid": [2, 7, 8],
        "clientsecret": [2, 7, 8],
        "audienc": [2, 7, 8],
        "domain": [2, 7, 8],
        "annealer_queue_s": [2, 7, 8],
        "proxi": [2, 7, 8],
        "proxy_port": [2, 7, 8],
        "81": [2, 7, 8],
        "proxy_us": [2, 7, 8],
        "proxy_password": [2, 7, 8],
        "timeout": [2, 7, 8],
        "1800": [2, 7, 8],
        "ssl_verifi": [2, 7, 8],
        "ssl_disable_warn": [2, 7, 8],
        "offline_request_fil": [2, 7],
        "offline_response_fil": [2, 7],
        "connection_mod": [2, 7],
        "async": [2, 7],
        "protocol": [2, 7, 8],
        "authent": [2, 7, 8],
        "oauth": [2, 7, 8, 9],
        "setannealerprofil": [2, 8, 10],
        "system": [2, 4, 5, 7, 8],
        "interfac": [2, 4, 7, 8],
        "ip": [2, 7, 8],
        "host": [2, 7, 8],
        "port": [2, 7, 8],
        "path": [2, 4, 5, 7, 8, 10],
        "prefix": [2, 7, 8],
        "root": [2, 7, 8],
        "product": [2, 5, 7, 8, 10],
        "irrespect": [2, 7],
        "fujitsu": [2, 3, 7],
        "commun": [2, 7],
        "commerci": [2, 7],
        "gzip": [2, 7, 8, 9],
        "classic": [2, 7, 8, 9],
        "client": [2, 7, 8, 9],
        "httpconnect": [2, 7, 8, 9],
        "send": [2, 7, 8, 9],
        "brotli": [2, 7, 8, 9],
        "experiment": [2, 7, 8, 9, 10],
        "stream_verbos": [2, 7, 8, 9],
        "101": [2, 7, 8, 9],
        "simple_verbos": [2, 7, 8, 9],
        "102": [2, 7, 8, 9],
        "gzip_verbos": [2, 7, 8, 9],
        "103": [2, 7, 8, 9],
        "brotli_verbos": [2, 7, 8, 9],
        "storag": [2, 7, 8, 9],
        "azure_blob": [2, 7, 8, 9],
        "azur": [2, 4, 7, 8],
        "blob": [2, 4, 8, 10],
        "instal": [2, 7, 8, 9],
        "packag": [2, 7, 8],
        "azure_blob_cmd": [2, 7, 8, 9],
        "commandlin": [2, 5, 7, 8],
        "network": [2, 7, 8],
        "sa": [2, 7],
        "token": [2, 7],
        "debug": [2, 4, 5, 7, 8, 9],
        "web": [2, 4, 7, 8],
        "identif": [2, 7],
        "auth0": [2, 7],
        "secret": [2, 7, 8],
        "queue": [2, 4, 7, 8],
        "server": [2, 4, 7, 8],
        "password": [2, 7, 8],
        "18": [2, 7],
        "000sec": [2, 7],
        "hour": [2, 4, 7],
        "disabl": [2, 4, 5, 7, 8, 10],
        "ssl": [2, 7, 8],
        "verif": [2, 7, 8],
        "respons": [2, 7],
        "job": [2, 10],
        "subsequ": [2, 4, 7],
        "poll": [2, 7],
        "wait": [2, 7],
        "sync": [2, 7],
        "ignore_proxi": 2,
        "replica_exchange_count": 2,
        "furnace_process_length": 2,
        "replica_histori": 2,
        "number_of_walk": 2,
        "number_of_bit": 2,
        "wait_cycl": 2,
        "bit_flip": 2,
        "number_of_hil": 2,
        "hill_step": 2,
        "hill_energi": 2,
        "number_of_vallei": 2,
        "valley_step": 2,
        "valley_energi": 2,
        "min_step": 2,
        "min_energi": 2,
        "emul": [2, 5, 7],
        "visit": [2, 8],
        "solv": [2, 4, 5, 7, 8],
        "record": [2, 4, 5],
        "cycl": [2, 4],
        "flip": [2, 6],
        "inform": [2, 4, 5, 6, 7, 9],
        "hill": 2,
        "occur": 2,
        "top": [2, 5],
        "vallei": 2,
        "plot_graph": 2,
        "center_in_step": 2,
        "center_in_perc": 2,
        "center_in_minimum_energi": 2,
        "width_in_step": 2,
        "width_in_perc": 2,
        "selected_run": 2,
        "qubosolveremul": [2, 10],
        "center": 2,
        "50": [2, 5],
        "percent": [2, 7],
        "percentag": 2,
        "viewport": 2,
        "plt": 2,
        "shown": [2, 4, 5, 6, 9],
        "notebook": [2, 4, 5, 6],
        "auto_tun": [2, 7],
        "autotun": [2, 7, 10],
        "scaling_factor": [2, 7, 9],
        "scaling_bit_precis": [2, 7, 9],
        "start_progress_prob": [2, 7],
        "end_progress_prob": [2, 7],
        "annealing_step": [2, 7],
        "sampling_walk_count": [2, 7],
        "sampling_walk_length": [2, 7],
        "sampling_dist": [2, 7],
        "tune": [2, 5, 6, 7, 9],
        "scale": [2, 4, 7, 9, 10],
        "action": [2, 4, 5, 7, 9],
        "auto_sc": [2, 7, 9],
        "t": [2, 4, 7, 8, 9],
        "auto_scaling_and_sampl": [2, 7, 9],
        "tuning_method": 2,
        "worsen": [2, 7],
        "half": [2, 7],
        "portion": [2, 7],
        "delta": [2, 7],
        "procedur": [2, 5, 7],
        "estim": [2, 7],
        "walker": [2, 7],
        "ham": [2, 7],
        "distanc": [2, 7, 8],
        "progress": [2, 3, 4, 5, 6, 7],
        "logger": [2, 7],
        "measur": [2, 4, 5, 9],
        "normal": [2, 4, 5, 9, 10],
        "who": 2,
        "duration_account_occupi": 2,
        "timedelta": [2, 4, 6, 7],
        "durat": [2, 4, 5, 7],
        "associ": [2, 5, 6],
        "keyword_account_occupied_tim": 2,
        "duration_ann": 2,
        "keyword_anneal_tim": 2,
        "duration_cpu": 2,
        "keyword_cpu_tim": 2,
        "duration_dau_servic": 2,
        "keyword_dau_service_tim": 2,
        "duration_elaps": 2,
        "keyword_elapsed_tim": 2,
        "duration_execut": 2,
        "keyword_execution_tim": 2,
        "duration_occupi": 2,
        "keyword_occupied_tim": 2,
        "duration_parse_respons": 2,
        "keyword_parse_response_tim": 2,
        "duration_prepare_qubo": 2,
        "keyword_prepare_qubo_tim": 2,
        "duration_prepare_request": 2,
        "keyword_prepare_request_tim": 2,
        "duration_queu": 2,
        "keyword_queue_tim": 2,
        "duration_receive_respons": 2,
        "keyword_receive_response_tim": 2,
        "duration_save_bqp": 2,
        "keyword_save_bqp_tim": 2,
        "duration_save_request": 2,
        "keyword_save_request_tim": 2,
        "duration_save_respons": 2,
        "keyword_save_response_tim": 2,
        "duration_send_request": 2,
        "keyword_send_request_tim": 2,
        "duration_solv": 2,
        "keyword_solve_tim": 2,
        "duration_tun": 2,
        "keyword_tuning_tim": 2,
        "duration_wait": 2,
        "keyword_waiting_tim": 2,
        "duration_waiting_2_finish": 2,
        "keyword_waiting_2_finish_tim": 2,
        "duration_waiting_2_start": 2,
        "keyword_waiting_2_start_tim": 2,
        "end_account_occupi": 2,
        "datetim": [2, 4, 6, 7],
        "timestamp": [2, 5],
        "end_ann": 2,
        "end_cpu": 2,
        "end_dau_servic": 2,
        "end_elaps": 2,
        "end_execut": 2,
        "end_occupi": 2,
        "end_parse_respons": 2,
        "end_prepare_qubo": 2,
        "end_prepare_request": 2,
        "end_queu": 2,
        "end_receive_respons": 2,
        "end_save_bqp": 2,
        "end_save_request": 2,
        "end_save_respons": 2,
        "end_send_request": 2,
        "end_solv": 2,
        "end_tun": 2,
        "end_wait": 2,
        "end_waiting_2_finish": 2,
        "end_waiting_2_start": 2,
        "start_account_occupi": 2,
        "start_ann": 2,
        "start_cpu": 2,
        "start_dau_servic": 2,
        "start_elaps": 2,
        "start_execut": 2,
        "start_occupi": 2,
        "start_parse_respons": 2,
        "start_prepare_qubo": 2,
        "start_prepare_request": 2,
        "start_queu": 2,
        "start_receive_respons": 2,
        "start_save_bqp": 2,
        "start_save_request": 2,
        "start_save_respons": 2,
        "start_send_request": 2,
        "start_solv": 2,
        "start_tun": 2,
        "start_wait": 2,
        "start_waiting_2_finish": 2,
        "start_waiting_2_start": 2,
        "temperature_model": 2,
        "replica_exchange_model": 2,
        "manag": [2, 3, 4, 8],
        "comput": [2, 8, 10],
        "bookkeep": 2,
        "strategi": 2,
        "swap": 2,
        "track": [2, 4, 5, 7],
        "histori": 2,
        "generate_replica_furnace_exchange_step": 2,
        "energy_list": 2,
        "reorgan": 2,
        "inher": 2,
        "structur": [2, 4, 5, 6, 8, 10],
        "histor": 2,
        "consecut": 2,
        "onc": [2, 4, 8],
        "outer": 2,
        "loop": [2, 4],
        "replica_furnace_histori": 2,
        "replica_temperature_list": 2,
        "temperature_list": 2,
        "descend": 2,
        "furnace_replica_list": 2,
        "furnaces_replica_histori": 2,
        "replica_furnace_list": 2,
        "ly": 2,
        "temperature_monotonicity_check": 2,
        "monoton": 2,
        "decreas": [2, 7],
        "replica_count": 2,
        "temperature_high": 2,
        "temperature_low": 2,
        "quotient": 2,
        "randomwalk_count": 2,
        "randomwalk_length": 2,
        "1000": [2, 5, 7],
        "fix_point_precis": 2,
        "1e": 2,
        "05": 2,
        "max_fixpoint_iter": 2,
        "temperature_adjustment_count": 2,
        "statist": [2, 6],
        "neighbor": [2, 7],
        "j": 2,
        "p_ex": 2,
        "e_i": 2,
        "e_j": 2,
        "t_i": 2,
        "t_j": 2,
        "correct": 2,
        "interpol": 2,
        "count": [2, 4, 8],
        "fixpoint": 2,
        "walk": [2, 7],
        "boltzmann": 2,
        "criteria": 2,
        "experi": 2,
        "sampler": 2,
        "basi": [2, 8],
        "do_sampl": 2,
        "furnace_mean_energy_list": 2,
        "averag": [2, 4],
        "basic": 2,
        "prepar": [2, 4, 5],
        "mean_abs_energy_delta": 2,
        "mean_escape_energi": 2,
        "escap": [2, 7, 8],
        "act": 2,
        "util": [2, 10],
        "welcom": 3,
        "develop": [3, 5, 9],
        "kit": 3,
        "you": [3, 4, 5, 7, 8],
        "understand": 3,
        "still": [3, 4, 7],
        "find": [3, 4, 5, 7],
        "gap": 3,
        "sorri": 3,
        "write": [3, 4, 7, 8],
        "easier": 3,
        "space": [3, 6, 9, 10],
        "jupytertool": [3, 7, 10],
        "framework": [3, 4, 5, 7],
        "tutori": [3, 5],
        "www": 3,
        "de": 3,
        "theme": 3,
        "digitalanneal": 3,
        "get": [3, 5, 8],
        "access_profile_fil": [4, 7, 8],
        "widget": [4, 5, 8, 9],
        "profil": [4, 5, 7, 8],
        "use_access_profil": [4, 7],
        "kwarg": [4, 5, 6, 7],
        "date": [4, 9],
        "6": 4,
        "field": [4, 5, 6, 7, 9],
        "year": 4,
        "month": 4,
        "dai": [4, 8],
        "label": [4, 5, 6, 10],
        "tooltip": 4,
        "visualis": 4,
        "style": 4,
        "layout": 4,
        "border": 4,
        "header": [4, 10],
        "row_label": [4, 10],
        "visibl": [4, 5, 9, 10],
        "directori": [4, 5, 7, 8, 9],
        "fulli": [4, 8],
        "qualifi": [4, 8],
        "full": [4, 8],
        "rel": [4, 5, 7, 8],
        "decis": 4,
        "description_tooltip": 4,
        "silent": [4, 8, 10],
        "suppress": 4,
        "setter": 4,
        "suffix": 4,
        "regular": [4, 5, 8],
        "handl": [4, 5, 8, 9],
        "insensit": 4,
        "upon": [4, 5],
        "redirect": 4,
        "deprec": [4, 5],
        "on_change_cod": [4, 10],
        "on_chang": 4,
        "explicitli": 4,
        "x_column": 4,
        "y_column": 4,
        "selection_set": 4,
        "add_figure_button": 4,
        "left_axi": 4,
        "right_axi": 4,
        "item": [4, 8],
        "y_colum": 4,
        "button": [4, 5],
        "click": [4, 5],
        "ax": 4,
        "label_offset": 4,
        "content": [4, 5, 8],
        "paint": 4,
        "them": 4,
        "behaviour": [4, 5],
        "50px": 4,
        "ab": 4,
        "freez": 4,
        "choic": 4,
        "immedi": [4, 5],
        "cell": [4, 5],
        "frozen": 4,
        "perman": 4,
        "dummi": 4,
        "panel": 4,
        "css_style": 4,
        "type_convert": 4,
        "summary_definit": 4,
        "download": [4, 5, 7],
        "file_nam": [4, 7, 8],
        "my_tabl": 4,
        "transform": [4, 8],
        "wise": [4, 5],
        "col_head": 4,
        "background": 4,
        "color": [4, 8],
        "miss": 4,
        "highlight": [4, 8],
        "oper": [4, 7, 10],
        "green": 4,
        "arg_typ": 4,
        "black": 4,
        "avg": 4,
        "len": 4,
        "css": 4,
        "csv": [4, 6],
        "displayfmt": 4,
        "markdown": 4,
        "jupyt": [4, 5],
        "tablefmt": [4, 7],
        "tabul": [4, 7, 9],
        "github": 4,
        "grid": 4,
        "fancy_grid": 4,
        "pipe": 4,
        "orgtbl": 4,
        "jira": 4,
        "presto": 4,
        "psql": [4, 7],
        "rst": 4,
        "mediawiki": 4,
        "moinmoin": 4,
        "youtrack": 4,
        "unsafehtml": 4,
        "latex_raw": 4,
        "latex_booktab": 4,
        "latex_longt": 4,
        "textil": 4,
        "tsv": 4,
        "new_data": 4,
        "name_title_pair": 4,
        "context": [4, 5],
        "tab_nam": 4,
        "is_vis": 4,
        "statu": [4, 7, 8],
        "tab_out": [4, 10],
        "var_valu": [4, 5],
        "var_fil": 4,
        "figure_height": 4,
        "500px": 4,
        "figure_width": 4,
        "get_persistent_tag": 4,
        "set_persistent_tag": 4,
        "facilit": 4,
        "seri": [4, 5],
        "test": [4, 5, 7, 8],
        "pareto": [4, 10],
        "hold": 4,
        "modul": 4,
        "pareto_data": 4,
        "dao": [4, 5],
        "px": 4,
        "callback": [4, 7],
        "tag": [4, 5],
        "persist": [4, 5],
        "don": [4, 9],
        "app": 4,
        "handler": 4,
        "launch": 4,
        "editor": 4,
        "pseudocod": 4,
        "rapid": 4,
        "prototyp": [4, 5],
        "notat": 4,
        "tool": [4, 10],
        "before_upd": 4,
        "after_upd": 4,
        "two_line_cr": 4,
        "creator": [4, 10],
        "applier": [4, 10],
        "delet": [4, 5, 7, 8],
        "press": [4, 5, 8],
        "icon": 4,
        "exist": [4, 6, 7, 8],
        "trash": 4,
        "remov": [4, 7, 8],
        "get_persistent_data": 4,
        "opposit": 4,
        "direct": [4, 9],
        "everytim": 4,
        "ptional": 4,
        "text_width": 4,
        "short": 4,
        "stopwatch": 4,
        "elaps": 4,
        "build_qubo": [4, 10],
        "watch": 4,
        "print": [4, 5, 6, 8, 9],
        "rsp": 4,
        "charact": [4, 8],
        "explan": 4,
        "topic": 4,
        "comment": 4,
        "fact": 4,
        "own": [4, 9],
        "out": [4, 9],
        "bracket": 4,
        "indent_width": 4,
        "instanti": [4, 5, 6],
        "id": [4, 7, 8, 9],
        "batch_mod": [4, 5, 7],
        "tracker": [4, 5],
        "long": [4, 7],
        "intermedi": 4,
        "3d": [4, 6],
        "travers": 4,
        "activ": [4, 9],
        "0xffffff": 4,
        "henc": 4,
        "opac": 4,
        "render": 4,
        "matplotlib": [4, 6, 8],
        "three": [4, 5, 7],
        "dim": 4,
        "boundedfloattext": 4,
        "horizont": [4, 7],
        "arrang": 4,
        "boundedinttext": 4,
        "cannot": [4, 5, 8],
        "bound": [4, 5],
        "widget_class": 4,
        "nest": [4, 5, 6],
        "compon": [4, 7],
        "applic": 4,
        "wigdet": 4,
        "mandatori": 4,
        "a_1": 4,
        "hide": [4, 5],
        "invis": 4,
        "manadatori": 4,
        "logarithm": 4,
        "2f": 4,
        "tupel": 4,
        "text_area": 4,
        "multi": [4, 5],
        "int_bound": 4,
        "int_slid": 4,
        "slider": 4,
        "int_range_slid": 4,
        "int_arrai": 4,
        "rectangular": 4,
        "float_bound": 4,
        "float_slid": 4,
        "float_log_slid": 4,
        "float_range_slid": 4,
        "float_arrai": 4,
        "select_multipl": 4,
        "select_slid": 4,
        "select_range_slid": 4,
        "radio": 4,
        "file_selector": 4,
        "directory_selector": 4,
        "date_pick": 4,
        "time_pick": 4,
        "minut": 4,
        "color_pick": 4,
        "spinner": 4,
        "now": 4,
        "shirt": 4,
        "accordion": 4,
        "usual": [4, 6],
        "your": 4,
        "begin_group": 4,
        "end_group": 4,
        "pleas": [4, 5],
        "notic": 4,
        "seen": 4,
        "drive": [4, 5],
        "mark": 4,
        "checkbox": 4,
        "custom": [4, 8],
        "regist": [4, 7, 8, 9],
        "mycustomwidget": 4,
        "mycustomwidgetrefer": 4,
        "Then": [4, 5],
        "filter_by_tag": 4,
        "fixed_paramet": 4,
        "persistent_set": 4,
        "hierarchi": 4,
        "parameter_definit": [4, 5],
        "made": [4, 8],
        "read_onli": [4, 5],
        "block": 4,
        "preserv": 4,
        "update_gui": 4,
        "break_after_stat": 4,
        "interrupt": [4, 5, 8],
        "resum": 4,
        "finish": [4, 7],
        "changeabl": 4,
        "batch": [4, 5, 9, 10],
        "parameter_log": [4, 5, 10],
        "parameterlog": [4, 5, 10],
        "_constant": [4, 7, 9],
        "dialog": 4,
        "persistent_read_funct": 4,
        "proper": 4,
        "decod": [4, 8],
        "persistent_write_funct": 4,
        "execution_time_receiv": 4,
        "result_receiv": 4,
        "__init__": 4,
        "breakpoint": [4, 5],
        "multiple_output": 4,
        "Will": [4, 6],
        "compose_model": [4, 5, 9],
        "optimizermodel": [4, 10],
        "before_call_funct": 4,
        "wrapper_funct": 4,
        "wrapper": [4, 5, 6, 9],
        "around": 4,
        "call_displai": 4,
        "tab_width_perc": 4,
        "optimizer_model": [4, 5],
        "static": 4,
        "registered_nam": [4, 8],
        "registr": 4,
        "registri": [4, 8],
        "widget_in_and_out": 4,
        "_widgetinandout": 4,
        "propag": [4, 5],
        "correl": 4,
        "dedic": [4, 5],
        "link": 4,
        "reset": [4, 5, 8],
        "incl": [4, 5],
        "widget_nam": [4, 5],
        "widget_arg": 4,
        "child": 4,
        "edit": 4,
        "old": [4, 5, 9],
        "overview": [4, 5, 10],
        "subset": 4,
        "follow_up": 4,
        "0f": 4,
        "auto_start": 4,
        "info": [4, 6, 9],
        "danger": 4,
        "intro": 4,
        "bar": [4, 5],
        "down": 4,
        "obligatori": 4,
        "countdown": 4,
        "front": 4,
        "2nd": 4,
        "ff": 4,
        "Their": 4,
        "becom": 4,
        "flavour": 4,
        "success": [4, 5, 6, 7],
        "disappear": 4,
        "immediate_run": 5,
        "immediate_load": 5,
        "through": 5,
        "auto_load": 5,
        "autoload": 5,
        "show_config": 5,
        "show_load": 5,
        "setup": 5,
        "scenario": 5,
        "show_compos": 5,
        "compos": [5, 10],
        "show_build": 5,
        "show_solv": 5,
        "show_track": 5,
        "show_report": 5,
        "show_visu": 5,
        "show_test": 5,
        "show_pareto": 5,
        "show_timeseri": 5,
        "show_optuna": 5,
        "qubo_hash_step_s": 5,
        "md5sum": 5,
        "stop_replay_on_error": 5,
        "replai": 5,
        "max_bit": [5, 9],
        "log_level": 5,
        "log_format": 5,
        "asctim": 5,
        "levelnam": 5,
        "overload_print": [5, 9],
        "thread": [5, 8, 9],
        "use_default_compose_model": 5,
        "development_mod": 5,
        "bodi": 5,
        "parser": 5,
        "load_paramet": 5,
        "compose_model_paramet": 5,
        "build_qubo_paramet": 5,
        "solver_paramet": 5,
        "time_track": 5,
        "anneal_track": 5,
        "timeseries_t": 5,
        "timeseries_plot": 5,
        "displai": [5, 6, 7, 10],
        "appear": 5,
        "pdf": 5,
        "coverag": 5,
        "draw": [5, 10],
        "valuewidget": 5,
        "tag_nam": 5,
        "widgetgui": [5, 10],
        "tri": 5,
        "regener": 5,
        "call_clear_output": 5,
        "optuna_set": 5,
        "qualiti": 5,
        "metric": 5,
        "studi": 5,
        "hp": 5,
        "earlier": 5,
        "vari": 5,
        "var_object": 5,
        "var_attribut": 5,
        "city_count": 5,
        "factor_a": 5,
        "20": 5,
        "1100": 5,
        "1200": 5,
        "800": 5,
        "700": 5,
        "span": 5,
        "cartesian": 5,
        "trial": 5,
        "base_dao_file_name_without_suffix": 5,
        "pickl": 5,
        "optuna_data": 5,
        "optimum": 5,
        "detect": [5, 8],
        "environ": 5,
        "scratch": 5,
        "no_gener": 5,
        "from_scratch": 5,
        "abl": 5,
        "pareto_set": 5,
        "examin": 5,
        "graph": [5, 6],
        "incomplet": 5,
        "recov": 5,
        "simultan": 5,
        "cartesian_product": 5,
        "27": 5,
        "recoveri": 5,
        "dao_path": 5,
        "dao_pattern": 5,
        "initial_select": 5,
        "dropdown": [5, 10],
        "On": [5, 7],
        "url": 5,
        "page": 5,
        "detail": [5, 7],
        "solve_templ": 5,
        "keyword_fixed_paramet": 5,
        "only_parameter_marked_as_calcul": 5,
        "timeseries_set": 5,
        "gui_compos": [5, 10],
        "composemodel": 5,
        "gui_load": [5, 10],
        "tab_build": [5, 10],
        "tab_compos": [5, 10],
        "tab_load": [5, 10],
        "tab_optuna": [5, 10],
        "tab_pareto": [5, 10],
        "tab_solv": [5, 10],
        "tab_timeseri": [5, 10],
        "tab_visu": [5, 10],
        "persistent_fil": 5,
        "model_data": 5,
        "profile_fil": 5,
        "load_titl": 5,
        "widgetdefinit": [5, 7, 10],
        "load_break_after_stat": 5,
        "load_on_cal": 5,
        "load_on_focu": 5,
        "load_requir": 5,
        "compose_model_titl": 5,
        "compose_model_toolbar_paramet": 5,
        "compose_model_break_after_stat": 5,
        "compose_model_on_cal": 5,
        "compose_model_on_focu": 5,
        "compose_model_requir": 5,
        "build_qubo_titl": 5,
        "build_qubo_toolbar_paramet": 5,
        "build_qubo_break_after_stat": 5,
        "build_qubo_on_cal": 5,
        "build_qubo_on_focu": 5,
        "build_qubo_requir": 5,
        "calculated_build_qubo_paramet": 5,
        "solve_titl": 5,
        "solve_toolbar_paramet": 5,
        "solve_on_focu": 5,
        "solve_requir": 5,
        "default_solver_paramet": 5,
        "calculated_solver_paramet": 5,
        "solve_prep_result": 5,
        "solve_processor": 5,
        "track_titl": 5,
        "track_toolbar_paramet": 5,
        "track_on_focu": 5,
        "track_requir": 5,
        "report_title_list": 5,
        "report_toolbar_parameter_list": 5,
        "report_on_focus_list": 5,
        "report_requirement_list": 5,
        "visualization_titl": 5,
        "visualization_toolbar_paramet": 5,
        "visualization_on_focu": 5,
        "visualization_requir": 5,
        "pareto_titl": 5,
        "pareto_toolbar_paramet": 5,
        "pareto_on_focu": 5,
        "pareto_requir": 5,
        "timeseries_titl": 5,
        "timeseries_toolbar_paramet": 5,
        "timeseries_on_focu": 5,
        "timeseries_requir": 5,
        "optuna_titl": 5,
        "optuna_toolbar_paramet": 5,
        "optuna_on_focu": 5,
        "optuna_requir": 5,
        "demo_solver_paramet": 5,
        "phase": 5,
        "mathemat": 5,
        "translat": [5, 6],
        "actual": [5, 7],
        "logic": 5,
        "dashboard": 5,
        "report_": 5,
        "excel": 5,
        "seper": 5,
        "want": 5,
        "necessari": 5,
        "wigget": 5,
        "parametr": 5,
        "exra": 5,
        "effort": 5,
        "thing": 5,
        "re": 5,
        "time_series_set": 5,
        "solve_paramet": 5,
        "enorm": 5,
        "alwai": [5, 7],
        "analysi": [5, 7],
        "min_servic": 5,
        "lambda_a": 5,
        "40000": 5,
        "70000": 5,
        "90000": 5,
        "500": 5,
        "900": 5,
        "15": 5,
        "25": 5,
        "leverag": 5,
        "hyperparamet": 5,
        "As": 5,
        "goal": 5,
        "real": 5,
        "xlsx": 5,
        "tile": 5,
        "focu": 5,
        "toolbar": 5,
        "max_tab_report": 5,
        "report1": 5,
        "report9": 5,
        "optuna_dirnam": [5, 10],
        "pareto_dirnam": [5, 10],
        "timeseries_dirnam": [5, 10],
        "build_qubo_templ": 5,
        "task": [5, 6],
        "time_seri": 5,
        "intiti": 5,
        "whenev": 5,
        "templat": 5,
        "keyword_on_cal": 5,
        "keyword_paramet": 5,
        "keyword_default_paramet": 5,
        "keyword_calculated_paramet": 5,
        "keyword_prep_result": 5,
        "_toolbar_paramet": 5,
        "on_click": 5,
        "event": [5, 8],
        "perform": [5, 6],
        "max_attempt": 5,
        "optimizermodelcomplexsolv": 5,
        "try": [5, 7],
        "again": 5,
        "af": 5,
        "annealing_log": [5, 10],
        "compose_log": [5, 10],
        "solve_dav2": [5, 10],
        "solve_dav3": [5, 10],
        "solve_dav3c": [5, 10],
        "dav3c": [5, 7],
        "solve_dav4": [5, 10],
        "solve_gui": [5, 10],
        "graphs_figs": [5, 10],
        "save_graph": [5, 10],
        "save_graphs_figs": [5, 10],
        "save_tim": [5, 10],
        "save_times_figs": [5, 10],
        "times_figs": [5, 10],
        "values_per_row": [5, 10],
        "legend": 5,
        "create_summary_excel": [5, 10],
        "excel_summary_column": [5, 10],
        "sheet": 5,
        "formular": 5,
        "insert": [5, 8, 9],
        "mb": 5,
        "log_memory_s": [5, 10],
        "memori": 5,
        "show_summari": [5, 10],
        "summary_column": [5, 10],
        "delete_fil": [5, 10],
        "newli": [5, 7],
        "filter_limit": [5, 7, 10],
        "_boundedintinputset": 5,
        "sample_s": [5, 7, 10],
        "_logintinputset": 5,
        "unique_sample_limit": [5, 7, 10],
        "store_graph": [5, 10],
        "button_width": [5, 10],
        "pixel": 5,
        "70": 5,
        "description_width": [5, 10],
        "170": 5,
        "widget_gui": 5,
        "enumer": [5, 9],
        "bit_array_shap": 6,
        "bitarrayshap": [6, 10],
        "notion": 6,
        "max_ax_per_row": 6,
        "subplotpar": 6,
        "axis_offset": 6,
        "dot": 6,
        "light": 6,
        "individu": 6,
        "subplot": 6,
        "unsort": 6,
        "resort": 6,
        "typ": 6,
        "subplotparam": 6,
        "pyplot": 6,
        "tick": 6,
        "standard": 6,
        "penalty_energi": [6, 10],
        "frequenc": 6,
        "varshapeset": [6, 8, 10],
        "adopt": 6,
        "penalty_binary_polynomi": 6,
        "extract": [6, 7],
        "stem": 6,
        "execution_tim": [6, 10],
        "anneal_tim": [6, 10],
        "graphics_data": 6,
        "graphicsdata": [6, 10],
        "stats_info": [6, 7],
        "connection_paramet": [6, 7, 10],
        "connectionparamet": [6, 7, 10],
        "da_paramet": [6, 7, 10],
        "tuning_paramet": [6, 7, 10],
        "tuningparamet": [6, 7, 10],
        "pure": 6,
        "number_of_sampl": 6,
        "truncat": 6,
        "coars": 6,
        "unravel": 6,
        "finest": 6,
        "csv_report": 6,
        "fig_report": 6,
        "keyword_progress": 6,
        "export": 6,
        "consumpt": 6,
        "variou": 6,
        "append": [6, 8, 9],
        "consum": 6,
        "dav2paramet": [6, 7, 10],
        "min_solut": [6, 10],
        "solver_tim": [6, 10],
        "solvertim": [6, 7, 10],
        "backward": 6,
        "v2": 7,
        "v3c": 7,
        "v4": 7,
        "cpu": 7,
        "8192": 7,
        "100000": 7,
        "1024": 7,
        "guidanc": 7,
        "config": 7,
        "polynom": 7,
        "1000000": 7,
        "26": 7,
        "99": 7,
        "01": 7,
        "guidance_config": 7,
        "partialconfig": [7, 10],
        "random_se": 7,
        "random_seed_incr": 7,
        "bqp_filenam": 7,
        "timeseries_max_bit": 7,
        "solver_max_bit": 7,
        "kept": 7,
        "declin": 7,
        "quicker": 7,
        "happen": 7,
        "candid": 7,
        "rapidli": 7,
        "overcom": 7,
        "situat": 7,
        "temporarili": 7,
        "stepwis": 7,
        "4096": 7,
        "2000000000": 7,
        "128": 7,
        "100000000000000000000": 7,
        "By": 7,
        "close": [7, 10],
        "accuraci": 7,
        "prf": [7, 8],
        "central": [7, 8],
        "seed": 7,
        "9999": 7,
        "bqp": [7, 10],
        "timeseri": [7, 10],
        "box": 7,
        "cancel_job": 7,
        "download_job": 7,
        "delete_job": 7,
        "list_job": 7,
        "cleanup_job": 7,
        "display_job": 7,
        "healthcheck": 7,
        "max_job_list_retri": 7,
        "sleep_dur": 7,
        "sleep_funct": 7,
        "8000": 7,
        "150": 7,
        "fixed_config": 7,
        "hybrid": 7,
        "softwar": 7,
        "establish": 7,
        "99999999999": 7,
        "9223372036854775807": 7,
        "3c": 7,
        "3600": 7,
        "10000": 7,
        "create_contain": 7,
        "delete_contain": 7,
        "list_contain": 7,
        "upload_blob": 7,
        "download_blob": 7,
        "delete_blob": 7,
        "list_blob": 7,
        "display_blob": 7,
        "create_sas_token": 7,
        "neighbour": 7,
        "arbitrari": 7,
        "pt_temperature_model_linear": 7,
        "pt_temperature_model_exponenti": 7,
        "pt_temperature_model_hukushima": 7,
        "impli": 7,
        "pt_replica_exchange_model_neighbour": 7,
        "pt_replica_exchange_model_far_jump": 7,
        "platform": 7,
        "solutionlist": [7, 10],
        "inspect": 7,
        "100000000": 7,
        "solver_id": 7,
        "solver_class": 7,
        "mixin": 7,
        "permiss": 7,
        "blob_nam": 7,
        "view": [7, 9],
        "progress_hook": 7,
        "signatur": 7,
        "byte": 7,
        "transfer": 7,
        "overwrit": [7, 8],
        "upload": 7,
        "fail": 7,
        "resourceexistserror": 7,
        "unknown": 7,
        "last_modifi": 7,
        "stamp": 7,
        "refresh": 7,
        "tui": 7,
        "job_id": 7,
        "start_tim": 7,
        "cancel": 7,
        "encapsul": [7, 8],
        "request_s": 7,
        "response_s": 7,
        "make_qubo": [7, 9, 10],
        "evalu": [7, 10],
        "sample_filt": 7,
        "samplefilt": [7, 10],
        "few": 7,
        "reject": 7,
        "exce": 7,
        "filter_qubo": 7,
        "dav3paramet": [7, 10],
        "dav3cparamet": 7,
        "fulfil": 7,
        "inequalit": 7,
        "implicit": 7,
        "dav4paramet": [7, 10],
        "remove_obsolet": 7,
        "remove_al": 7,
        "remove_job_id": 7,
        "show_job_id": 7,
        "older": 7,
        "retri": 7,
        "reproduc": 7,
        "sleep": 7,
        "621": 7,
        "440": 7,
        "5mb": 7,
        "files": 7,
        "human": 7,
        "file_name_pattern": 8,
        "safe": 8,
        "copy_to": 8,
        "target_directory_manag": 8,
        "move": 8,
        "count_fil": 8,
        "move_to": 8,
        "physic": 8,
        "directmanag": 8,
        "read_json_fil": 8,
        "object_hook": 8,
        "hook": 8,
        "read_text_fil": 8,
        "remove_fil": 8,
        "write_json_fil": 8,
        "flag": 8,
        "written": 8,
        "serial": 8,
        "write_text_fil": 8,
        "eventu": 8,
        "status_output": 8,
        "listen": 8,
        "alt": 8,
        "signal": 8,
        "observ": 8,
        "keyboard": 8,
        "notifi": 8,
        "receiv": 8,
        "notif": 8,
        "obj": 8,
        "register_decod": 8,
        "decoder_class": 8,
        "register_funct": 8,
        "registered_funct": 8,
        "classnam": 8,
        "skipkei": 8,
        "ensure_ascii": 8,
        "check_circular": 8,
        "allow_nan": 8,
        "sort_kei": 8,
        "sensibl": 8,
        "attempt": 8,
        "skip": 8,
        "guarante": 8,
        "incom": 8,
        "ascii": 8,
        "prevent": 8,
        "infinit": 8,
        "recurs": 8,
        "caus": 8,
        "recursionerror": 8,
        "nan": 8,
        "infin": 8,
        "behavior": 8,
        "compliant": 8,
        "javascript": 8,
        "regress": 8,
        "newlin": [8, 9],
        "item_separ": 8,
        "key_separ": 8,
        "elimin": 8,
        "whitespac": 8,
        "register_encod": 8,
        "clazz": 8,
        "encoder_class": 8,
        "__class__": 8,
        "cleanup": 8,
        "json_minifi": 8,
        "delete_annealer_access_profil": 8,
        "home": 8,
        "get_annealer_access_profil": 8,
        "restrict_search": 8,
        "restriction_search": 8,
        "list_annealer_access_profil": 8,
        "store_annealer_access_profil": 8,
        "name_in_profile_stor": 8,
        "look": 8,
        "etc": 8,
        "jason": 8,
        "update_annealer_access_profil": 8,
        "build_group": 8,
        "cluster": 8,
        "generate_coordin": 8,
        "quantiti": 8,
        "min_dist": 8,
        "special_cas": 8,
        "centr": 8,
        "circl": 8,
        "plot_coordin": 8,
        "xlim": 8,
        "ylim": 8,
        "scatter": 8,
        "plot_coordinates_by_group": 8,
        "groups_by_index": 8,
        "denot": 8,
        "tour": 8,
        "create_qubo": 8,
        "factor_rul": 8,
        "factor_dist": 8,
        "tsp": 8,
        "citi": 8,
        "travel": 8,
        "nearest_neighbour": 8,
        "salesman": 8,
        "plot_rout": 8,
        "rout": 8,
        "plot_routes_by_group": 8,
        "om_ann": 9,
        "om_parallel_temp": 9,
        "solution_mode_quick": 9,
        "solution_mode_complet": 9,
        "method": [9, 10],
        "rest_with_oauth": 9,
        "rest_with_kei": 9,
        "le": 9,
        "ge": 9,
        "variablesequenti": [9, 10],
        "variableunari": [9, 10],
        "variablebinari": [9, 10],
        "littlegauss": 9,
        "variablelittlegauss": [9, 10],
        "variablefibonacci": [9, 10],
        "variablebase10": [9, 10],
        "max_abs_coeffici": 9,
        "reduce_factor": 9,
        "overflow_indic": 9,
        "overflow_coeffici": 9,
        "bring": 9,
        "overflow_idx": 9,
        "overflow": 9,
        "too": 9,
        "big": 9,
        "deactiv": 9,
        "hex": 9,
        "min_dadk_vers": 9,
        "yyyi": 9,
        "mm": 9,
        "dd": 9,
        "oop": 9,
        "sub_id": 9,
        "ctype": 9,
        "_dllt": 9,
        "extern": 9,
        "librari": 9,
        "linux": 9,
        "window": 9,
        "dll": 9,
        "darwin": 9,
        "dylib": 9,
        "shallow": 9,
        "preced": 9,
        "goe": 9,
        "sep": 9,
        "builtin": 9,
        "sy": 9,
        "stdout": 9,
        "tab": [9, 10],
        "dadk_flavour": 9,
        "flavour_develop": 9,
        "signific": 9,
        "func": 9,
        "introduct": 10,
        "add_term": 10,
        "set_term": 10,
        "add_slack_penalti": 10,
        "add_slack_vari": 10,
        "clone": 10,
        "inflate_clamped_configur": 10,
        "make_clamp": 10,
        "multiply_scalar": 10,
        "power": 10,
        "power2": 10,
        "get_weight": 10,
        "get_weights_spars": 10,
        "as_json": 10,
        "as_latex": 10,
        "as_bqm": 10,
        "as_qbsolv": 10,
        "as_text": 10,
        "get_json": 10,
        "get_json_gener": 10,
        "get_json_length": 10,
        "add_json_lin": 10,
        "freeze_var_shape_set": 10,
        "miscellan": 10,
        "generate_slack_polynomi": 10,
        "merge_var_shape_set": 10,
        "reduce_higher_degre": 10,
        "restor": 10,
        "set_clone_warning_count": 10,
        "calculate_hash": 10,
        "plot_connect": 10,
        "plot_histogram": 10,
        "get_normalize_factor": 10,
        "get_scale_factor": 10,
        "exactly_1_bit_on": 10,
        "add_exactly_1_bit_on": 10,
        "exactly_n_bits_on": 10,
        "add_exactly_n_bits_on": 10,
        "most_1_bit_on": 10,
        "add_most_1_bit_on": 10,
        "load_qbsolv": 10,
        "properti": 10,
        "twosideinequ": 10,
        "isingpol": 10,
        "classmethod": 10,
        "convert_to_binari": 10,
        "generate_penalty_polynomi": 10,
        "get_false_bit_indic": 10,
        "get_free_bit_indic": 10,
        "get_not_false_bit_indic": 10,
        "get_true_bit_indic": 10,
        "categori": 10,
        "abc": 10,
        "create_random_st": 10,
        "get_dict": 10,
        "set_bit": 10,
        "set_vari": 10,
        "onehotgroup": 10,
        "load_hdf5": 10,
        "save_as_hdf5": 10,
        "varslack": 10,
        "inequalities2cr": 10,
        "qubo2cr": 10,
        "crs2inequ": 10,
        "crs2qubo": 10,
        "display_graph": 10,
        "get_minimum_energy_solut": 10,
        "get_solution_list": 10,
        "get_sorted_solution_list": 10,
        "get_tim": 10,
        "print_progress": 10,
        "print_stat": 10,
        "search_stats_info": 10,
        "varset": 10,
        "binpolgen": 10,
        "gen_latex": 10,
        "gen_pretty_str": 10,
        "gen_python": 10,
        "parse_poli": 10,
        "restmixin": 10,
        "get_parameter_definit": 10,
        "solverbas": 10,
        "qubosolverdav3": 10,
        "qubosolverbasev3": 10,
        "qubosolverdav3c": 10,
        "azureblobmixin": 10,
        "qubosolverbasev3c": 10,
        "qubosolverdav4": 10,
        "qubosolverbasev4": 10,
        "qubosolvercpu": 10,
        "solverfactori": 10,
        "create_solv": 10,
        "get_solver_id": 10,
        "has_solv": 10,
        "register_solv": 10,
        "progressbar": 10,
        "jobstatu": 10,
        "abstractjob": 10,
        "jobv2": 10,
        "jobv3": 10,
        "jobv3c": 10,
        "jobv4": 10,
        "file_size_info": 10,
        "enum": 10,
        "connectionmethod": 10,
        "makequbowarn": 10,
        "makequbonotusedbitwarn": 10,
        "makequboroundedtozerowarn": 10,
        "makequboerror": 10,
        "qubosizeexceedssolvermaxbit": 10,
        "qubosizeexceedstimeseriesmaxbit": 10,
        "activate_output": 10,
        "deactivate_output": 10,
        "configuration_2_str": 10,
        "string_2_configur": 10,
        "dadk_version_check": 10,
        "debug_except": 10,
        "get_logg": 10,
        "i18n_get": 10,
        "load_librari": 10,
        "merge_dict": 10,
        "print_to_output": 10,
        "register_logging_output": 10,
        "register_timeit_output": 10,
        "round_to_n": 10,
        "timeit": 10,
        "math_prod": 10,
        "directorymanag": 10,
        "interruptkei": 10,
        "jsontool": 10,
        "daodecod": 10,
        "daoencod": 10,
        "jsonencod": 10,
        "dump_json": 10,
        "dumps_json": 10,
        "load_json": 10,
        "loads_json": 10,
        "profileutil": 10,
        "coordinatesutil": 10,
        "tsputil": 10,
        "paralleltemperingutil": 10,
        "paralleltemperingmanag": 10,
        "replicaexchangemodel": 10,
        "replicaexchangemodelfarjump": 10,
        "temperaturemodel": 10,
        "temperaturemodelexponenti": 10,
        "temperaturemodelhukushima": 10,
        "temperaturemodellinear": 10,
        "samplingutil": 10,
        "boltzmannsampl": 10,
        "samplingbasi": 10,
        "energylandscapesampl": 10,
        "cleanupazureblobstorag": 10,
        "cleanupjob": 10,
        "datetimepick": 10,
        "widgetboundedintarrai": 10,
        "widgetboundednumberarrai": 10,
        "widgetnumberarrai": 10,
        "directoryselector": 10,
        "set_directori": 10,
        "fileselector": 10,
        "set_valu": 10,
        "numberplot": 10,
        "add_figur": 10,
        "display_control": 10,
        "numbert": 10,
        "csv_content": 10,
        "display_cont": 10,
        "get_summari": 10,
        "prepare_cont": 10,
        "text_cont": 10,
        "update_cont": 10,
        "outputtab": 10,
        "set_vis": 10,
        "paretoplot": 10,
        "quboeditor": 10,
        "taggedguicontrol": 10,
        "display_appli": 10,
        "display_cr": 10,
        "timepick": 10,
        "timereport": 10,
        "report_fact": 10,
        "take_tim": 10,
        "timetrack": 10,
        "traverse2plot": 10,
        "traverseplot": 10,
        "widgetboundedfloatarrai": 10,
        "widgetboundedfloatrang": 10,
        "widgetboundedintrang": 10,
        "widgetfloatarrai": 10,
        "widgetfloatrang": 10,
        "hbox": 10,
        "staticmethod": 10,
        "register_widget_class": 10,
        "call_funct": 10,
        "get_default_set": 10,
        "get_persistent_set": 10,
        "get_valu": 10,
        "get_widget": 10,
        "gui_default_valu": 10,
        "gui_reset_valu": 10,
        "gui_save_valu": 10,
        "set_dis": 10,
        "set_persistent_set": 10,
        "trigger_change_handl": 10,
        "widgetintarrai": 10,
        "widgetintrang": 10,
        "vbox": 10,
        "widgettab": 10,
        "add_tab": 10,
        "remove_all_tab": 10,
        "select_tab": 10,
        "set_titl": 10,
        "showsolverparamet": 10,
        "get_active_paramet": 10,
        "create_batch": 10,
        "get_result": 10,
        "gui_build": 10,
        "gui_solv": 10,
        "optuna": 10,
        "select_inst": 10,
        "set_build_qubo_details_refer": 10,
        "set_calculated_build_qubo_paramet": 10,
        "set_calculated_solver_paramet": 10,
        "set_compose_model_details_refer": 10,
        "set_fixed_solver_paramet": 10,
        "set_load_details_refer": 10,
        "set_prep_result_details_refer": 10,
        "set_solver_paramet": 10,
        "tab_report": 10,
        "optimizermodelcomplex": 10,
        "build_and_solv": 10,
        "log_data": 10,
        "prep_result": 10,
        "optimizerset": 10,
        "_set": 10,
        "annealinglogset": 10,
        "batchset": 10,
        "composelogset": 10,
        "composeset": 10,
        "optunaset": 10,
        "paretoset": 10,
        "samplingset": 10,
        "solvedav2set": 10,
        "solvedav3set": 10,
        "solvedav3cset": 10,
        "solvedav4set": 10,
        "solveguiset": 10,
        "timeseriesset": 10,
        "optimizertab": 10,
        "optimizertabrequir": 10
    },
    "objects": {
        "dadk.BinPol": [
            [0, 0, 1, "", "BQP"],
            [0, 0, 1, "", "BinPol"],
            [0, 0, 1, "", "BitArrayShape"],
            [0, 0, 1, "", "Category"],
            [0, 0, 1, "", "Inequality"],
            [0, 0, 1, "", "IsingPol"],
            [0, 0, 1, "", "OneHotGroup"],
            [0, 0, 1, "", "PartialConfig"],
            [0, 0, 1, "", "SampleFilter"],
            [0, 0, 1, "", "Term"],
            [0, 0, 1, "", "TwoSideInequality"],
            [0, 0, 1, "", "VarShapeSet"],
            [0, 3, 1, "", "VarSlack"],
            [0, 0, 1, "", "Variable"],
            [0, 0, 1, "", "VariableBase10"],
            [0, 0, 1, "", "VariableBinary"],
            [0, 0, 1, "", "VariableFibonacci"],
            [0, 0, 1, "", "VariableLittlegauss"],
            [0, 0, 1, "", "VariableSequential"],
            [0, 0, 1, "", "VariableUnary"],
            [0, 3, 1, "", "crs2Inequalities"],
            [0, 3, 1, "", "crs2QUBO"],
            [0, 3, 1, "", "inequalities2CRS"],
            [0, 3, 1, "", "qubo2CRS"]
        ],
        "dadk.BinPol.BQP": [
            [0, 1, 1, "", "inequalities"],
            [0, 2, 1, "", "load_hdf5"],
            [0, 1, 1, "", "penalty_qubo"],
            [0, 1, 1, "", "qubo"],
            [0, 2, 1, "", "save_as_hdf5"]
        ],
        "dadk.BinPol.BinPol": [
            [0, 1, 1, "", "N"],
            [0, 2, 1, "", "add"],
            [0, 2, 1, "", "add_exactly_1_bit_on"],
            [0, 2, 1, "", "add_exactly_n_bits_on"],
            [0, 2, 1, "", "add_json_lines"],
            [0, 2, 1, "", "add_most_1_bit_on"],
            [0, 2, 1, "", "add_slack_penalty"],
            [0, 2, 1, "", "add_slack_variable"],
            [0, 2, 1, "", "add_term"],
            [0, 2, 1, "", "as_bqm"],
            [0, 2, 1, "", "as_json"],
            [0, 2, 1, "", "as_latex"],
            [0, 2, 1, "", "as_qbsolv"],
            [0, 2, 1, "", "as_text"],
            [0, 2, 1, "", "calculate_hash"],
            [0, 2, 1, "", "clone"],
            [0, 2, 1, "", "compute"],
            [0, 1, 1, "", "degree"],
            [0, 2, 1, "", "exactly_1_bit_on"],
            [0, 2, 1, "", "exactly_n_bits_on"],
            [0, 2, 1, "", "freeze_var_shape_set"],
            [0, 2, 1, "", "generate_slack_polynomial"],
            [0, 2, 1, "", "get_json"],
            [0, 2, 1, "", "get_json_generator"],
            [0, 2, 1, "", "get_json_length"],
            [0, 2, 1, "", "get_normalize_factor"],
            [0, 2, 1, "", "get_scale_factor"],
            [0, 2, 1, "", "get_weights"],
            [0, 2, 1, "", "get_weights_sparse"],
            [0, 2, 1, "", "inflate_clamped_configuration"],
            [0, 2, 1, "", "load_qbsolv"],
            [0, 2, 1, "", "make_clamped"],
            [0, 2, 1, "", "make_qubo"],
            [0, 2, 1, "", "merge_var_shape_set"],
            [0, 2, 1, "", "most_1_bit_on"],
            [0, 2, 1, "", "multiply"],
            [0, 2, 1, "", "multiply_scalar"],
            [0, 2, 1, "", "normalize"],
            [0, 1, 1, "", "one_hot"],
            [0, 1, 1, "", "p"],
            [0, 2, 1, "", "plot_connections"],
            [0, 2, 1, "", "plot_histogram"],
            [0, 2, 1, "", "power"],
            [0, 2, 1, "", "power2"],
            [0, 2, 1, "", "reduce_higher_degree"],
            [0, 2, 1, "", "restore"],
            [0, 2, 1, "", "scale"],
            [0, 2, 1, "", "set_CLONE_WARNING_COUNTER"],
            [0, 2, 1, "", "set_term"],
            [0, 2, 1, "", "sum"]
        ],
        "dadk.BinPol.BitArrayShape": [
            [0, 1, 1, "", "name"]
        ],
        "dadk.BinPol.Category": [
            [0, 1, 1, "", "values"]
        ],
        "dadk.BinPol.Inequality": [
            [0, 2, 1, "", "as_latex"],
            [0, 2, 1, "", "as_text"],
            [0, 2, 1, "", "clone"],
            [0, 2, 1, "", "compute"],
            [0, 1, 1, "", "lambda_value"],
            [0, 1, 1, "", "makeQUBO_precision"],
            [0, 2, 1, "", "make_qubo"],
            [0, 2, 1, "", "multiply_scalar"],
            [0, 1, 1, "", "qubo"],
            [0, 1, 1, "", "var_shape_set"]
        ],
        "dadk.BinPol.IsingPol": [
            [0, 1, 1, "", "N"],
            [0, 2, 1, "", "add_term"],
            [0, 2, 1, "", "as_latex"],
            [0, 2, 1, "", "as_text"],
            [0, 2, 1, "", "convert_to_binary"],
            [0, 1, 1, "", "degree"],
            [0, 2, 1, "", "freeze_var_shape_set"],
            [0, 1, 1, "", "p"],
            [0, 2, 1, "", "set_term"]
        ],
        "dadk.BinPol.OneHotGroup": [
            [0, 1, 1, "", "entries"]
        ],
        "dadk.BinPol.PartialConfig": [
            [0, 2, 1, "", "as_json"],
            [0, 2, 1, "", "create_random_state"],
            [0, 2, 1, "", "get_dict"],
            [0, 2, 1, "", "set_bit"],
            [0, 2, 1, "", "set_bits"],
            [0, 2, 1, "", "set_variable"],
            [0, 2, 1, "", "set_variables"]
        ],
        "dadk.BinPol.SampleFilter": [
            [0, 2, 1, "", "clone"],
            [0, 1, 1, "", "makeQUBO_precision"],
            [0, 2, 1, "", "make_qubo"],
            [0, 2, 1, "", "multiply_scalar"],
            [0, 1, 1, "", "qubo"],
            [0, 1, 1, "", "upper_limit"],
            [0, 1, 1, "", "var_shape_set"]
        ],
        "dadk.BinPol.Term": [
            [0, 2, 1, "", "compute"]
        ],
        "dadk.BinPol.TwoSideInequality": [
            [0, 2, 1, "", "as_latex"],
            [0, 2, 1, "", "as_text"],
            [0, 1, 1, "", "left_qubo"],
            [0, 1, 1, "", "right_qubo"],
            [0, 1, 1, "", "sign"]
        ],
        "dadk.BinPol.VarShapeSet": [
            [0, 2, 1, "", "generate_penalty_polynomial"],
            [0, 2, 1, "", "get_false_bit_indices"],
            [0, 2, 1, "", "get_free_bit_indices"],
            [0, 2, 1, "", "get_not_false_bit_indices"],
            [0, 2, 1, "", "get_true_bit_indices"],
            [0, 1, 1, "", "one_hot"]
        ],
        "dadk.BinPol.Variable": [
            [0, 1, 1, "", "penalty"],
            [0, 1, 1, "", "qubo"],
            [0, 1, 1, "", "start"],
            [0, 1, 1, "", "step"],
            [0, 1, 1, "", "stop"]
        ],
        "dadk.BinPolGen": [
            [1, 0, 1, "", "BinPolGen"]
        ],
        "dadk.BinPolGen.BinPolGen": [
            [1, 2, 1, "", "gen_latex"],
            [1, 2, 1, "", "gen_pretty_string"],
            [1, 2, 1, "", "gen_python"],
            [1, 2, 1, "", "parse_poly"],
            [1, 1, 1, "", "source"],
            [1, 1, 1, "", "tree"]
        ],
        "dadk.JSONTools": [
            [8, 0, 1, "", "DaoDecoder"],
            [8, 0, 1, "", "DaoEncoder"],
            [8, 3, 1, "", "dump_json"],
            [8, 3, 1, "", "dumps_json"],
            [8, 3, 1, "", "load_json"],
            [8, 3, 1, "", "loads_json"]
        ],
        "dadk.JSONTools.DaoDecoder": [
            [8, 2, 1, "", "object_hook"],
            [8, 2, 1, "", "register_decoder"],
            [8, 2, 1, "", "register_function"]
        ],
        "dadk.JSONTools.DaoEncoder": [
            [8, 2, 1, "", "default"],
            [8, 2, 1, "", "register_encoder"],
            [8, 2, 1, "", "register_function"]
        ],
        "dadk.JupyterTools": [
            [4, 0, 1, "", "CleanupAzureBlobStorage"],
            [4, 0, 1, "", "CleanupJobs"],
            [4, 0, 1, "", "DatetimePicker"],
            [4, 0, 1, "", "DirectorySelector"],
            [4, 0, 1, "", "FileSelector"],
            [4, 0, 1, "", "NumberPlot"],
            [4, 0, 1, "", "NumberTable"],
            [4, 0, 1, "", "OutputTab"],
            [4, 0, 1, "", "ParetoPlot"],
            [4, 0, 1, "", "QuboEditor"],
            [4, 0, 1, "", "SetAnnealerProfile"],
            [4, 3, 1, "", "ShowSolverParameter"],
            [4, 0, 1, "", "TaggedGuiControl"],
            [4, 0, 1, "", "TimePicker"],
            [4, 0, 1, "", "TimeReporter"],
            [4, 0, 1, "", "TimeTracker"],
            [4, 0, 1, "", "Traverse2Plot"],
            [4, 0, 1, "", "TraversePlot"],
            [4, 0, 1, "", "WidgetBoundedFloatArray"],
            [4, 0, 1, "", "WidgetBoundedFloatRange"],
            [4, 0, 1, "", "WidgetBoundedIntArray"],
            [4, 0, 1, "", "WidgetBoundedIntRange"],
            [4, 0, 1, "", "WidgetBoundedNumberArray"],
            [4, 0, 1, "", "WidgetDefinition"],
            [4, 0, 1, "", "WidgetFloatArray"],
            [4, 0, 1, "", "WidgetFloatRange"],
            [4, 0, 1, "", "WidgetGui"],
            [4, 0, 1, "", "WidgetIntArray"],
            [4, 0, 1, "", "WidgetIntRange"],
            [4, 0, 1, "", "WidgetNumberArray"],
            [4, 0, 1, "", "WidgetTab"],
            [4, 3, 1, "", "get_active_parameters"],
            [4, 3, 1, "", "prolog"]
        ],
        "dadk.JupyterTools.DatetimePicker": [
            [4, 1, 1, "", "value"]
        ],
        "dadk.JupyterTools.DirectorySelector": [
            [4, 2, 1, "", "set_directory"]
        ],
        "dadk.JupyterTools.FileSelector": [
            [4, 1, 1, "", "file"],
            [4, 1, 1, "", "on_change_code"],
            [4, 1, 1, "", "path"],
            [4, 2, 1, "", "set_value"],
            [4, 1, 1, "", "value"]
        ],
        "dadk.JupyterTools.NumberPlot": [
            [4, 2, 1, "", "add_figure"],
            [4, 2, 1, "", "display_control"]
        ],
        "dadk.JupyterTools.NumberTable": [
            [4, 2, 1, "", "csv_content"],
            [4, 2, 1, "", "display_content"],
            [4, 2, 1, "", "get_summary"],
            [4, 2, 1, "", "prepare_content"],
            [4, 2, 1, "", "text_content"],
            [4, 2, 1, "", "update_content"]
        ],
        "dadk.JupyterTools.OutputTab": [
            [4, 2, 1, "", "display"],
            [4, 2, 1, "", "set_visibility"],
            [4, 1, 1, "", "tab_out"]
        ],
        "dadk.JupyterTools.ParetoPlot": [
            [4, 2, 1, "", "add_figure"],
            [4, 2, 1, "", "display_control"]
        ],
        "dadk.JupyterTools.TaggedGuiControl": [
            [4, 1, 1, "", "applier"],
            [4, 1, 1, "", "creator"],
            [4, 2, 1, "", "display_applier"],
            [4, 2, 1, "", "display_creator"]
        ],
        "dadk.JupyterTools.TimePicker": [
            [4, 1, 1, "", "value"]
        ],
        "dadk.JupyterTools.TimeReporter": [
            [4, 2, 1, "", "report_fact"],
            [4, 1, 1, "", "silent"],
            [4, 2, 1, "", "take_time"]
        ],
        "dadk.JupyterTools.TimeTracker": [
            [4, 2, 1, "", "add"],
            [4, 2, 1, "", "close"]
        ],
        "dadk.JupyterTools.Traverse2Plot": [
            [4, 2, 1, "", "add_figure"],
            [4, 2, 1, "", "display_control"]
        ],
        "dadk.JupyterTools.TraversePlot": [
            [4, 2, 1, "", "add_figure"],
            [4, 2, 1, "", "display_control"]
        ],
        "dadk.JupyterTools.WidgetBoundedNumberArray": [
            [4, 1, 1, "", "max"],
            [4, 1, 1, "", "min"],
            [4, 1, 1, "", "step"]
        ],
        "dadk.JupyterTools.WidgetGui": [
            [4, 2, 1, "", "call_function"],
            [4, 2, 1, "", "get_default_setting"],
            [4, 2, 1, "", "get_persistent_setting"],
            [4, 2, 1, "", "get_value"],
            [4, 2, 1, "", "get_widget"],
            [4, 2, 1, "", "gui_default_values"],
            [4, 2, 1, "", "gui_reset_values"],
            [4, 2, 1, "", "gui_save_values"],
            [4, 2, 1, "", "register_widget_class"],
            [4, 2, 1, "", "set_disabled"],
            [4, 2, 1, "", "set_persistent_setting"],
            [4, 2, 1, "", "set_value"],
            [4, 2, 1, "", "trigger_change_handlers"]
        ],
        "dadk.JupyterTools.WidgetNumberArray": [
            [4, 1, 1, "", "columns"],
            [4, 1, 1, "", "description"],
            [4, 1, 1, "", "disabled"],
            [4, 1, 1, "", "headers"],
            [4, 1, 1, "", "label"],
            [4, 1, 1, "", "row_labels"],
            [4, 1, 1, "", "rows"],
            [4, 1, 1, "", "value"],
            [4, 1, 1, "", "visible"]
        ],
        "dadk.JupyterTools.WidgetTab": [
            [4, 2, 1, "", "add_tab"],
            [4, 2, 1, "", "remove_all_tabs"],
            [4, 2, 1, "", "select_tab"],
            [4, 2, 1, "", "set_title"]
        ],
        "dadk.Optimizer": [
            [5, 0, 1, "", "Optimizer"],
            [5, 0, 1, "", "OptimizerModel"],
            [5, 0, 1, "", "OptimizerModelComplex"],
            [5, 0, 1, "", "OptimizerSettings"],
            [5, 0, 1, "", "OptimizerTab"],
            [5, 0, 1, "", "OptimizerTabRequirement"]
        ],
        "dadk.Optimizer.Optimizer": [
            [5, 2, 1, "", "create_batch"],
            [5, 2, 1, "", "get_results"],
            [5, 2, 1, "", "get_widget"],
            [5, 2, 1, "", "gui_build"],
            [5, 1, 1, "", "gui_compose"],
            [5, 1, 1, "", "gui_load"],
            [5, 2, 1, "", "gui_solve"],
            [5, 2, 1, "", "load"],
            [5, 2, 1, "", "optuna"],
            [5, 2, 1, "", "pareto"],
            [5, 2, 1, "", "run"],
            [5, 2, 1, "", "select_instance"],
            [5, 2, 1, "", "set_build_qubo_details_reference"],
            [5, 2, 1, "", "set_calculated_build_qubo_parameter"],
            [5, 2, 1, "", "set_calculated_solver_parameter"],
            [5, 2, 1, "", "set_compose_model_details_reference"],
            [5, 2, 1, "", "set_fixed_solver_parameter"],
            [5, 2, 1, "", "set_load_details_reference"],
            [5, 2, 1, "", "set_prep_result_details_reference"],
            [5, 2, 1, "", "set_solver_parameter"],
            [5, 1, 1, "", "tab_build"],
            [5, 1, 1, "", "tab_compose"],
            [5, 1, 1, "", "tab_load"],
            [5, 1, 1, "", "tab_optuna"],
            [5, 1, 1, "", "tab_pareto"],
            [5, 2, 1, "", "tab_report"],
            [5, 1, 1, "", "tab_solve"],
            [5, 1, 1, "", "tab_timeseries"],
            [5, 1, 1, "", "tab_visualization"],
            [5, 2, 1, "", "timeseries"]
        ],
        "dadk.Optimizer.OptimizerModelComplex": [
            [5, 1, 1, "", "Optimizer"],
            [5, 2, 1, "", "build_and_solve"],
            [5, 2, 1, "", "build_qubo"],
            [5, 2, 1, "", "get_time"],
            [5, 2, 1, "", "load"],
            [5, 2, 1, "", "log"],
            [5, 2, 1, "", "log_data"],
            [5, 1, 1, "", "optuna_dirname"],
            [5, 1, 1, "", "pareto_dirname"],
            [5, 2, 1, "", "prep_result"],
            [5, 1, 1, "", "timeseries_dirname"]
        ],
        "dadk.Optimizer.OptimizerSettings": [
            [5, 0, 1, "", "AnnealingLogSettings"],
            [5, 0, 1, "", "BatchSettings"],
            [5, 0, 1, "", "ComposeLogSettings"],
            [5, 0, 1, "", "ComposeSettings"],
            [5, 0, 1, "", "OptunaSettings"],
            [5, 0, 1, "", "ParetoSettings"],
            [5, 0, 1, "", "SamplingSettings"],
            [5, 0, 1, "", "SolveDAv2Settings"],
            [5, 0, 1, "", "SolveDAv3Settings"],
            [5, 0, 1, "", "SolveDAv3cSettings"],
            [5, 0, 1, "", "SolveDAv4Settings"],
            [5, 0, 1, "", "SolveGUISettings"],
            [5, 0, 1, "", "TimeseriesSettings"],
            [5, 1, 1, "", "annealing_log"],
            [5, 1, 1, "", "batch"],
            [5, 1, 1, "", "compose"],
            [5, 1, 1, "", "compose_log"],
            [5, 1, 1, "", "optuna"],
            [5, 1, 1, "", "pareto"],
            [5, 1, 1, "", "sampling"],
            [5, 1, 1, "", "solve_dav2"],
            [5, 1, 1, "", "solve_dav3"],
            [5, 1, 1, "", "solve_dav3c"],
            [5, 1, 1, "", "solve_dav4"],
            [5, 1, 1, "", "solve_gui"],
            [5, 1, 1, "", "timeseries"]
        ],
        "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings": [
            [5, 1, 1, "", "graphs_figsize"],
            [5, 1, 1, "", "save_graphs"],
            [5, 1, 1, "", "save_graphs_figsize"],
            [5, 1, 1, "", "save_times"],
            [5, 1, 1, "", "save_times_figsize"],
            [5, 1, 1, "", "times_figsize"],
            [5, 1, 1, "", "values_per_row"]
        ],
        "dadk.Optimizer.OptimizerSettings.BatchSettings": [
            [5, 1, 1, "", "parameter_logging"]
        ],
        "dadk.Optimizer.OptimizerSettings.ComposeLogSettings": [
            [5, 1, 1, "", "figsize"],
            [5, 1, 1, "", "save_graphs"],
            [5, 1, 1, "", "save_graphs_figsize"],
            [5, 1, 1, "", "values_per_row"]
        ],
        "dadk.Optimizer.OptimizerSettings.ComposeSettings": [
            [5, 1, 1, "", "create_summary_excel"],
            [5, 1, 1, "", "excel_summary_columns"],
            [5, 1, 1, "", "log_memory_size"],
            [5, 1, 1, "", "show_summary"],
            [5, 1, 1, "", "summary_columns"]
        ],
        "dadk.Optimizer.OptimizerSettings.OptunaSettings": [
            [5, 1, 1, "", "delete_files"]
        ],
        "dadk.Optimizer.OptimizerSettings.ParetoSettings": [
            [5, 1, 1, "", "delete_files"]
        ],
        "dadk.Optimizer.OptimizerSettings.SamplingSettings": [
            [5, 1, 1, "", "filter_limit"],
            [5, 1, 1, "", "sample_size"],
            [5, 1, 1, "", "unique_sample_limit"]
        ],
        "dadk.Optimizer.OptimizerSettings.SolveDAv2Settings": [
            [5, 1, 1, "", "store_graphics"],
            [5, 1, 1, "", "use_compact"],
            [5, 1, 1, "", "use_qubo_matrix"]
        ],
        "dadk.Optimizer.OptimizerSettings.SolveDAv3Settings": [
            [5, 1, 1, "", "use_compact"]
        ],
        "dadk.Optimizer.OptimizerSettings.SolveDAv3cSettings": [
            [5, 1, 1, "", "use_compact"]
        ],
        "dadk.Optimizer.OptimizerSettings.SolveDAv4Settings": [
            [5, 1, 1, "", "use_compact"]
        ],
        "dadk.Optimizer.OptimizerSettings.SolveGUISettings": [
            [5, 1, 1, "", "button_width"],
            [5, 1, 1, "", "description_width"]
        ],
        "dadk.Optimizer.OptimizerSettings.TimeseriesSettings": [
            [5, 1, 1, "", "delete_files"]
        ],
        "dadk.Optimizer.OptimizerTab": [
            [5, 2, 1, "", "get_widget"],
            [5, 2, 1, "", "set_disabled"]
        ],
        "dadk.ProfileUtils": [
            [8, 0, 1, "", "ProfileUtils"]
        ],
        "dadk.ProfileUtils.ProfileUtils": [
            [8, 2, 1, "", "delete_annealer_access_profile"],
            [8, 2, 1, "", "get_annealer_access_profile"],
            [8, 2, 1, "", "list_annealer_access_profiles"],
            [8, 2, 1, "", "store_annealer_access_profile"],
            [8, 2, 1, "", "update_annealer_access_profiles"]
        ],
        "dadk.QUBOSolverBase": [
            [7, 0, 1, "", "AzureBlobMixin"],
            [7, 0, 1, "", "JobStatus"],
            [7, 0, 1, "", "QUBOSolverBase"],
            [7, 0, 1, "", "QUBOSolverBaseV2"],
            [7, 0, 1, "", "QUBOSolverBaseV3"],
            [7, 0, 1, "", "QUBOSolverBaseV3c"],
            [7, 0, 1, "", "QUBOSolverBaseV4"],
            [7, 0, 1, "", "QUBOSolverEmulator"],
            [7, 0, 1, "", "RestMixin"],
            [7, 0, 1, "", "SolverBase"],
            [7, 3, 1, "", "file_size_info"]
        ],
        "dadk.QUBOSolverBase.AzureBlobMixin": [
            [7, 0, 1, "", "Blob"],
            [7, 0, 1, "", "ProgressBar"],
            [7, 2, 1, "", "create_container"],
            [7, 2, 1, "", "create_sas_token"],
            [7, 2, 1, "", "delete_blob"],
            [7, 2, 1, "", "delete_container"],
            [7, 2, 1, "", "display_blobs"],
            [7, 2, 1, "", "download_blob"],
            [7, 2, 1, "", "list_blobs"],
            [7, 2, 1, "", "list_containers"],
            [7, 2, 1, "", "upload_blob"]
        ],
        "dadk.QUBOSolverBase.AzureBlobMixin.Blob": [
            [7, 1, 1, "", "blob_name"],
            [7, 1, 1, "", "container_name"],
            [7, 1, 1, "", "last_modified"],
            [7, 1, 1, "", "size"]
        ],
        "dadk.QUBOSolverBase.AzureBlobMixin.ProgressBar": [
            [7, 2, 1, "", "close"],
            [7, 2, 1, "", "set"]
        ],
        "dadk.QUBOSolverBase.JobStatus": [
            [7, 1, 1, "", "job_id"],
            [7, 1, 1, "", "start_time"],
            [7, 1, 1, "", "status"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBase": [
            [7, 0, 1, "", "Job"],
            [7, 1, 1, "", "bqp_filename"],
            [7, 1, 1, "", "guidance_config"],
            [7, 2, 1, "", "healthcheck"],
            [7, 1, 1, "", "solver_max_bits"],
            [7, 1, 1, "", "timeseries_max_bits"],
            [7, 1, 1, "", "tuning_parameter"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBase.Job": [
            [7, 1, 1, "", "bqp_filename"],
            [7, 1, 1, "", "check_number_of_bits"],
            [7, 1, 1, "", "guidance_config"],
            [7, 1, 1, "", "qubo"],
            [7, 1, 1, "", "random_seed"],
            [7, 1, 1, "", "report_holes"],
            [7, 1, 1, "", "request_size"],
            [7, 1, 1, "", "response_size"],
            [7, 1, 1, "", "solver_max_bits"],
            [7, 1, 1, "", "stats_info"],
            [7, 1, 1, "", "timeseries_max_bits"],
            [7, 1, 1, "", "tuning_parameter"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBaseV2": [
            [7, 0, 1, "", "JobV2"],
            [7, 1, 1, "", "da_parameter"],
            [7, 2, 1, "", "minimize"],
            [7, 2, 1, "", "sample"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBaseV2.JobV2": [
            [7, 1, 1, "", "da_parameter"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBaseV3": [
            [7, 0, 1, "", "JobV3"],
            [7, 1, 1, "", "da_parameter"],
            [7, 1, 1, "", "fixed_config"],
            [7, 2, 1, "", "minimize"],
            [7, 2, 1, "", "sample"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBaseV3.JobV3": [
            [7, 1, 1, "", "da_parameter"],
            [7, 1, 1, "", "fixed_config"],
            [7, 1, 1, "", "inequalities"],
            [7, 1, 1, "", "penalty_qubo"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBaseV3c": [
            [7, 0, 1, "", "JobV3C"],
            [7, 1, 1, "", "da_parameter"],
            [7, 1, 1, "", "fixed_config"],
            [7, 2, 1, "", "minimize"],
            [7, 2, 1, "", "sample"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBaseV3c.JobV3C": [
            [7, 1, 1, "", "da_parameter"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBaseV4": [
            [7, 0, 1, "", "JobV4"],
            [7, 1, 1, "", "da_parameter"],
            [7, 1, 1, "", "fixed_config"],
            [7, 2, 1, "", "minimize"],
            [7, 2, 1, "", "sample"]
        ],
        "dadk.QUBOSolverBase.QUBOSolverBaseV4.JobV4": [
            [7, 1, 1, "", "da_parameter"]
        ],
        "dadk.QUBOSolverBase.RestMixin": [
            [7, 2, 1, "", "cancel_job"],
            [7, 2, 1, "", "cleanup_jobs"],
            [7, 2, 1, "", "delete_job"],
            [7, 2, 1, "", "display_jobs"],
            [7, 2, 1, "", "download_job"],
            [7, 2, 1, "", "list_jobs"]
        ],
        "dadk.QUBOSolverBase.SolverBase": [
            [7, 0, 1, "", "AbstractJob"],
            [7, 1, 1, "", "connection_parameter"],
            [7, 1, 1, "", "logger"],
            [7, 1, 1, "", "max_job_list_retry"],
            [7, 1, 1, "", "random_seed"],
            [7, 1, 1, "", "random_seed_increment"],
            [7, 1, 1, "", "sleep_duration"],
            [7, 1, 1, "", "sleep_function"]
        ],
        "dadk.QUBOSolverBase.SolverBase.AbstractJob": [
            [7, 1, 1, "", "logger"],
            [7, 1, 1, "", "times"]
        ],
        "dadk.QUBOSolverCPU": [
            [7, 0, 1, "", "QUBOSolverCPU"]
        ],
        "dadk.QUBOSolverCPU.QUBOSolverCPU": [
            [7, 2, 1, "", "get_parameter_definitions"]
        ],
        "dadk.QUBOSolverDAv2": [
            [7, 0, 1, "", "QUBOSolverDAv2"]
        ],
        "dadk.QUBOSolverDAv2.QUBOSolverDAv2": [
            [7, 2, 1, "", "get_parameter_definitions"]
        ],
        "dadk.QUBOSolverDAv3": [
            [7, 0, 1, "", "QUBOSolverDAv3"]
        ],
        "dadk.QUBOSolverDAv3.QUBOSolverDAv3": [
            [7, 2, 1, "", "get_parameter_definitions"]
        ],
        "dadk.QUBOSolverDAv3c": [
            [7, 0, 1, "", "QUBOSolverDAv3c"]
        ],
        "dadk.QUBOSolverDAv3c.QUBOSolverDAv3c": [
            [7, 2, 1, "", "get_parameter_definitions"]
        ],
        "dadk.QUBOSolverDAv4": [
            [7, 0, 1, "", "QUBOSolverDAv4"]
        ],
        "dadk.QUBOSolverDAv4.QUBOSolverDAv4": [
            [7, 2, 1, "", "get_parameter_definitions"]
        ],
        "dadk.Solution_SolutionList": [
            [6, 0, 1, "", "BitArray"],
            [6, 0, 1, "", "Solution"],
            [6, 0, 1, "", "SolutionList"],
            [6, 0, 1, "", "VarSet"]
        ],
        "dadk.Solution_SolutionList.BitArray": [
            [6, 1, 1, "", "call_back"],
            [6, 2, 1, "", "draw"],
            [6, 2, 1, "", "evaluate"],
            [6, 1, 1, "", "name"],
            [6, 1, 1, "", "shape"],
            [6, 1, 1, "", "start"],
            [6, 1, 1, "", "step"],
            [6, 1, 1, "", "stop"]
        ],
        "dadk.Solution_SolutionList.Solution": [
            [6, 1, 1, "", "configuration"],
            [6, 2, 1, "", "draw"],
            [6, 1, 1, "", "energy"],
            [6, 2, 1, "", "extract_bit_array"],
            [6, 1, 1, "", "penalty_energy"],
            [6, 1, 1, "", "var_shape_set"]
        ],
        "dadk.Solution_SolutionList.SolutionList": [
            [6, 1, 1, "", "anneal_time"],
            [6, 1, 1, "", "connection_parameter"],
            [6, 1, 1, "", "da_parameter"],
            [6, 2, 1, "", "display_graphs"],
            [6, 1, 1, "", "execution_time"],
            [6, 2, 1, "", "get_minimum_energy_solution"],
            [6, 2, 1, "", "get_solution_list"],
            [6, 2, 1, "", "get_sorted_solution_list"],
            [6, 2, 1, "", "get_time"],
            [6, 2, 1, "", "get_times"],
            [6, 1, 1, "", "inequalities"],
            [6, 1, 1, "", "min_solution"],
            [6, 1, 1, "", "penalty_qubo"],
            [6, 2, 1, "", "print_progress"],
            [6, 2, 1, "", "print_stats"],
            [6, 1, 1, "", "qubo"],
            [6, 2, 1, "", "search_stats_info"],
            [6, 1, 1, "", "solver_times"],
            [6, 1, 1, "", "tuning_parameter"]
        ],
        "dadk.Solution_SolutionList.VarSet": [
            [6, 2, 1, "", "extract_bit_array"]
        ],
        "dadk.SolverFactory": [
            [7, 3, 1, "", "create_solver"],
            [7, 3, 1, "", "get_solver_IDs"],
            [7, 3, 1, "", "has_solver"],
            [7, 3, 1, "", "register_solver"]
        ],
        "dadk._Constants": [
            [9, 0, 1, "", "AutoTuning"],
            [9, 0, 1, "", "ConnectionMethod"],
            [9, 0, 1, "", "GraphicsDetail"],
            [9, 0, 1, "", "InequalitySign"],
            [9, 0, 1, "", "MakeQuboError"],
            [9, 0, 1, "", "MakeQuboNotUsedBitWarning"],
            [9, 0, 1, "", "MakeQuboRoundedToZeroWarning"],
            [9, 0, 1, "", "MakeQuboWarning"],
            [9, 0, 1, "", "OneHot"],
            [9, 0, 1, "", "ParameterLogging"],
            [9, 0, 1, "", "QUBOSizeExceedsSolverMaxBits"],
            [9, 0, 1, "", "QUBOSizeExceedsTimeseriesMaxBits"],
            [9, 0, 1, "", "RequestMode"],
            [9, 0, 1, "", "SlackType"],
            [9, 0, 1, "", "StorageAccountType"],
            [9, 3, 1, "", "activate_output"],
            [9, 3, 1, "", "configuration_2_string"],
            [9, 3, 1, "", "dadk_version_check"],
            [9, 3, 1, "", "deactivate_output"],
            [9, 3, 1, "", "debug_exception"],
            [9, 3, 1, "", "get_logger"],
            [9, 3, 1, "", "i18n_get"],
            [9, 3, 1, "", "load_library"],
            [9, 3, 1, "", "math_prod"],
            [9, 3, 1, "", "merge_dicts"],
            [9, 3, 1, "", "print_to_output"],
            [9, 3, 1, "", "register_logging_output"],
            [9, 3, 1, "", "register_timeit_output"],
            [9, 3, 1, "", "round_to_n"],
            [9, 3, 1, "", "string_2_configuration"],
            [9, 3, 1, "", "timeit"]
        ],
        "dadk._Constants.MakeQuboNotUsedBitWarning": [
            [9, 1, 1, "", "index"]
        ],
        "dadk._Constants.MakeQuboRoundedToZeroWarning": [
            [9, 1, 1, "", "coefficient"],
            [9, 1, 1, "", "index"]
        ],
        "dadk._Constants.MakeQuboWarning": [
            [9, 1, 1, "", "index"]
        ],
        "dadk._Constants.QUBOSizeExceedsSolverMaxBits": [
            [9, 1, 1, "", "bits"],
            [9, 1, 1, "", "max_bits"],
            [9, 1, 1, "", "name"]
        ],
        "dadk._Constants.QUBOSizeExceedsTimeseriesMaxBits": [
            [9, 1, 1, "", "bits"],
            [9, 1, 1, "", "max_bits"],
            [9, 1, 1, "", "name"]
        ],
        "dadk.internal.ConnectionParameter": [
            [2, 0, 1, "", "ConnectionParameter"]
        ],
        "dadk.internal.ConnectionParameter.ConnectionParameter": [
            [2, 1, 1, "", "annealer_address"],
            [2, 1, 1, "", "annealer_path"],
            [2, 1, 1, "", "annealer_port"],
            [2, 1, 1, "", "annealer_protocol"],
            [2, 1, 1, "", "annealer_queue_size"],
            [2, 1, 1, "", "api_key"],
            [2, 1, 1, "", "audience"],
            [2, 1, 1, "", "clientid"],
            [2, 1, 1, "", "clientsecret"],
            [2, 1, 1, "", "connection_method"],
            [2, 1, 1, "", "connection_mode"],
            [2, 1, 1, "", "container_name"],
            [2, 1, 1, "", "dict"],
            [2, 1, 1, "", "domain"],
            [2, 1, 1, "", "ignore_proxy"],
            [2, 1, 1, "", "inequalities_blob_name"],
            [2, 1, 1, "", "inequalities_filename"],
            [2, 1, 1, "", "offline_request_file"],
            [2, 1, 1, "", "offline_response_file"],
            [2, 1, 1, "", "penalty_qubo_blob_name"],
            [2, 1, 1, "", "penalty_qubo_filename"],
            [2, 1, 1, "", "prolog_blob_name"],
            [2, 1, 1, "", "prolog_filename"],
            [2, 1, 1, "", "proxy"],
            [2, 1, 1, "", "proxy_password"],
            [2, 1, 1, "", "proxy_port"],
            [2, 1, 1, "", "proxy_user"],
            [2, 1, 1, "", "qubo_blob_name"],
            [2, 1, 1, "", "qubo_filename"],
            [2, 1, 1, "", "request_mode"],
            [2, 1, 1, "", "rest_version_enforced"],
            [2, 1, 1, "", "sas_token"],
            [2, 1, 1, "", "ssl_disable_warnings"],
            [2, 1, 1, "", "ssl_verify"],
            [2, 1, 1, "", "storage_account_name"],
            [2, 1, 1, "", "storage_account_type"],
            [2, 1, 1, "", "storage_connection_string"],
            [2, 1, 1, "", "timeout"]
        ],
        "dadk.internal.DAv2Parameter": [
            [2, 0, 1, "", "DAv2Parameter"]
        ],
        "dadk.internal.DAv2Parameter.DAv2Parameter": [
            [2, 1, 1, "", "bit_precision"],
            [2, 1, 1, "", "dict"],
            [2, 1, 1, "", "graphics"],
            [2, 1, 1, "", "number_iterations"],
            [2, 1, 1, "", "number_replicas"],
            [2, 1, 1, "", "number_runs"],
            [2, 1, 1, "", "offset_increase_rate"],
            [2, 1, 1, "", "optimization_method"],
            [2, 2, 1, "", "plot_temperature_curve"],
            [2, 1, 1, "", "pt_replica_exchange_model"],
            [2, 1, 1, "", "pt_temperature_model"],
            [2, 1, 1, "", "solution_mode"],
            [2, 1, 1, "", "temperature_decay"],
            [2, 1, 1, "", "temperature_end"],
            [2, 1, 1, "", "temperature_interval"],
            [2, 1, 1, "", "temperature_mode"],
            [2, 1, 1, "", "temperature_mode_txt"],
            [2, 1, 1, "", "temperature_start"]
        ],
        "dadk.internal.DAv3Parameter": [
            [2, 0, 1, "", "DAv3Parameter"]
        ],
        "dadk.internal.DAv3Parameter.DAv3Parameter": [
            [2, 1, 1, "", "dict"],
            [2, 1, 1, "", "gs_max_penalty_coef"],
            [2, 1, 1, "", "gs_num_iteration_cl"],
            [2, 1, 1, "", "gs_num_iteration_factor"],
            [2, 1, 1, "", "gs_penalty_auto_mode"],
            [2, 1, 1, "", "gs_penalty_coef"],
            [2, 1, 1, "", "gs_penalty_inc_rate"],
            [2, 1, 1, "", "num_group"],
            [2, 1, 1, "", "num_output_solution"],
            [2, 1, 1, "", "num_solution"],
            [2, 1, 1, "", "target_energy"],
            [2, 1, 1, "", "time_limit_sec"]
        ],
        "dadk.internal.DAv4Parameter": [
            [2, 0, 1, "", "DAv4Parameter"]
        ],
        "dadk.internal.DAv4Parameter.DAv4Parameter": [
            [2, 1, 1, "", "dict"],
            [2, 1, 1, "", "gs_max_penalty_coef"],
            [2, 1, 1, "", "gs_num_iteration_cl"],
            [2, 1, 1, "", "gs_num_iteration_factor"],
            [2, 1, 1, "", "gs_ohs_xw1h_num_iteration_cl"],
            [2, 1, 1, "", "gs_ohs_xw1h_num_iteration_factor"],
            [2, 1, 1, "", "gs_penalty_auto_mode"],
            [2, 1, 1, "", "gs_penalty_coef"],
            [2, 1, 1, "", "gs_penalty_inc_rate"],
            [2, 1, 1, "", "num_group"],
            [2, 1, 1, "", "num_output_solution"],
            [2, 1, 1, "", "num_solution"],
            [2, 1, 1, "", "ohs_xw1h_internal_penalty"],
            [2, 1, 1, "", "target_energy"],
            [2, 1, 1, "", "time_limit_sec"]
        ],
        "dadk.internal.GraphicsData": [
            [2, 0, 1, "", "GraphicsData"]
        ],
        "dadk.internal.GraphicsData.GraphicsData": [
            [2, 1, 1, "", "bit_flips"],
            [2, 1, 1, "", "energies"],
            [2, 1, 1, "", "furnace_process_length"],
            [2, 1, 1, "", "graphics"],
            [2, 1, 1, "", "hill_energies"],
            [2, 1, 1, "", "hill_steps"],
            [2, 1, 1, "", "min_energy"],
            [2, 1, 1, "", "min_step"],
            [2, 1, 1, "", "number_of_bits"],
            [2, 1, 1, "", "number_of_hills"],
            [2, 1, 1, "", "number_of_valleys"],
            [2, 1, 1, "", "number_of_walks"],
            [2, 1, 1, "", "optimization_method"],
            [2, 2, 1, "", "plot_graphs"],
            [2, 1, 1, "", "replica_exchange_count"],
            [2, 1, 1, "", "replica_history"],
            [2, 1, 1, "", "temperatures"],
            [2, 1, 1, "", "valley_energies"],
            [2, 1, 1, "", "valley_steps"],
            [2, 1, 1, "", "wait_cycles"]
        ],
        "dadk.internal.ParallelTemperingUtilities": [
            [2, 0, 1, "", "ParallelTemperingManagement"],
            [2, 0, 1, "", "ReplicaExchangeModel"],
            [2, 0, 1, "", "ReplicaExchangeModelFarJump"],
            [2, 0, 1, "", "TemperatureModel"],
            [2, 0, 1, "", "TemperatureModelExponential"],
            [2, 0, 1, "", "TemperatureModelHukushima"],
            [2, 0, 1, "", "TemperatureModelLinear"]
        ],
        "dadk.internal.ParallelTemperingUtilities.ParallelTemperingManagement": [
            [2, 2, 1, "", "generate_replica_furnace_exchange_step"],
            [2, 1, 1, "", "replica_furnace_history"],
            [2, 1, 1, "", "replica_temperature_list"]
        ],
        "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModel": [
            [2, 1, 1, "", "furnace_replica_list"],
            [2, 1, 1, "", "furnaces_replica_history"],
            [2, 1, 1, "", "logger"],
            [2, 1, 1, "", "replica_furnace_history"],
            [2, 1, 1, "", "replica_furnace_list"],
            [2, 1, 1, "", "replica_temperature_list"]
        ],
        "dadk.internal.ParallelTemperingUtilities.TemperatureModel": [
            [2, 1, 1, "", "logger"],
            [2, 1, 1, "", "replica_count"],
            [2, 1, 1, "", "temperature_high"],
            [2, 1, 1, "", "temperature_list"],
            [2, 1, 1, "", "temperature_low"]
        ],
        "dadk.internal.SamplingUtilities": [
            [2, 0, 1, "", "BoltzmannSampling"],
            [2, 0, 1, "", "EnergyLandscapeSampling"],
            [2, 0, 1, "", "SamplingBasis"]
        ],
        "dadk.internal.SamplingUtilities.BoltzmannSampling": [
            [2, 1, 1, "", "furnace_mean_energy_list"],
            [2, 1, 1, "", "randomwalk_count"],
            [2, 1, 1, "", "randomwalk_length"]
        ],
        "dadk.internal.SamplingUtilities.EnergyLandscapeSampling": [
            [2, 2, 1, "", "do_sampling"],
            [2, 1, 1, "", "mean_abs_energy_delta"],
            [2, 1, 1, "", "mean_escape_energy"]
        ],
        "dadk.internal.SamplingUtilities.SamplingBasis": [
            [2, 2, 1, "", "do_sampling"]
        ],
        "dadk.internal.SolverTimes": [
            [2, 0, 1, "", "SolverTimes"]
        ],
        "dadk.internal.SolverTimes.SolverTimes": [
            [2, 1, 1, "", "duration_account_occupied"],
            [2, 1, 1, "", "duration_anneal"],
            [2, 1, 1, "", "duration_cpu"],
            [2, 1, 1, "", "duration_dau_service"],
            [2, 1, 1, "", "duration_elapsed"],
            [2, 1, 1, "", "duration_execution"],
            [2, 1, 1, "", "duration_occupied"],
            [2, 1, 1, "", "duration_parse_response"],
            [2, 1, 1, "", "duration_prepare_qubo"],
            [2, 1, 1, "", "duration_prepare_request"],
            [2, 1, 1, "", "duration_queue"],
            [2, 1, 1, "", "duration_receive_response"],
            [2, 1, 1, "", "duration_save_bqp"],
            [2, 1, 1, "", "duration_save_request"],
            [2, 1, 1, "", "duration_save_response"],
            [2, 1, 1, "", "duration_send_request"],
            [2, 1, 1, "", "duration_solve"],
            [2, 1, 1, "", "duration_tuning"],
            [2, 1, 1, "", "duration_waiting"],
            [2, 1, 1, "", "duration_waiting_2_finish"],
            [2, 1, 1, "", "duration_waiting_2_start"],
            [2, 1, 1, "", "end_account_occupied"],
            [2, 1, 1, "", "end_anneal"],
            [2, 1, 1, "", "end_cpu"],
            [2, 1, 1, "", "end_dau_service"],
            [2, 1, 1, "", "end_elapsed"],
            [2, 1, 1, "", "end_execution"],
            [2, 1, 1, "", "end_occupied"],
            [2, 1, 1, "", "end_parse_response"],
            [2, 1, 1, "", "end_prepare_qubo"],
            [2, 1, 1, "", "end_prepare_request"],
            [2, 1, 1, "", "end_queue"],
            [2, 1, 1, "", "end_receive_response"],
            [2, 1, 1, "", "end_save_bqp"],
            [2, 1, 1, "", "end_save_request"],
            [2, 1, 1, "", "end_save_response"],
            [2, 1, 1, "", "end_send_request"],
            [2, 1, 1, "", "end_solve"],
            [2, 1, 1, "", "end_tuning"],
            [2, 1, 1, "", "end_waiting"],
            [2, 1, 1, "", "end_waiting_2_finish"],
            [2, 1, 1, "", "end_waiting_2_start"],
            [2, 1, 1, "", "logger"],
            [2, 1, 1, "", "start_account_occupied"],
            [2, 1, 1, "", "start_anneal"],
            [2, 1, 1, "", "start_cpu"],
            [2, 1, 1, "", "start_dau_service"],
            [2, 1, 1, "", "start_elapsed"],
            [2, 1, 1, "", "start_execution"],
            [2, 1, 1, "", "start_occupied"],
            [2, 1, 1, "", "start_parse_response"],
            [2, 1, 1, "", "start_prepare_qubo"],
            [2, 1, 1, "", "start_prepare_request"],
            [2, 1, 1, "", "start_queue"],
            [2, 1, 1, "", "start_receive_response"],
            [2, 1, 1, "", "start_save_bqp"],
            [2, 1, 1, "", "start_save_request"],
            [2, 1, 1, "", "start_save_response"],
            [2, 1, 1, "", "start_send_request"],
            [2, 1, 1, "", "start_solve"],
            [2, 1, 1, "", "start_tuning"],
            [2, 1, 1, "", "start_waiting"],
            [2, 1, 1, "", "start_waiting_2_finish"],
            [2, 1, 1, "", "start_waiting_2_start"]
        ],
        "dadk.internal.Tools": [
            [8, 0, 1, "", "DirectoryManager"],
            [8, 0, 1, "", "InterruptKey"]
        ],
        "dadk.internal.Tools.DirectoryManager": [
            [8, 2, 1, "", "copy_to"],
            [8, 2, 1, "", "count_files"],
            [8, 2, 1, "", "create"],
            [8, 2, 1, "", "move_to"],
            [8, 1, 1, "", "path"],
            [8, 2, 1, "", "read_json_file"],
            [8, 2, 1, "", "read_text_file"],
            [8, 2, 1, "", "remove"],
            [8, 2, 1, "", "remove_files"],
            [8, 2, 1, "", "write_json_file"],
            [8, 2, 1, "", "write_text_file"]
        ],
        "dadk.internal.Tools.InterruptKey": [
            [8, 1, 1, "", "interrupt"],
            [8, 2, 1, "", "stop"]
        ],
        "dadk.internal.TuningParameter": [
            [2, 0, 1, "", "TuningParameter"]
        ],
        "dadk.internal.TuningParameter.TuningParameter": [
            [2, 1, 1, "", "annealing_steps"],
            [2, 1, 1, "", "auto_tuning"],
            [2, 1, 1, "", "dict"],
            [2, 1, 1, "", "end_progress_probability"],
            [2, 1, 1, "", "sampling_distance"],
            [2, 1, 1, "", "sampling_walk_count"],
            [2, 1, 1, "", "sampling_walk_length"],
            [2, 1, 1, "", "scaling_bit_precision"],
            [2, 1, 1, "", "scaling_factor"],
            [2, 1, 1, "", "start_progress_probability"]
        ],
        "dadk.utils.CoordinatesUtils": [
            [8, 0, 1, "", "CoordinatesUtils"]
        ],
        "dadk.utils.CoordinatesUtils.CoordinatesUtils": [
            [8, 2, 1, "", "build_groups"],
            [8, 2, 1, "", "generate_coordinates"],
            [8, 2, 1, "", "plot_coordinates"],
            [8, 2, 1, "", "plot_coordinates_by_groups"]
        ],
        "dadk.utils.TSPUtils": [
            [8, 0, 1, "", "TSPUtils"]
        ],
        "dadk.utils.TSPUtils.TSPUtils": [
            [8, 2, 1, "", "create_QUBOS"],
            [8, 2, 1, "", "nearest_neighbour"],
            [8, 2, 1, "", "plot_route"],
            [8, 2, 1, "", "plot_routes_by_groups"]
        ]
    },
    "objtypes": {
        "0": "py:class",
        "1": "py:property",
        "2": "py:method",
        "3": "py:function"
    },
    "objnames": {
        "0": ["py", "class", "Python class"],
        "1": ["py", "property", "Python property"],
        "2": ["py", "method", "Python method"],
        "3": ["py", "function", "Python function"]
    },
    "titleterms": {
        "polynomi": [0, 1],
        "binpol": 0,
        "binari": 0,
        "defin": 0,
        "term": 0,
        "add_term": 0,
        "set_term": 0,
        "oper": 0,
        "add": [0, 4],
        "add_slack_penalti": 0,
        "add_slack_vari": 0,
        "clone": 0,
        "inflate_clamped_configur": 0,
        "make_clamp": 0,
        "multipli": 0,
        "multiply_scalar": 0,
        "power": 0,
        "power2": 0,
        "evalu": [0, 6],
        "comput": 0,
        "get_weight": 0,
        "get_weights_spars": 0,
        "as_json": 0,
        "as_latex": 0,
        "as_bqm": 0,
        "as_qbsolv": 0,
        "as_text": 0,
        "get_json": 0,
        "get_json_gener": 0,
        "get_json_length": 0,
        "add_json_lin": 0,
        "freeze_var_shape_set": 0,
        "miscellan": 0,
        "generate_slack_polynomi": 0,
        "make_qubo": 0,
        "merge_var_shape_set": 0,
        "reduce_higher_degre": 0,
        "restor": 0,
        "set_clone_warning_count": 0,
        "experiment": 0,
        "calculate_hash": 0,
        "plot_connect": 0,
        "plot_histogram": 0,
        "get_normalize_factor": 0,
        "normal": 0,
        "get_scale_factor": 0,
        "scale": 0,
        "sum": 0,
        "exactly_1_bit_on": 0,
        "add_exactly_1_bit_on": 0,
        "exactly_n_bits_on": 0,
        "add_exactly_n_bits_on": 0,
        "most_1_bit_on": 0,
        "add_most_1_bit_on": 0,
        "load_qbsolv": 0,
        "properti": [0, 1, 2, 4, 5, 6, 7, 8, 9],
        "product": 0,
        "variabl": 0,
        "method": [0, 1, 2, 4, 5, 6, 7, 8],
        "inequ": 0,
        "twosideinequ": 0,
        "isingpol": 0,
        "classmethod": [0, 7, 8],
        "convert_to_binari": 0,
        "The": 0,
        "search": 0,
        "space": 0,
        "structur": [0, 3],
        "bit": 0,
        "varshapeset": 0,
        "generate_penalty_polynomi": 0,
        "get_false_bit_indic": 0,
        "get_free_bit_indic": 0,
        "get_not_false_bit_indic": 0,
        "get_true_bit_indic": 0,
        "bitarrayshap": 0,
        "categori": 0,
        "abc": [0, 2, 7, 9],
        "variablebase10": 0,
        "variablebinari": 0,
        "variablefibonacci": 0,
        "variablelittlegauss": 0,
        "variablesequenti": 0,
        "variableunari": 0,
        "partialconfig": 0,
        "create_random_st": 0,
        "get_dict": 0,
        "set_bit": 0,
        "set_vari": 0,
        "samplefilt": 0,
        "onehotgroup": 0,
        "bqp": 0,
        "load_hdf5": 0,
        "save_as_hdf5": 0,
        "function": [0, 4, 7, 8, 9],
        "varslack": 0,
        "inequalities2cr": 0,
        "qubo2cr": 0,
        "crs2inequ": 0,
        "crs2qubo": 0,
        "gener": 1,
        "descript": 1,
        "binpolgen": 1,
        "grammar": 1,
        "lark": 1,
        "syntax": 1,
        "start": 1,
        "element": 1,
        "exampl": 1,
        "gen_latex": 1,
        "gen_pretty_str": 1,
        "gen_python": 1,
        "parse_poli": 1,
        "intern": 2,
        "dav2paramet": 2,
        "dav3paramet": 2,
        "dav4paramet": 2,
        "connectionparamet": 2,
        "graphicsdata": 2,
        "tuningparamet": 2,
        "solvertim": 2,
        "paralleltemperingutil": 2,
        "paralleltemperingmanag": 2,
        "replicaexchangemodel": 2,
        "replicaexchangemodelfarjump": 2,
        "temperaturemodel": 2,
        "temperaturemodelexponenti": 2,
        "temperaturemodelhukushima": 2,
        "temperaturemodellinear": 2,
        "samplingutil": 2,
        "boltzmannsampl": 2,
        "samplingbasi": 2,
        "energylandscapesampl": 2,
        "introduct": 3,
        "thi": 3,
        "help": 3,
        "jupytertool": 4,
        "cleanupazureblobstorag": 4,
        "cleanupjob": 4,
        "datetimepick": 4,
        "widgetboundedintarrai": 4,
        "widgetboundednumberarrai": 4,
        "widgetnumberarrai": 4,
        "directoryselector": 4,
        "dropdown": 4,
        "set_directori": 4,
        "fileselector": 4,
        "set_valu": 4,
        "numberplot": 4,
        "add_figur": 4,
        "display_control": 4,
        "numbert": 4,
        "csv_content": 4,
        "display_cont": 4,
        "get_summari": 4,
        "prepare_cont": 4,
        "text_cont": 4,
        "update_cont": 4,
        "outputtab": 4,
        "displai": 4,
        "set_vis": 4,
        "paretoplot": 4,
        "quboeditor": 4,
        "setannealerprofil": 4,
        "taggedguicontrol": 4,
        "display_appli": 4,
        "display_cr": 4,
        "timepick": 4,
        "timereport": 4,
        "report_fact": 4,
        "take_tim": 4,
        "timetrack": 4,
        "close": 4,
        "traverse2plot": 4,
        "traverseplot": 4,
        "widgetboundedfloatarrai": 4,
        "widgetboundedfloatrang": 4,
        "widgetboundedintrang": 4,
        "widgetdefinit": 4,
        "dict": 4,
        "widgetfloatarrai": 4,
        "widgetfloatrang": 4,
        "widgetgui": 4,
        "hbox": [4, 5],
        "staticmethod": 4,
        "register_widget_class": 4,
        "call_funct": 4,
        "get_default_set": 4,
        "get_persistent_set": 4,
        "get_valu": 4,
        "get_widget": [4, 5],
        "gui_default_valu": 4,
        "gui_reset_valu": 4,
        "gui_save_valu": 4,
        "set_dis": [4, 5],
        "set_persistent_set": 4,
        "trigger_change_handl": 4,
        "widgetintarrai": 4,
        "widgetintrang": 4,
        "vbox": 4,
        "widgettab": 4,
        "tab": [4, 5],
        "add_tab": 4,
        "remove_all_tab": 4,
        "select_tab": 4,
        "set_titl": 4,
        "showsolverparamet": 4,
        "get_active_paramet": 4,
        "prolog": 4,
        "optim": [5, 6],
        "create_batch": 5,
        "get_result": 5,
        "gui_build": 5,
        "gui_solv": 5,
        "load": 5,
        "optuna": 5,
        "pareto": 5,
        "run": 5,
        "select_inst": 5,
        "set_build_qubo_details_refer": 5,
        "set_calculated_build_qubo_paramet": 5,
        "set_calculated_solver_paramet": 5,
        "set_compose_model_details_refer": 5,
        "set_fixed_solver_paramet": 5,
        "set_load_details_refer": 5,
        "set_prep_result_details_refer": 5,
        "set_solver_paramet": 5,
        "tab_report": 5,
        "timeseri": 5,
        "optimizermodel": 5,
        "optimizermodelcomplex": 5,
        "build_and_solv": 5,
        "build_qubo": 5,
        "get_tim": [5, 6],
        "log": 5,
        "log_data": 5,
        "prep_result": 5,
        "optimizerset": 5,
        "_set": 5,
        "annealinglogset": 5,
        "batchset": 5,
        "composelogset": 5,
        "composeset": 5,
        "optunaset": 5,
        "paretoset": 5,
        "samplingset": 5,
        "solvedav2set": 5,
        "solvedav3set": 5,
        "solvedav3cset": 5,
        "solvedav4set": 5,
        "solveguiset": 5,
        "timeseriesset": 5,
        "optimizertab": 5,
        "optimizertabrequir": 5,
        "enum": [5, 9],
        "solut": 6,
        "bitarrai": 6,
        "draw": 6,
        "extract_bit_arrai": 6,
        "solutionlist": 6,
        "display_graph": 6,
        "get_minimum_energy_solut": 6,
        "get_solution_list": 6,
        "get_sorted_solution_list": 6,
        "print_progress": 6,
        "print_stat": 6,
        "search_stats_info": 6,
        "varset": 6,
        "solver": 7,
        "overview": 7,
        "qubosolverdav2": 7,
        "restmixin": 7,
        "qubosolverbasev2": 7,
        "get_parameter_definit": 7,
        "qubosolverbas": 7,
        "solverbas": 7,
        "qubosolverdav3": 7,
        "qubosolverbasev3": 7,
        "qubosolverdav3c": 7,
        "azureblobmixin": 7,
        "qubosolverbasev3c": 7,
        "contain": 7,
        "blob": 7,
        "other": [7, 9],
        "qubosolverdav4": 7,
        "qubosolverbasev4": 7,
        "qubosolvercpu": 7,
        "qubosolveremul": 7,
        "solverfactori": 7,
        "create_solv": 7,
        "get_solver_id": 7,
        "has_solv": 7,
        "register_solv": 7,
        "progressbar": 7,
        "jobstatu": 7,
        "job": 7,
        "abstractjob": 7,
        "jobv2": 7,
        "jobv3": 7,
        "jobv3c": 7,
        "jobv4": 7,
        "file_size_info": 7,
        "util": 8,
        "tool": 8,
        "directorymanag": 8,
        "interruptkei": 8,
        "jsontool": 8,
        "daodecod": 8,
        "daoencod": 8,
        "jsonencod": 8,
        "dump_json": 8,
        "dumps_json": 8,
        "load_json": 8,
        "loads_json": 8,
        "profileutil": 8,
        "coordinatesutil": 8,
        "tsputil": 8,
        "constant": 9,
        "autotun": 9,
        "connectionmethod": 9,
        "graphicsdetail": 9,
        "inequalitysign": 9,
        "onehot": 9,
        "requestmod": 9,
        "parameterlog": 9,
        "slacktyp": 9,
        "storageaccounttyp": 9,
        "warn": 9,
        "makequbowarn": 9,
        "makequbonotusedbitwarn": 9,
        "makequboroundedtozerowarn": 9,
        "except": 9,
        "makequboerror": 9,
        "qubosizeexceedssolvermaxbit": 9,
        "qubosizeexceedstimeseriesmaxbit": 9,
        "activate_output": 9,
        "deactivate_output": 9,
        "configuration_2_str": 9,
        "string_2_configur": 9,
        "dadk_version_check": 9,
        "debug_except": 9,
        "get_logg": 9,
        "i18n_get": 9,
        "load_librari": 9,
        "merge_dict": 9,
        "print_to_output": 9,
        "register_logging_output": 9,
        "register_timeit_output": 9,
        "round_to_n": 9,
        "timeit": 9,
        "math_prod": 9,
        "digit": 10,
        "anneal": 10,
        "develop": 10,
        "kit": 10,
        "index": 10,
        "content": 10
    },
    "envversion": {
        "sphinx.domains.c": 3,
        "sphinx.domains.changeset": 1,
        "sphinx.domains.citation": 1,
        "sphinx.domains.cpp": 9,
        "sphinx.domains.index": 1,
        "sphinx.domains.javascript": 3,
        "sphinx.domains.math": 2,
        "sphinx.domains.python": 4,
        "sphinx.domains.rst": 2,
        "sphinx.domains.std": 2,
        "sphinx": 60
    },
    "alltitles": {
        "Polynomials": [
            [0, "polynomials"]
        ],
        "BinPol - Binary polynomials": [
            [0, "binpol-binary-polynomials"]
        ],
        "Define polynomial terms": [
            [0, "define-polynomial-terms"]
        ],
        "add_term": [
            [0, "add-term"],
            [0, "dadk-binpol-isingpol-add-term"]
        ],
        "set_term": [
            [0, "set-term"],
            [0, "dadk-binpol-isingpol-set-term"]
        ],
        "Polynomial operations": [
            [0, "polynomial-operations"]
        ],
        "add": [
            [0, "add"],
            [4, "add"]
        ],
        "add_slack_penalty": [
            [0, "add-slack-penalty"]
        ],
        "add_slack_variable": [
            [0, "add-slack-variable"]
        ],
        "clone": [
            [0, "clone"],
            [0, "dadk-binpol-inequality-clone"],
            [0, "dadk-binpol-samplefilter-clone"]
        ],
        "inflate_clamped_configuration": [
            [0, "inflate-clamped-configuration"]
        ],
        "make_clamped": [
            [0, "make-clamped"]
        ],
        "multiply": [
            [0, "multiply"]
        ],
        "multiply_scalar": [
            [0, "multiply-scalar"],
            [0, "dadk-binpol-inequality-multiply-scalar"],
            [0, "dadk-binpol-samplefilter-multiply-scalar"]
        ],
        "power": [
            [0, "power"]
        ],
        "power2": [
            [0, "power2"]
        ],
        "Operators": [
            [0, "operators"],
            [0, "id50"]
        ],
        "Polynomial evaluation": [
            [0, "polynomial-evaluation"]
        ],
        "compute": [
            [0, "compute"],
            [0, "dadk-binpol-term-compute"],
            [0, "dadk-binpol-inequality-compute"]
        ],
        "get_weights": [
            [0, "get-weights"]
        ],
        "get_weights_sparse": [
            [0, "get-weights-sparse"]
        ],
        "as_json": [
            [0, "as-json"],
            [0, "dadk-binpol-partialconfig-as-json"]
        ],
        "as_latex": [
            [0, "as-latex"],
            [0, "dadk-binpol-inequality-as-latex"],
            [0, "dadk-binpol-twosideinequality-as-latex"],
            [0, "dadk-binpol-isingpol-as-latex"]
        ],
        "as_bqm": [
            [0, "as-bqm"]
        ],
        "as_qbsolv": [
            [0, "as-qbsolv"]
        ],
        "as_text": [
            [0, "as-text"],
            [0, "dadk-binpol-inequality-as-text"],
            [0, "dadk-binpol-twosideinequality-as-text"],
            [0, "dadk-binpol-isingpol-as-text"]
        ],
        "get_json": [
            [0, "get-json"]
        ],
        "get_json_generator": [
            [0, "get-json-generator"]
        ],
        "get_json_length": [
            [0, "get-json-length"]
        ],
        "add_json_lines": [
            [0, "add-json-lines"]
        ],
        "freeze_var_shape_set": [
            [0, "freeze-var-shape-set"],
            [0, "dadk-binpol-isingpol-freeze-var-shape-set"]
        ],
        "Miscellaneous": [
            [0, "miscellaneous"]
        ],
        "generate_slack_polynomial": [
            [0, "generate-slack-polynomial"]
        ],
        "make_qubo": [
            [0, "make-qubo"],
            [0, "dadk-binpol-inequality-make-qubo"],
            [0, "dadk-binpol-samplefilter-make-qubo"]
        ],
        "merge_var_shape_set": [
            [0, "merge-var-shape-set"]
        ],
        "reduce_higher_degree": [
            [0, "reduce-higher-degree"]
        ],
        "restore": [
            [0, "restore"]
        ],
        "set_CLONE_WARNING_COUNTER": [
            [0, "set-clone-warning-counter"]
        ],
        "EXPERIMENTAL": [
            [0, "experimental"]
        ],
        "calculate_hash": [
            [0, "calculate-hash"]
        ],
        "plot_connections": [
            [0, "plot-connections"]
        ],
        "plot_histogram": [
            [0, "plot-histogram"]
        ],
        "get_normalize_factor": [
            [0, "get-normalize-factor"]
        ],
        "normalize": [
            [0, "normalize"]
        ],
        "get_scale_factor": [
            [0, "get-scale-factor"]
        ],
        "scale": [
            [0, "scale"]
        ],
        "sum": [
            [0, "sum"]
        ],
        "exactly_1_bit_on": [
            [0, "exactly-1-bit-on"]
        ],
        "add_exactly_1_bit_on": [
            [0, "add-exactly-1-bit-on"]
        ],
        "exactly_n_bits_on": [
            [0, "exactly-n-bits-on"]
        ],
        "add_exactly_n_bits_on": [
            [0, "add-exactly-n-bits-on"]
        ],
        "most_1_bit_on": [
            [0, "most-1-bit-on"]
        ],
        "add_most_1_bit_on": [
            [0, "add-most-1-bit-on"]
        ],
        "load_qbsolv": [
            [0, "load-qbsolv"]
        ],
        "Properties": [
            [0, "properties"],
            [0, "id10"],
            [0, "id14"],
            [0, "id21"],
            [0, "id23"],
            [0, "id24"],
            [0, "id25"],
            [0, "id26"],
            [0, "id45"],
            [0, "id46"],
            [0, "id49"],
            [1, "properties"],
            [2, "properties"],
            [2, "id3"],
            [2, "id5"],
            [2, "id7"],
            [2, "id10"],
            [2, "id12"],
            [2, "id14"],
            [2, "id16"],
            [2, "id17"],
            [2, "id18"],
            [2, "id21"],
            [2, "id23"],
            [4, "properties"],
            [4, "id2"],
            [4, "id6"],
            [4, "id11"],
            [4, "id12"],
            [4, "id16"],
            [4, "id32"],
            [4, "id40"],
            [5, "properties"],
            [5, "id3"],
            [5, "id4"],
            [5, "id5"],
            [5, "id6"],
            [5, "id7"],
            [5, "id8"],
            [5, "id9"],
            [5, "id10"],
            [5, "id11"],
            [5, "id12"],
            [5, "id13"],
            [5, "id14"],
            [5, "id15"],
            [5, "id16"],
            [5, "id17"],
            [6, "properties"],
            [6, "id3"],
            [6, "id5"],
            [7, "properties"],
            [7, "id31"],
            [7, "id33"],
            [7, "id35"],
            [7, "id38"],
            [7, "id41"],
            [7, "id45"],
            [7, "id48"],
            [7, "id53"],
            [7, "id56"],
            [7, "id61"],
            [7, "id64"],
            [7, "id74"],
            [7, "id75"],
            [8, "properties"],
            [8, "id2"],
            [9, "properties"],
            [9, "id1"],
            [9, "id2"],
            [9, "id3"],
            [9, "id4"]
        ],
        "Term - Products of binary variables": [
            [0, "term-products-of-binary-variables"]
        ],
        "Methods": [
            [0, "methods"],
            [0, "id3"],
            [0, "id11"],
            [0, "id16"],
            [0, "id22"],
            [0, "id39"],
            [0, "id41"],
            [0, "id48"],
            [1, "methods"],
            [2, "methods"],
            [2, "id9"],
            [2, "id15"],
            [2, "id22"],
            [2, "id24"],
            [4, "methods"],
            [4, "id1"],
            [4, "id3"],
            [4, "id4"],
            [4, "id5"],
            [4, "id7"],
            [4, "id10"],
            [4, "id15"],
            [4, "id17"],
            [4, "id18"],
            [4, "id21"],
            [4, "id36"],
            [4, "id41"],
            [5, "methods"],
            [5, "id1"],
            [5, "id18"],
            [6, "methods"],
            [6, "id1"],
            [6, "id4"],
            [6, "id6"],
            [7, "methods"],
            [7, "id30"],
            [7, "id32"],
            [7, "id36"],
            [7, "id43"],
            [7, "id51"],
            [7, "id59"],
            [7, "id73"],
            [8, "methods"],
            [8, "id1"],
            [8, "id4"]
        ],
        "Inequality": [
            [0, "inequality"]
        ],
        "TwoSideInequality(Inequality)": [
            [0, "twosideinequality-inequality"]
        ],
        "Methods (Inequality)": [
            [0, "methods-inequality"]
        ],
        "Properties (Inequality)": [
            [0, "properties-inequality"]
        ],
        "IsingPol": [
            [0, "isingpol"]
        ],
        "Classmethods": [
            [0, "classmethods"],
            [0, "id47"],
            [7, "classmethods"],
            [7, "id1"],
            [7, "id7"],
            [7, "id13"],
            [7, "id23"],
            [8, "classmethods"],
            [8, "id3"],
            [8, "id6"],
            [8, "id8"],
            [8, "id10"]
        ],
        "convert_to_binary": [
            [0, "convert-to-binary"]
        ],
        "The Binary Search Space": [
            [0, "the-binary-search-space"]
        ],
        "Structured Bit Variables": [
            [0, "structured-bit-variables"]
        ],
        "VarShapeSet": [
            [0, "varshapeset"]
        ],
        "generate_penalty_polynomial": [
            [0, "generate-penalty-polynomial"]
        ],
        "get_false_bit_indices": [
            [0, "get-false-bit-indices"]
        ],
        "get_free_bit_indices": [
            [0, "get-free-bit-indices"]
        ],
        "get_not_false_bit_indices": [
            [0, "get-not-false-bit-indices"]
        ],
        "get_true_bit_indices": [
            [0, "get-true-bit-indices"]
        ],
        "BitArrayShape": [
            [0, "bitarrayshape"]
        ],
        "Category(BitArrayShape)": [
            [0, "category-bitarrayshape"]
        ],
        "Properties (BitArrayShape)": [
            [0, "properties-bitarrayshape"],
            [0, "id27"],
            [0, "id28"],
            [0, "id30"],
            [0, "id32"],
            [0, "id34"],
            [0, "id36"],
            [0, "id38"]
        ],
        "Variable(BitArrayShape, ABC)": [
            [0, "variable-bitarrayshape-abc"]
        ],
        "VariableBase10(Variable)": [
            [0, "variablebase10-variable"]
        ],
        "Properties (Variable)": [
            [0, "properties-variable"],
            [0, "id29"],
            [0, "id31"],
            [0, "id33"],
            [0, "id35"],
            [0, "id37"]
        ],
        "VariableBinary(Variable)": [
            [0, "variablebinary-variable"]
        ],
        "VariableFibonacci(Variable)": [
            [0, "variablefibonacci-variable"]
        ],
        "VariableLittlegauss(Variable)": [
            [0, "variablelittlegauss-variable"]
        ],
        "VariableSequential(Variable)": [
            [0, "variablesequential-variable"]
        ],
        "VariableUnary(Variable)": [
            [0, "variableunary-variable"]
        ],
        "PartialConfig": [
            [0, "partialconfig"]
        ],
        "create_random_state": [
            [0, "create-random-state"]
        ],
        "get_dict": [
            [0, "get-dict"]
        ],
        "set_bit": [
            [0, "set-bit"]
        ],
        "set_bits": [
            [0, "set-bits"]
        ],
        "set_variable": [
            [0, "set-variable"]
        ],
        "set_variables": [
            [0, "set-variables"]
        ],
        "SampleFilter": [
            [0, "samplefilter"]
        ],
        "OneHotGroup": [
            [0, "onehotgroup"]
        ],
        "BQP": [
            [0, "bqp"]
        ],
        "load_hdf5": [
            [0, "load-hdf5"]
        ],
        "save_as_hdf5": [
            [0, "save-as-hdf5"]
        ],
        "Functions": [
            [0, "functions"],
            [4, "functions"],
            [7, "functions"],
            [7, "id76"],
            [8, "functions"],
            [9, "functions"]
        ],
        "VarSlack": [
            [0, "varslack"]
        ],
        "inequalities2CRS": [
            [0, "inequalities2crs"]
        ],
        "qubo2CRS": [
            [0, "qubo2crs"]
        ],
        "crs2Inequalities": [
            [0, "crs2inequalities"]
        ],
        "crs2QUBO": [
            [0, "crs2qubo"]
        ],
        "Generate Polynomials and Description": [
            [1, "generate-polynomials-and-description"]
        ],
        "BinPolGen": [
            [1, "binpolgen"]
        ],
        "Grammar in lark syntax with start element polynomial:": [
            [1, "grammar-in-lark-syntax-with-start-element-polynomial"]
        ],
        "Example": [
            [1, "example"]
        ],
        "gen_latex": [
            [1, "gen-latex"]
        ],
        "gen_pretty_string": [
            [1, "gen-pretty-string"]
        ],
        "gen_python": [
            [1, "gen-python"]
        ],
        "parse_poly": [
            [1, "parse-poly"]
        ],
        "Internal": [
            [2, "internal"]
        ],
        "DAv2Parameter": [
            [2, "dav2parameter"],
            [2, "dadk-internal-dav2parameter-dav2parameter"]
        ],
        "DAv3Parameter": [
            [2, "dav3parameter"],
            [2, "dadk-internal-dav3parameter-dav3parameter"]
        ],
        "DAv4Parameter": [
            [2, "dav4parameter"],
            [2, "dadk-internal-dav4parameter-dav4parameter"]
        ],
        "ConnectionParameter": [
            [2, "connectionparameter"],
            [2, "dadk-internal-connectionparameter-connectionparameter"]
        ],
        "GraphicsData": [
            [2, "graphicsdata"],
            [2, "dadk-internal-graphicsdata-graphicsdata"]
        ],
        "TuningParameter": [
            [2, "tuningparameter"],
            [2, "dadk-internal-tuningparameter-tuningparameter"]
        ],
        "SolverTimes": [
            [2, "solvertimes"],
            [2, "dadk-internal-solvertimes-solvertimes"]
        ],
        "ParallelTemperingUtilities": [
            [2, "paralleltemperingutilities"]
        ],
        "ParallelTemperingManagement": [
            [2, "paralleltemperingmanagement"]
        ],
        "ReplicaExchangeModel": [
            [2, "replicaexchangemodel"]
        ],
        "ReplicaExchangeModelFarJump(ReplicaExchangeModel)": [
            [2, "replicaexchangemodelfarjump-replicaexchangemodel"]
        ],
        "Properties (ReplicaExchangeModel)": [
            [2, "properties-replicaexchangemodel"]
        ],
        "TemperatureModel": [
            [2, "temperaturemodel"]
        ],
        "TemperatureModelExponential(TemperatureModel)": [
            [2, "temperaturemodelexponential-temperaturemodel"]
        ],
        "Properties (TemperatureModel)": [
            [2, "properties-temperaturemodel"],
            [2, "id19"],
            [2, "id20"]
        ],
        "TemperatureModelHukushima(TemperatureModelExponential)": [
            [2, "temperaturemodelhukushima-temperaturemodelexponential"]
        ],
        "TemperatureModelLinear(TemperatureModel)": [
            [2, "temperaturemodellinear-temperaturemodel"]
        ],
        "SamplingUtilities": [
            [2, "samplingutilities"]
        ],
        "BoltzmannSampling(SamplingBasis)": [
            [2, "boltzmannsampling-samplingbasis"]
        ],
        "Methods (SamplingBasis)": [
            [2, "methods-samplingbasis"]
        ],
        "EnergyLandscapeSampling(SamplingBasis)": [
            [2, "energylandscapesampling-samplingbasis"]
        ],
        "SamplingBasis(ABC)": [
            [2, "samplingbasis-abc"]
        ],
        "Introduction": [
            [3, "introduction"]
        ],
        "Structure of this help": [
            [3, "structure-of-this-help"]
        ],
        "JupyterTools": [
            [4, "jupytertools"]
        ],
        "CleanupAzureBlobStorage": [
            [4, "cleanupazureblobstorage"]
        ],
        "CleanupJobs": [
            [4, "cleanupjobs"]
        ],
        "DatetimePicker(WidgetBoundedIntArray)": [
            [4, "datetimepicker-widgetboundedintarray"]
        ],
        "Properties (WidgetBoundedNumberArray)": [
            [4, "properties-widgetboundednumberarray"],
            [4, "id13"],
            [4, "id24"],
            [4, "id26"],
            [4, "id28"],
            [4, "id30"]
        ],
        "Properties (WidgetNumberArray)": [
            [4, "properties-widgetnumberarray"],
            [4, "id14"],
            [4, "id25"],
            [4, "id27"],
            [4, "id29"],
            [4, "id31"],
            [4, "id33"],
            [4, "id34"],
            [4, "id35"],
            [4, "id38"],
            [4, "id39"]
        ],
        "DirectorySelector(Dropdown)": [
            [4, "directoryselector-dropdown"]
        ],
        "set_directory": [
            [4, "set-directory"]
        ],
        "FileSelector": [
            [4, "fileselector"]
        ],
        "set_value": [
            [4, "set-value"],
            [4, "dadk-jupytertools-widgetgui-set-value"]
        ],
        "NumberPlot": [
            [4, "numberplot"]
        ],
        "add_figure": [
            [4, "add-figure"],
            [4, "dadk-jupytertools-paretoplot-add-figure"],
            [4, "dadk-jupytertools-traverse2plot-add-figure"],
            [4, "dadk-jupytertools-traverseplot-add-figure"]
        ],
        "display_control": [
            [4, "display-control"],
            [4, "dadk-jupytertools-paretoplot-display-control"],
            [4, "dadk-jupytertools-traverse2plot-display-control"],
            [4, "dadk-jupytertools-traverseplot-display-control"]
        ],
        "NumberTable": [
            [4, "numbertable"]
        ],
        "csv_content": [
            [4, "csv-content"]
        ],
        "display_content": [
            [4, "display-content"]
        ],
        "get_summary": [
            [4, "get-summary"]
        ],
        "prepare_content": [
            [4, "prepare-content"]
        ],
        "text_content": [
            [4, "text-content"]
        ],
        "update_content": [
            [4, "update-content"]
        ],
        "OutputTab": [
            [4, "outputtab"]
        ],
        "display": [
            [4, "display"]
        ],
        "set_visibility": [
            [4, "set-visibility"]
        ],
        "ParetoPlot": [
            [4, "paretoplot"]
        ],
        "QuboEditor": [
            [4, "quboeditor"]
        ],
        "SetAnnealerProfile": [
            [4, "setannealerprofile"]
        ],
        "TaggedGuiControl": [
            [4, "taggedguicontrol"]
        ],
        "display_applier": [
            [4, "display-applier"]
        ],
        "display_creator": [
            [4, "display-creator"]
        ],
        "TimePicker(WidgetBoundedIntArray)": [
            [4, "timepicker-widgetboundedintarray"]
        ],
        "TimeReporter": [
            [4, "timereporter"]
        ],
        "report_fact": [
            [4, "report-fact"]
        ],
        "take_time": [
            [4, "take-time"]
        ],
        "TimeTracker": [
            [4, "timetracker"]
        ],
        "close": [
            [4, "close"]
        ],
        "Traverse2Plot": [
            [4, "traverse2plot"]
        ],
        "TraversePlot": [
            [4, "traverseplot"]
        ],
        "WidgetBoundedFloatArray(WidgetBoundedNumberArray)": [
            [4, "widgetboundedfloatarray-widgetboundednumberarray"]
        ],
        "WidgetBoundedFloatRange(WidgetBoundedNumberArray)": [
            [4, "widgetboundedfloatrange-widgetboundednumberarray"]
        ],
        "WidgetBoundedIntArray(WidgetBoundedNumberArray)": [
            [4, "widgetboundedintarray-widgetboundednumberarray"]
        ],
        "WidgetBoundedIntRange(WidgetBoundedNumberArray)": [
            [4, "widgetboundedintrange-widgetboundednumberarray"]
        ],
        "WidgetBoundedNumberArray(WidgetNumberArray)": [
            [4, "widgetboundednumberarray-widgetnumberarray"]
        ],
        "WidgetDefinition(dict)": [
            [4, "widgetdefinition-dict"]
        ],
        "WidgetFloatArray(WidgetNumberArray)": [
            [4, "widgetfloatarray-widgetnumberarray"]
        ],
        "WidgetFloatRange(WidgetNumberArray)": [
            [4, "widgetfloatrange-widgetnumberarray"]
        ],
        "WidgetGui(HBox)": [
            [4, "widgetgui-hbox"]
        ],
        "Staticmethod": [
            [4, "staticmethod"]
        ],
        "register_widget_class": [
            [4, "register-widget-class"]
        ],
        "call_function": [
            [4, "call-function"]
        ],
        "get_default_setting": [
            [4, "get-default-setting"]
        ],
        "get_persistent_setting": [
            [4, "get-persistent-setting"]
        ],
        "get_value": [
            [4, "get-value"]
        ],
        "get_widget": [
            [4, "get-widget"],
            [5, "get-widget"],
            [5, "dadk-optimizer-optimizertab-get-widget"]
        ],
        "gui_default_values": [
            [4, "gui-default-values"]
        ],
        "gui_reset_values": [
            [4, "gui-reset-values"]
        ],
        "gui_save_values": [
            [4, "gui-save-values"]
        ],
        "set_disabled": [
            [4, "set-disabled"],
            [5, "set-disabled"]
        ],
        "set_persistent_setting": [
            [4, "set-persistent-setting"]
        ],
        "trigger_change_handlers": [
            [4, "trigger-change-handlers"]
        ],
        "WidgetIntArray(WidgetNumberArray)": [
            [4, "widgetintarray-widgetnumberarray"]
        ],
        "WidgetIntRange(WidgetNumberArray)": [
            [4, "widgetintrange-widgetnumberarray"]
        ],
        "WidgetNumberArray(VBox)": [
            [4, "widgetnumberarray-vbox"]
        ],
        "WidgetTab(Tab)": [
            [4, "widgettab-tab"]
        ],
        "add_tab": [
            [4, "add-tab"]
        ],
        "remove_all_tabs": [
            [4, "remove-all-tabs"]
        ],
        "select_tab": [
            [4, "select-tab"]
        ],
        "set_title": [
            [4, "set-title"]
        ],
        "ShowSolverParameter": [
            [4, "showsolverparameter"]
        ],
        "get_active_parameters": [
            [4, "get-active-parameters"]
        ],
        "prolog": [
            [4, "prolog"]
        ],
        "Optimizer": [
            [5, "optimizer"]
        ],
        "Optimizer(Tab)": [
            [5, "optimizer-tab"]
        ],
        "create_batch": [
            [5, "create-batch"]
        ],
        "get_results": [
            [5, "get-results"]
        ],
        "gui_build": [
            [5, "gui-build"]
        ],
        "gui_solve": [
            [5, "gui-solve"]
        ],
        "load": [
            [5, "load"],
            [5, "dadk-optimizer-optimizermodelcomplex-load"]
        ],
        "optuna": [
            [5, "optuna"]
        ],
        "pareto": [
            [5, "pareto"]
        ],
        "run": [
            [5, "run"]
        ],
        "select_instance": [
            [5, "select-instance"]
        ],
        "set_build_qubo_details_reference": [
            [5, "set-build-qubo-details-reference"]
        ],
        "set_calculated_build_qubo_parameter": [
            [5, "set-calculated-build-qubo-parameter"]
        ],
        "set_calculated_solver_parameter": [
            [5, "set-calculated-solver-parameter"]
        ],
        "set_compose_model_details_reference": [
            [5, "set-compose-model-details-reference"]
        ],
        "set_fixed_solver_parameter": [
            [5, "set-fixed-solver-parameter"]
        ],
        "set_load_details_reference": [
            [5, "set-load-details-reference"]
        ],
        "set_prep_result_details_reference": [
            [5, "set-prep-result-details-reference"]
        ],
        "set_solver_parameter": [
            [5, "set-solver-parameter"]
        ],
        "tab_report": [
            [5, "tab-report"]
        ],
        "timeseries": [
            [5, "timeseries"]
        ],
        "OptimizerModel(OptimizerModelComplex)": [
            [5, "optimizermodel-optimizermodelcomplex"]
        ],
        "Methods (OptimizerModelComplex)": [
            [5, "methods-optimizermodelcomplex"]
        ],
        "Properties (OptimizerModelComplex)": [
            [5, "properties-optimizermodelcomplex"]
        ],
        "OptimizerModelComplex": [
            [5, "optimizermodelcomplex"]
        ],
        "build_and_solve": [
            [5, "build-and-solve"]
        ],
        "build_qubo": [
            [5, "build-qubo"]
        ],
        "get_time": [
            [5, "get-time"],
            [6, "get-time"]
        ],
        "log": [
            [5, "log"]
        ],
        "log_data": [
            [5, "log-data"]
        ],
        "prep_result": [
            [5, "prep-result"]
        ],
        "OptimizerSettings(_Settings)": [
            [5, "optimizersettings-settings"]
        ],
        "OptimizerSettings.AnnealingLogSettings(_Settings)": [
            [5, "optimizersettings-annealinglogsettings-settings"]
        ],
        "OptimizerSettings.BatchSettings(_Settings)": [
            [5, "optimizersettings-batchsettings-settings"]
        ],
        "OptimizerSettings.ComposeLogSettings(_Settings)": [
            [5, "optimizersettings-composelogsettings-settings"]
        ],
        "OptimizerSettings.ComposeSettings(_Settings)": [
            [5, "optimizersettings-composesettings-settings"]
        ],
        "OptimizerSettings.OptunaSettings(_Settings)": [
            [5, "optimizersettings-optunasettings-settings"]
        ],
        "OptimizerSettings.ParetoSettings(_Settings)": [
            [5, "optimizersettings-paretosettings-settings"]
        ],
        "OptimizerSettings.SamplingSettings(_Settings)": [
            [5, "optimizersettings-samplingsettings-settings"]
        ],
        "OptimizerSettings.SolveDAv2Settings(_Settings)": [
            [5, "optimizersettings-solvedav2settings-settings"]
        ],
        "OptimizerSettings.SolveDAv3Settings(_Settings)": [
            [5, "optimizersettings-solvedav3settings-settings"]
        ],
        "OptimizerSettings.SolveDAv3cSettings(_Settings)": [
            [5, "optimizersettings-solvedav3csettings-settings"]
        ],
        "OptimizerSettings.SolveDAv4Settings(_Settings)": [
            [5, "optimizersettings-solvedav4settings-settings"]
        ],
        "OptimizerSettings.SolveGUISettings(_Settings)": [
            [5, "optimizersettings-solveguisettings-settings"]
        ],
        "OptimizerSettings.TimeseriesSettings(_Settings)": [
            [5, "optimizersettings-timeseriessettings-settings"]
        ],
        "OptimizerTab(HBox)": [
            [5, "optimizertab-hbox"]
        ],
        "OptimizerTabRequirement(Enum)": [
            [5, "optimizertabrequirement-enum"]
        ],
        "Optimization Solutions": [
            [6, "optimization-solutions"]
        ],
        "BitArray": [
            [6, "bitarray"]
        ],
        "draw": [
            [6, "draw"],
            [6, "dadk-solution-solutionlist-solution-draw"]
        ],
        "evaluate": [
            [6, "evaluate"]
        ],
        "Solution": [
            [6, "solution"]
        ],
        "extract_bit_array": [
            [6, "extract-bit-array"],
            [6, "dadk-solution-solutionlist-varset-extract-bit-array"]
        ],
        "SolutionList": [
            [6, "solutionlist"]
        ],
        "display_graphs": [
            [6, "display-graphs"]
        ],
        "get_minimum_energy_solution": [
            [6, "get-minimum-energy-solution"]
        ],
        "get_solution_list": [
            [6, "get-solution-list"]
        ],
        "get_sorted_solution_list": [
            [6, "get-sorted-solution-list"]
        ],
        "get_times": [
            [6, "get-times"]
        ],
        "print_progress": [
            [6, "print-progress"]
        ],
        "print_stats": [
            [6, "print-stats"]
        ],
        "search_stats_info": [
            [6, "search-stats-info"]
        ],
        "VarSet": [
            [6, "varset"]
        ],
        "Solvers": [
            [7, "solvers"]
        ],
        "Overview": [
            [7, "overview"]
        ],
        "QUBOSolverDAv2(RestMixin, QUBOSolverBaseV2)": [
            [7, "qubosolverdav2-restmixin-qubosolverbasev2"]
        ],
        "get_parameter_definitions": [
            [7, "get-parameter-definitions"],
            [7, "dadk-qubosolverdav3-qubosolverdav3-get-parameter-definitions"],
            [7, "dadk-qubosolverdav3c-qubosolverdav3c-get-parameter-definitions"],
            [7, "dadk-qubosolverdav4-qubosolverdav4-get-parameter-definitions"],
            [7, "dadk-qubosolvercpu-qubosolvercpu-get-parameter-definitions"]
        ],
        "Methods (RestMixin)": [
            [7, "methods-restmixin"],
            [7, "id3"],
            [7, "id9"],
            [7, "id15"]
        ],
        "Methods (QUBOSolverBaseV2)": [
            [7, "methods-qubosolverbasev2"],
            [7, "id25"],
            [7, "id68"]
        ],
        "Methods (QUBOSolverBase)": [
            [7, "methods-qubosolverbase"],
            [7, "id4"],
            [7, "id10"],
            [7, "id20"],
            [7, "id26"],
            [7, "id37"],
            [7, "id44"],
            [7, "id52"],
            [7, "id60"],
            [7, "id69"]
        ],
        "Properties (QUBOSolverBaseV2)": [
            [7, "properties-qubosolverbasev2"],
            [7, "id27"],
            [7, "id70"]
        ],
        "Properties (QUBOSolverBase)": [
            [7, "properties-qubosolverbase"],
            [7, "id5"],
            [7, "id11"],
            [7, "id21"],
            [7, "id28"],
            [7, "id39"],
            [7, "id46"],
            [7, "id54"],
            [7, "id62"],
            [7, "id71"]
        ],
        "Properties (SolverBase)": [
            [7, "properties-solverbase"],
            [7, "id6"],
            [7, "id12"],
            [7, "id22"],
            [7, "id29"],
            [7, "id34"],
            [7, "id40"],
            [7, "id47"],
            [7, "id55"],
            [7, "id63"],
            [7, "id72"]
        ],
        "QUBOSolverDAv3(RestMixin, QUBOSolverBaseV3)": [
            [7, "qubosolverdav3-restmixin-qubosolverbasev3"]
        ],
        "Methods (QUBOSolverBaseV3)": [
            [7, "methods-qubosolverbasev3"]
        ],
        "Properties (QUBOSolverBaseV3)": [
            [7, "properties-qubosolverbasev3"]
        ],
        "QUBOSolverDAv3c(RestMixin, AzureBlobMixin, QUBOSolverBaseV3c)": [
            [7, "qubosolverdav3c-restmixin-azureblobmixin-qubosolverbasev3c"]
        ],
        "Methods (AzureBlobMixin)": [
            [7, "methods-azureblobmixin"],
            [7, "id16"]
        ],
        "Container": [
            [7, "container"],
            [7, "id17"]
        ],
        "Blob": [
            [7, "blob"],
            [7, "id18"]
        ],
        "Other": [
            [7, "other"],
            [7, "id19"],
            [9, "other"]
        ],
        "Methods (QUBOSolverBaseV3c)": [
            [7, "methods-qubosolverbasev3c"]
        ],
        "Properties (QUBOSolverBaseV3c)": [
            [7, "properties-qubosolverbasev3c"]
        ],
        "QUBOSolverDAv4(RestMixin, AzureBlobMixin, QUBOSolverBaseV4)": [
            [7, "qubosolverdav4-restmixin-azureblobmixin-qubosolverbasev4"]
        ],
        "Methods (QUBOSolverBaseV4)": [
            [7, "methods-qubosolverbasev4"]
        ],
        "Properties (QUBOSolverBaseV4)": [
            [7, "properties-qubosolverbasev4"]
        ],
        "QUBOSolverCPU(QUBOSolverEmulator)": [
            [7, "qubosolvercpu-qubosolveremulator"]
        ],
        "SolverFactory": [
            [7, "solverfactory"]
        ],
        "create_solver": [
            [7, "create-solver"]
        ],
        "get_solver_IDs": [
            [7, "get-solver-ids"]
        ],
        "has_solver": [
            [7, "has-solver"]
        ],
        "register_solver": [
            [7, "register-solver"]
        ],
        "QUBOSolverBase": [
            [7, "qubosolverbase"]
        ],
        "AzureBlobMixin": [
            [7, "azureblobmixin"]
        ],
        "AzureBlobMixin.Blob": [
            [7, "azureblobmixin-blob"]
        ],
        "AzureBlobMixin.ProgressBar": [
            [7, "azureblobmixin-progressbar"]
        ],
        "JobStatus": [
            [7, "jobstatus"]
        ],
        "QUBOSolverBase(SolverBase)": [
            [7, "qubosolverbase-solverbase"]
        ],
        "QUBOSolverBase.Job(SolverBase.AbstractJob)": [
            [7, "qubosolverbase-job-solverbase-abstractjob"]
        ],
        "Properties (SolverBase.AbstractJob)": [
            [7, "properties-solverbase-abstractjob"],
            [7, "id42"],
            [7, "id50"],
            [7, "id58"],
            [7, "id67"]
        ],
        "QUBOSolverBaseV2(QUBOSolverBase)": [
            [7, "qubosolverbasev2-qubosolverbase"]
        ],
        "QUBOSolverBaseV2.JobV2(QUBOSolverBase.Job)": [
            [7, "qubosolverbasev2-jobv2-qubosolverbase-job"]
        ],
        "Properties (QUBOSolverBase.Job)": [
            [7, "properties-qubosolverbase-job"],
            [7, "id49"],
            [7, "id57"],
            [7, "id66"]
        ],
        "QUBOSolverBaseV3(QUBOSolverBase)": [
            [7, "qubosolverbasev3-qubosolverbase"]
        ],
        "QUBOSolverBaseV3.JobV3(QUBOSolverBase.Job)": [
            [7, "qubosolverbasev3-jobv3-qubosolverbase-job"]
        ],
        "QUBOSolverBaseV3c(QUBOSolverBaseV3)": [
            [7, "qubosolverbasev3c-qubosolverbasev3"]
        ],
        "QUBOSolverBaseV3c.JobV3C(QUBOSolverBaseV3.JobV3)": [
            [7, "qubosolverbasev3c-jobv3c-qubosolverbasev3-jobv3"]
        ],
        "Properties (QUBOSolverBaseV3.JobV3)": [
            [7, "properties-qubosolverbasev3-jobv3"],
            [7, "id65"]
        ],
        "QUBOSolverBaseV4(QUBOSolverBaseV3)": [
            [7, "qubosolverbasev4-qubosolverbasev3"]
        ],
        "QUBOSolverBaseV4.JobV4(QUBOSolverBaseV3.JobV3)": [
            [7, "qubosolverbasev4-jobv4-qubosolverbasev3-jobv3"]
        ],
        "QUBOSolverEmulator(QUBOSolverBaseV2)": [
            [7, "qubosolveremulator-qubosolverbasev2"]
        ],
        "RestMixin": [
            [7, "restmixin"]
        ],
        "SolverBase(ABC)": [
            [7, "solverbase-abc"]
        ],
        "SolverBase.AbstractJob(ABC)": [
            [7, "solverbase-abstractjob-abc"]
        ],
        "file_size_info": [
            [7, "file-size-info"]
        ],
        "Utils": [
            [8, "utils"]
        ],
        "Tools": [
            [8, "tools"]
        ],
        "DirectoryManager": [
            [8, "directorymanager"]
        ],
        "InterruptKey": [
            [8, "interruptkey"]
        ],
        "JSONTools": [
            [8, "jsontools"]
        ],
        "DaoDecoder": [
            [8, "daodecoder"]
        ],
        "DaoEncoder(JSONEncoder)": [
            [8, "daoencoder-jsonencoder"]
        ],
        "dump_json": [
            [8, "dump-json"]
        ],
        "dumps_json": [
            [8, "dumps-json"]
        ],
        "load_json": [
            [8, "load-json"]
        ],
        "loads_json": [
            [8, "loads-json"]
        ],
        "ProfileUtils": [
            [8, "profileutils"],
            [8, "dadk-profileutils-profileutils"]
        ],
        "CoordinatesUtils": [
            [8, "coordinatesutils"],
            [8, "dadk-utils-coordinatesutils-coordinatesutils"]
        ],
        "TSPUtils": [
            [8, "tsputils"],
            [8, "dadk-utils-tsputils-tsputils"]
        ],
        "Constants": [
            [9, "constants"]
        ],
        "Enums": [
            [9, "enums"]
        ],
        "AutoTuning(Enum)": [
            [9, "autotuning-enum"]
        ],
        "ConnectionMethod(Enum)": [
            [9, "connectionmethod-enum"]
        ],
        "GraphicsDetail(Enum)": [
            [9, "graphicsdetail-enum"]
        ],
        "InequalitySign(Enum)": [
            [9, "inequalitysign-enum"]
        ],
        "OneHot(Enum)": [
            [9, "onehot-enum"]
        ],
        "RequestMode(Enum)": [
            [9, "requestmode-enum"]
        ],
        "ParameterLogging(Enum)": [
            [9, "parameterlogging-enum"]
        ],
        "SlackType(Enum)": [
            [9, "slacktype-enum"]
        ],
        "StorageAccountType(Enum)": [
            [9, "storageaccounttype-enum"]
        ],
        "Warnings": [
            [9, "warnings"]
        ],
        "MakeQuboWarning(ABC)": [
            [9, "makequbowarning-abc"]
        ],
        "MakeQuboNotUsedBitWarning(MakeQuboWarning)": [
            [9, "makequbonotusedbitwarning-makequbowarning"]
        ],
        "MakeQuboRoundedToZeroWarning(MakeQuboWarning)": [
            [9, "makequboroundedtozerowarning-makequbowarning"]
        ],
        "Exceptions": [
            [9, "exceptions"]
        ],
        "MakeQuboError(Exception)": [
            [9, "makequboerror-exception"]
        ],
        "QUBOSizeExceedsSolverMaxBits(Exception)": [
            [9, "qubosizeexceedssolvermaxbits-exception"]
        ],
        "QUBOSizeExceedsTimeseriesMaxBits(Exception)": [
            [9, "qubosizeexceedstimeseriesmaxbits-exception"]
        ],
        "activate_output": [
            [9, "activate-output"]
        ],
        "deactivate_output": [
            [9, "deactivate-output"]
        ],
        "configuration_2_string": [
            [9, "configuration-2-string"]
        ],
        "string_2_configuration": [
            [9, "string-2-configuration"]
        ],
        "dadk_version_check": [
            [9, "dadk-version-check"]
        ],
        "debug_exception": [
            [9, "debug-exception"]
        ],
        "get_logger": [
            [9, "get-logger"]
        ],
        "i18n_get": [
            [9, "i18n-get"]
        ],
        "load_library": [
            [9, "load-library"]
        ],
        "merge_dicts": [
            [9, "merge-dicts"]
        ],
        "print_to_output": [
            [9, "print-to-output"]
        ],
        "register_logging_output": [
            [9, "register-logging-output"]
        ],
        "register_timeit_output": [
            [9, "register-timeit-output"]
        ],
        "round_to_n": [
            [9, "round-to-n"]
        ],
        "timeit": [
            [9, "timeit"]
        ],
        "math_prod": [
            [9, "math-prod"]
        ],
        "Digital Annealer Development Kit": [
            [10, "digital-annealer-development-kit"]
        ],
        "Index": [
            [10, "index"]
        ],
        "Content": [
            [10, "content"]
        ]
    },
    "indexentries": {
        "bqp (class in dadk.binpol)": [
            [0, "dadk.BinPol.BQP"]
        ],
        "binpol (class in dadk.binpol)": [
            [0, "dadk.BinPol.BinPol"]
        ],
        "bitarrayshape (class in dadk.binpol)": [
            [0, "dadk.BinPol.BitArrayShape"]
        ],
        "category (class in dadk.binpol)": [
            [0, "dadk.BinPol.Category"]
        ],
        "inequality (class in dadk.binpol)": [
            [0, "dadk.BinPol.Inequality"]
        ],
        "isingpol (class in dadk.binpol)": [
            [0, "dadk.BinPol.IsingPol"]
        ],
        "n (dadk.binpol.binpol property)": [
            [0, "dadk.BinPol.BinPol.N"]
        ],
        "n (dadk.binpol.isingpol property)": [
            [0, "dadk.BinPol.IsingPol.N"]
        ],
        "onehotgroup (class in dadk.binpol)": [
            [0, "dadk.BinPol.OneHotGroup"]
        ],
        "partialconfig (class in dadk.binpol)": [
            [0, "dadk.BinPol.PartialConfig"]
        ],
        "samplefilter (class in dadk.binpol)": [
            [0, "dadk.BinPol.SampleFilter"]
        ],
        "term (class in dadk.binpol)": [
            [0, "dadk.BinPol.Term"]
        ],
        "twosideinequality (class in dadk.binpol)": [
            [0, "dadk.BinPol.TwoSideInequality"]
        ],
        "varshapeset (class in dadk.binpol)": [
            [0, "dadk.BinPol.VarShapeSet"]
        ],
        "varslack() (in module dadk.binpol)": [
            [0, "dadk.BinPol.VarSlack"]
        ],
        "variable (class in dadk.binpol)": [
            [0, "dadk.BinPol.Variable"]
        ],
        "variablebase10 (class in dadk.binpol)": [
            [0, "dadk.BinPol.VariableBase10"]
        ],
        "variablebinary (class in dadk.binpol)": [
            [0, "dadk.BinPol.VariableBinary"]
        ],
        "variablefibonacci (class in dadk.binpol)": [
            [0, "dadk.BinPol.VariableFibonacci"]
        ],
        "variablelittlegauss (class in dadk.binpol)": [
            [0, "dadk.BinPol.VariableLittlegauss"]
        ],
        "variablesequential (class in dadk.binpol)": [
            [0, "dadk.BinPol.VariableSequential"]
        ],
        "variableunary (class in dadk.binpol)": [
            [0, "dadk.BinPol.VariableUnary"]
        ],
        "add() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.add"]
        ],
        "add_exactly_1_bit_on() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.add_exactly_1_bit_on"]
        ],
        "add_exactly_n_bits_on() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.add_exactly_n_bits_on"]
        ],
        "add_json_lines() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.add_json_lines"]
        ],
        "add_most_1_bit_on() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.add_most_1_bit_on"]
        ],
        "add_slack_penalty() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.add_slack_penalty"]
        ],
        "add_slack_variable() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.add_slack_variable"]
        ],
        "add_term() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.add_term"]
        ],
        "add_term() (dadk.binpol.isingpol method)": [
            [0, "dadk.BinPol.IsingPol.add_term"]
        ],
        "as_bqm() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.as_bqm"]
        ],
        "as_json() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.as_json"]
        ],
        "as_json() (dadk.binpol.partialconfig method)": [
            [0, "dadk.BinPol.PartialConfig.as_json"]
        ],
        "as_latex() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.as_latex"]
        ],
        "as_latex() (dadk.binpol.inequality method)": [
            [0, "dadk.BinPol.Inequality.as_latex"]
        ],
        "as_latex() (dadk.binpol.isingpol method)": [
            [0, "dadk.BinPol.IsingPol.as_latex"]
        ],
        "as_latex() (dadk.binpol.twosideinequality method)": [
            [0, "dadk.BinPol.TwoSideInequality.as_latex"]
        ],
        "as_qbsolv() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.as_qbsolv"]
        ],
        "as_text() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.as_text"]
        ],
        "as_text() (dadk.binpol.inequality method)": [
            [0, "dadk.BinPol.Inequality.as_text"]
        ],
        "as_text() (dadk.binpol.isingpol method)": [
            [0, "dadk.BinPol.IsingPol.as_text"]
        ],
        "as_text() (dadk.binpol.twosideinequality method)": [
            [0, "dadk.BinPol.TwoSideInequality.as_text"]
        ],
        "calculate_hash() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.calculate_hash"]
        ],
        "clone() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.clone"]
        ],
        "clone() (dadk.binpol.inequality method)": [
            [0, "dadk.BinPol.Inequality.clone"]
        ],
        "clone() (dadk.binpol.samplefilter method)": [
            [0, "dadk.BinPol.SampleFilter.clone"]
        ],
        "compute() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.compute"]
        ],
        "compute() (dadk.binpol.inequality method)": [
            [0, "dadk.BinPol.Inequality.compute"]
        ],
        "compute() (dadk.binpol.term method)": [
            [0, "dadk.BinPol.Term.compute"]
        ],
        "convert_to_binary() (dadk.binpol.isingpol method)": [
            [0, "dadk.BinPol.IsingPol.convert_to_binary"]
        ],
        "create_random_state() (dadk.binpol.partialconfig method)": [
            [0, "dadk.BinPol.PartialConfig.create_random_state"]
        ],
        "crs2inequalities() (in module dadk.binpol)": [
            [0, "dadk.BinPol.crs2Inequalities"]
        ],
        "crs2qubo() (in module dadk.binpol)": [
            [0, "dadk.BinPol.crs2QUBO"]
        ],
        "degree (dadk.binpol.binpol property)": [
            [0, "dadk.BinPol.BinPol.degree"]
        ],
        "degree (dadk.binpol.isingpol property)": [
            [0, "dadk.BinPol.IsingPol.degree"]
        ],
        "entries (dadk.binpol.onehotgroup property)": [
            [0, "dadk.BinPol.OneHotGroup.entries"]
        ],
        "exactly_1_bit_on() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.exactly_1_bit_on"]
        ],
        "exactly_n_bits_on() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.exactly_n_bits_on"]
        ],
        "freeze_var_shape_set() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.freeze_var_shape_set"]
        ],
        "freeze_var_shape_set() (dadk.binpol.isingpol class method)": [
            [0, "dadk.BinPol.IsingPol.freeze_var_shape_set"]
        ],
        "generate_penalty_polynomial() (dadk.binpol.varshapeset method)": [
            [0, "dadk.BinPol.VarShapeSet.generate_penalty_polynomial"]
        ],
        "generate_slack_polynomial() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.generate_slack_polynomial"]
        ],
        "get_dict() (dadk.binpol.partialconfig method)": [
            [0, "dadk.BinPol.PartialConfig.get_dict"]
        ],
        "get_false_bit_indices() (dadk.binpol.varshapeset method)": [
            [0, "dadk.BinPol.VarShapeSet.get_false_bit_indices"]
        ],
        "get_free_bit_indices() (dadk.binpol.varshapeset method)": [
            [0, "dadk.BinPol.VarShapeSet.get_free_bit_indices"]
        ],
        "get_json() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.get_json"]
        ],
        "get_json_generator() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.get_json_generator"]
        ],
        "get_json_length() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.get_json_length"]
        ],
        "get_normalize_factor() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.get_normalize_factor"]
        ],
        "get_not_false_bit_indices() (dadk.binpol.varshapeset method)": [
            [0, "dadk.BinPol.VarShapeSet.get_not_false_bit_indices"]
        ],
        "get_scale_factor() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.get_scale_factor"]
        ],
        "get_true_bit_indices() (dadk.binpol.varshapeset method)": [
            [0, "dadk.BinPol.VarShapeSet.get_true_bit_indices"]
        ],
        "get_weights() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.get_weights"]
        ],
        "get_weights_sparse() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.get_weights_sparse"]
        ],
        "inequalities (dadk.binpol.bqp property)": [
            [0, "dadk.BinPol.BQP.inequalities"]
        ],
        "inequalities2crs() (in module dadk.binpol)": [
            [0, "dadk.BinPol.inequalities2CRS"]
        ],
        "inflate_clamped_configuration() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.inflate_clamped_configuration"]
        ],
        "lambda_value (dadk.binpol.inequality property)": [
            [0, "dadk.BinPol.Inequality.lambda_value"]
        ],
        "left_qubo (dadk.binpol.twosideinequality property)": [
            [0, "dadk.BinPol.TwoSideInequality.left_qubo"]
        ],
        "load_hdf5() (dadk.binpol.bqp class method)": [
            [0, "dadk.BinPol.BQP.load_hdf5"]
        ],
        "load_qbsolv() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.load_qbsolv"]
        ],
        "makequbo_precision (dadk.binpol.inequality property)": [
            [0, "dadk.BinPol.Inequality.makeQUBO_precision"]
        ],
        "makequbo_precision (dadk.binpol.samplefilter property)": [
            [0, "dadk.BinPol.SampleFilter.makeQUBO_precision"]
        ],
        "make_clamped() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.make_clamped"]
        ],
        "make_qubo() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.make_qubo"]
        ],
        "make_qubo() (dadk.binpol.inequality method)": [
            [0, "dadk.BinPol.Inequality.make_qubo"]
        ],
        "make_qubo() (dadk.binpol.samplefilter method)": [
            [0, "dadk.BinPol.SampleFilter.make_qubo"]
        ],
        "merge_var_shape_set() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.merge_var_shape_set"]
        ],
        "most_1_bit_on() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.most_1_bit_on"]
        ],
        "multiply() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.multiply"]
        ],
        "multiply_scalar() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.multiply_scalar"]
        ],
        "multiply_scalar() (dadk.binpol.inequality method)": [
            [0, "dadk.BinPol.Inequality.multiply_scalar"]
        ],
        "multiply_scalar() (dadk.binpol.samplefilter method)": [
            [0, "dadk.BinPol.SampleFilter.multiply_scalar"]
        ],
        "name (dadk.binpol.bitarrayshape property)": [
            [0, "dadk.BinPol.BitArrayShape.name"]
        ],
        "normalize() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.normalize"]
        ],
        "one_hot (dadk.binpol.binpol property)": [
            [0, "dadk.BinPol.BinPol.one_hot"]
        ],
        "one_hot (dadk.binpol.varshapeset property)": [
            [0, "dadk.BinPol.VarShapeSet.one_hot"]
        ],
        "p (dadk.binpol.binpol property)": [
            [0, "dadk.BinPol.BinPol.p"]
        ],
        "p (dadk.binpol.isingpol property)": [
            [0, "dadk.BinPol.IsingPol.p"]
        ],
        "penalty (dadk.binpol.variable property)": [
            [0, "dadk.BinPol.Variable.penalty"]
        ],
        "penalty_qubo (dadk.binpol.bqp property)": [
            [0, "dadk.BinPol.BQP.penalty_qubo"]
        ],
        "plot_connections() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.plot_connections"]
        ],
        "plot_histogram() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.plot_histogram"]
        ],
        "power() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.power"]
        ],
        "power2() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.power2"]
        ],
        "qubo (dadk.binpol.bqp property)": [
            [0, "dadk.BinPol.BQP.qubo"]
        ],
        "qubo (dadk.binpol.inequality property)": [
            [0, "dadk.BinPol.Inequality.qubo"]
        ],
        "qubo (dadk.binpol.samplefilter property)": [
            [0, "dadk.BinPol.SampleFilter.qubo"]
        ],
        "qubo (dadk.binpol.variable property)": [
            [0, "dadk.BinPol.Variable.qubo"]
        ],
        "qubo2crs() (in module dadk.binpol)": [
            [0, "dadk.BinPol.qubo2CRS"]
        ],
        "reduce_higher_degree() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.reduce_higher_degree"]
        ],
        "restore() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.restore"]
        ],
        "right_qubo (dadk.binpol.twosideinequality property)": [
            [0, "dadk.BinPol.TwoSideInequality.right_qubo"]
        ],
        "save_as_hdf5() (dadk.binpol.bqp method)": [
            [0, "dadk.BinPol.BQP.save_as_hdf5"]
        ],
        "scale() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.scale"]
        ],
        "set_clone_warning_counter() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.set_CLONE_WARNING_COUNTER"]
        ],
        "set_bit() (dadk.binpol.partialconfig method)": [
            [0, "dadk.BinPol.PartialConfig.set_bit"]
        ],
        "set_bits() (dadk.binpol.partialconfig method)": [
            [0, "dadk.BinPol.PartialConfig.set_bits"]
        ],
        "set_term() (dadk.binpol.binpol method)": [
            [0, "dadk.BinPol.BinPol.set_term"]
        ],
        "set_term() (dadk.binpol.isingpol method)": [
            [0, "dadk.BinPol.IsingPol.set_term"]
        ],
        "set_variable() (dadk.binpol.partialconfig method)": [
            [0, "dadk.BinPol.PartialConfig.set_variable"]
        ],
        "set_variables() (dadk.binpol.partialconfig method)": [
            [0, "dadk.BinPol.PartialConfig.set_variables"]
        ],
        "sign (dadk.binpol.twosideinequality property)": [
            [0, "dadk.BinPol.TwoSideInequality.sign"]
        ],
        "start (dadk.binpol.variable property)": [
            [0, "dadk.BinPol.Variable.start"]
        ],
        "step (dadk.binpol.variable property)": [
            [0, "dadk.BinPol.Variable.step"]
        ],
        "stop (dadk.binpol.variable property)": [
            [0, "dadk.BinPol.Variable.stop"]
        ],
        "sum() (dadk.binpol.binpol class method)": [
            [0, "dadk.BinPol.BinPol.sum"]
        ],
        "upper_limit (dadk.binpol.samplefilter property)": [
            [0, "dadk.BinPol.SampleFilter.upper_limit"]
        ],
        "values (dadk.binpol.category property)": [
            [0, "dadk.BinPol.Category.values"]
        ],
        "var_shape_set (dadk.binpol.inequality property)": [
            [0, "dadk.BinPol.Inequality.var_shape_set"]
        ],
        "var_shape_set (dadk.binpol.samplefilter property)": [
            [0, "dadk.BinPol.SampleFilter.var_shape_set"]
        ],
        "binpolgen (class in dadk.binpolgen)": [
            [1, "dadk.BinPolGen.BinPolGen"]
        ],
        "gen_latex() (dadk.binpolgen.binpolgen method)": [
            [1, "dadk.BinPolGen.BinPolGen.gen_latex"]
        ],
        "gen_pretty_string() (dadk.binpolgen.binpolgen method)": [
            [1, "dadk.BinPolGen.BinPolGen.gen_pretty_string"]
        ],
        "gen_python() (dadk.binpolgen.binpolgen method)": [
            [1, "dadk.BinPolGen.BinPolGen.gen_python"]
        ],
        "parse_poly() (dadk.binpolgen.binpolgen method)": [
            [1, "dadk.BinPolGen.BinPolGen.parse_poly"]
        ],
        "source (dadk.binpolgen.binpolgen property)": [
            [1, "dadk.BinPolGen.BinPolGen.source"]
        ],
        "tree (dadk.binpolgen.binpolgen property)": [
            [1, "dadk.BinPolGen.BinPolGen.tree"]
        ],
        "boltzmannsampling (class in dadk.internal.samplingutilities)": [
            [2, "dadk.internal.SamplingUtilities.BoltzmannSampling"]
        ],
        "connectionparameter (class in dadk.internal.connectionparameter)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter"]
        ],
        "dav2parameter (class in dadk.internal.dav2parameter)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter"]
        ],
        "dav3parameter (class in dadk.internal.dav3parameter)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter"]
        ],
        "dav4parameter (class in dadk.internal.dav4parameter)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter"]
        ],
        "energylandscapesampling (class in dadk.internal.samplingutilities)": [
            [2, "dadk.internal.SamplingUtilities.EnergyLandscapeSampling"]
        ],
        "graphicsdata (class in dadk.internal.graphicsdata)": [
            [2, "dadk.internal.GraphicsData.GraphicsData"]
        ],
        "paralleltemperingmanagement (class in dadk.internal.paralleltemperingutilities)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ParallelTemperingManagement"]
        ],
        "replicaexchangemodel (class in dadk.internal.paralleltemperingutilities)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModel"]
        ],
        "replicaexchangemodelfarjump (class in dadk.internal.paralleltemperingutilities)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModelFarJump"]
        ],
        "samplingbasis (class in dadk.internal.samplingutilities)": [
            [2, "dadk.internal.SamplingUtilities.SamplingBasis"]
        ],
        "solvertimes (class in dadk.internal.solvertimes)": [
            [2, "dadk.internal.SolverTimes.SolverTimes"]
        ],
        "temperaturemodel (class in dadk.internal.paralleltemperingutilities)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModel"]
        ],
        "temperaturemodelexponential (class in dadk.internal.paralleltemperingutilities)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModelExponential"]
        ],
        "temperaturemodelhukushima (class in dadk.internal.paralleltemperingutilities)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModelHukushima"]
        ],
        "temperaturemodellinear (class in dadk.internal.paralleltemperingutilities)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModelLinear"]
        ],
        "tuningparameter (class in dadk.internal.tuningparameter)": [
            [2, "dadk.internal.TuningParameter.TuningParameter"]
        ],
        "annealer_address (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.annealer_address"]
        ],
        "annealer_path (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.annealer_path"]
        ],
        "annealer_port (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.annealer_port"]
        ],
        "annealer_protocol (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.annealer_protocol"]
        ],
        "annealer_queue_size (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.annealer_queue_size"]
        ],
        "annealing_steps (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.annealing_steps"]
        ],
        "api_key (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.api_key"]
        ],
        "audience (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.audience"]
        ],
        "auto_tuning (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.auto_tuning"]
        ],
        "bit_flips (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.bit_flips"]
        ],
        "bit_precision (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.bit_precision"]
        ],
        "clientid (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.clientid"]
        ],
        "clientsecret (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.clientsecret"]
        ],
        "connection_method (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.connection_method"]
        ],
        "connection_mode (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.connection_mode"]
        ],
        "container_name (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.container_name"]
        ],
        "dict (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.dict"]
        ],
        "dict (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.dict"]
        ],
        "dict (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.dict"]
        ],
        "dict (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.dict"]
        ],
        "dict (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.dict"]
        ],
        "do_sampling() (dadk.internal.samplingutilities.energylandscapesampling method)": [
            [2, "dadk.internal.SamplingUtilities.EnergyLandscapeSampling.do_sampling"]
        ],
        "do_sampling() (dadk.internal.samplingutilities.samplingbasis method)": [
            [2, "dadk.internal.SamplingUtilities.SamplingBasis.do_sampling"]
        ],
        "domain (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.domain"]
        ],
        "duration_account_occupied (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_account_occupied"]
        ],
        "duration_anneal (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_anneal"]
        ],
        "duration_cpu (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_cpu"]
        ],
        "duration_dau_service (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_dau_service"]
        ],
        "duration_elapsed (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_elapsed"]
        ],
        "duration_execution (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_execution"]
        ],
        "duration_occupied (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_occupied"]
        ],
        "duration_parse_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_parse_response"]
        ],
        "duration_prepare_qubo (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_prepare_qubo"]
        ],
        "duration_prepare_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_prepare_request"]
        ],
        "duration_queue (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_queue"]
        ],
        "duration_receive_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_receive_response"]
        ],
        "duration_save_bqp (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_save_bqp"]
        ],
        "duration_save_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_save_request"]
        ],
        "duration_save_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_save_response"]
        ],
        "duration_send_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_send_request"]
        ],
        "duration_solve (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_solve"]
        ],
        "duration_tuning (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_tuning"]
        ],
        "duration_waiting (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_waiting"]
        ],
        "duration_waiting_2_finish (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_waiting_2_finish"]
        ],
        "duration_waiting_2_start (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.duration_waiting_2_start"]
        ],
        "end_account_occupied (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_account_occupied"]
        ],
        "end_anneal (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_anneal"]
        ],
        "end_cpu (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_cpu"]
        ],
        "end_dau_service (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_dau_service"]
        ],
        "end_elapsed (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_elapsed"]
        ],
        "end_execution (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_execution"]
        ],
        "end_occupied (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_occupied"]
        ],
        "end_parse_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_parse_response"]
        ],
        "end_prepare_qubo (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_prepare_qubo"]
        ],
        "end_prepare_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_prepare_request"]
        ],
        "end_progress_probability (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.end_progress_probability"]
        ],
        "end_queue (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_queue"]
        ],
        "end_receive_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_receive_response"]
        ],
        "end_save_bqp (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_save_bqp"]
        ],
        "end_save_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_save_request"]
        ],
        "end_save_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_save_response"]
        ],
        "end_send_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_send_request"]
        ],
        "end_solve (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_solve"]
        ],
        "end_tuning (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_tuning"]
        ],
        "end_waiting (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_waiting"]
        ],
        "end_waiting_2_finish (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_waiting_2_finish"]
        ],
        "end_waiting_2_start (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.end_waiting_2_start"]
        ],
        "energies (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.energies"]
        ],
        "furnace_mean_energy_list (dadk.internal.samplingutilities.boltzmannsampling property)": [
            [2, "dadk.internal.SamplingUtilities.BoltzmannSampling.furnace_mean_energy_list"]
        ],
        "furnace_process_length (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.furnace_process_length"]
        ],
        "furnace_replica_list (dadk.internal.paralleltemperingutilities.replicaexchangemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModel.furnace_replica_list"]
        ],
        "furnaces_replica_history (dadk.internal.paralleltemperingutilities.replicaexchangemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModel.furnaces_replica_history"]
        ],
        "generate_replica_furnace_exchange_step() (dadk.internal.paralleltemperingutilities.paralleltemperingmanagement method)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ParallelTemperingManagement.generate_replica_furnace_exchange_step"]
        ],
        "graphics (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.graphics"]
        ],
        "graphics (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.graphics"]
        ],
        "gs_max_penalty_coef (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.gs_max_penalty_coef"]
        ],
        "gs_max_penalty_coef (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.gs_max_penalty_coef"]
        ],
        "gs_num_iteration_cl (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.gs_num_iteration_cl"]
        ],
        "gs_num_iteration_cl (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.gs_num_iteration_cl"]
        ],
        "gs_num_iteration_factor (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.gs_num_iteration_factor"]
        ],
        "gs_num_iteration_factor (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.gs_num_iteration_factor"]
        ],
        "gs_ohs_xw1h_num_iteration_cl (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.gs_ohs_xw1h_num_iteration_cl"]
        ],
        "gs_ohs_xw1h_num_iteration_factor (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.gs_ohs_xw1h_num_iteration_factor"]
        ],
        "gs_penalty_auto_mode (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.gs_penalty_auto_mode"]
        ],
        "gs_penalty_auto_mode (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.gs_penalty_auto_mode"]
        ],
        "gs_penalty_coef (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.gs_penalty_coef"]
        ],
        "gs_penalty_coef (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.gs_penalty_coef"]
        ],
        "gs_penalty_inc_rate (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.gs_penalty_inc_rate"]
        ],
        "gs_penalty_inc_rate (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.gs_penalty_inc_rate"]
        ],
        "hill_energies (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.hill_energies"]
        ],
        "hill_steps (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.hill_steps"]
        ],
        "ignore_proxy (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.ignore_proxy"]
        ],
        "inequalities_blob_name (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.inequalities_blob_name"]
        ],
        "inequalities_filename (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.inequalities_filename"]
        ],
        "logger (dadk.internal.paralleltemperingutilities.replicaexchangemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModel.logger"]
        ],
        "logger (dadk.internal.paralleltemperingutilities.temperaturemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModel.logger"]
        ],
        "logger (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.logger"]
        ],
        "mean_abs_energy_delta (dadk.internal.samplingutilities.energylandscapesampling property)": [
            [2, "dadk.internal.SamplingUtilities.EnergyLandscapeSampling.mean_abs_energy_delta"]
        ],
        "mean_escape_energy (dadk.internal.samplingutilities.energylandscapesampling property)": [
            [2, "dadk.internal.SamplingUtilities.EnergyLandscapeSampling.mean_escape_energy"]
        ],
        "min_energy (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.min_energy"]
        ],
        "min_step (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.min_step"]
        ],
        "num_group (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.num_group"]
        ],
        "num_group (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.num_group"]
        ],
        "num_output_solution (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.num_output_solution"]
        ],
        "num_output_solution (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.num_output_solution"]
        ],
        "num_solution (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.num_solution"]
        ],
        "num_solution (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.num_solution"]
        ],
        "number_iterations (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.number_iterations"]
        ],
        "number_of_bits (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.number_of_bits"]
        ],
        "number_of_hills (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.number_of_hills"]
        ],
        "number_of_valleys (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.number_of_valleys"]
        ],
        "number_of_walks (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.number_of_walks"]
        ],
        "number_replicas (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.number_replicas"]
        ],
        "number_runs (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.number_runs"]
        ],
        "offline_request_file (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.offline_request_file"]
        ],
        "offline_response_file (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.offline_response_file"]
        ],
        "offset_increase_rate (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.offset_increase_rate"]
        ],
        "ohs_xw1h_internal_penalty (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.ohs_xw1h_internal_penalty"]
        ],
        "optimization_method (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.optimization_method"]
        ],
        "optimization_method (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.optimization_method"]
        ],
        "penalty_qubo_blob_name (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.penalty_qubo_blob_name"]
        ],
        "penalty_qubo_filename (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.penalty_qubo_filename"]
        ],
        "plot_graphs() (dadk.internal.graphicsdata.graphicsdata method)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.plot_graphs"]
        ],
        "plot_temperature_curve() (dadk.internal.dav2parameter.dav2parameter method)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.plot_temperature_curve"]
        ],
        "prolog_blob_name (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.prolog_blob_name"]
        ],
        "prolog_filename (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.prolog_filename"]
        ],
        "proxy (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.proxy"]
        ],
        "proxy_password (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.proxy_password"]
        ],
        "proxy_port (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.proxy_port"]
        ],
        "proxy_user (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.proxy_user"]
        ],
        "pt_replica_exchange_model (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.pt_replica_exchange_model"]
        ],
        "pt_temperature_model (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.pt_temperature_model"]
        ],
        "qubo_blob_name (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.qubo_blob_name"]
        ],
        "qubo_filename (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.qubo_filename"]
        ],
        "randomwalk_count (dadk.internal.samplingutilities.boltzmannsampling property)": [
            [2, "dadk.internal.SamplingUtilities.BoltzmannSampling.randomwalk_count"]
        ],
        "randomwalk_length (dadk.internal.samplingutilities.boltzmannsampling property)": [
            [2, "dadk.internal.SamplingUtilities.BoltzmannSampling.randomwalk_length"]
        ],
        "replica_count (dadk.internal.paralleltemperingutilities.temperaturemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModel.replica_count"]
        ],
        "replica_exchange_count (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.replica_exchange_count"]
        ],
        "replica_furnace_history (dadk.internal.paralleltemperingutilities.paralleltemperingmanagement property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ParallelTemperingManagement.replica_furnace_history"]
        ],
        "replica_furnace_history (dadk.internal.paralleltemperingutilities.replicaexchangemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModel.replica_furnace_history"]
        ],
        "replica_furnace_list (dadk.internal.paralleltemperingutilities.replicaexchangemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModel.replica_furnace_list"]
        ],
        "replica_history (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.replica_history"]
        ],
        "replica_temperature_list (dadk.internal.paralleltemperingutilities.paralleltemperingmanagement property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ParallelTemperingManagement.replica_temperature_list"]
        ],
        "replica_temperature_list (dadk.internal.paralleltemperingutilities.replicaexchangemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.ReplicaExchangeModel.replica_temperature_list"]
        ],
        "request_mode (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.request_mode"]
        ],
        "rest_version_enforced (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.rest_version_enforced"]
        ],
        "sampling_distance (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.sampling_distance"]
        ],
        "sampling_walk_count (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.sampling_walk_count"]
        ],
        "sampling_walk_length (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.sampling_walk_length"]
        ],
        "sas_token (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.sas_token"]
        ],
        "scaling_bit_precision (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.scaling_bit_precision"]
        ],
        "scaling_factor (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.scaling_factor"]
        ],
        "solution_mode (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.solution_mode"]
        ],
        "ssl_disable_warnings (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.ssl_disable_warnings"]
        ],
        "ssl_verify (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.ssl_verify"]
        ],
        "start_account_occupied (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_account_occupied"]
        ],
        "start_anneal (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_anneal"]
        ],
        "start_cpu (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_cpu"]
        ],
        "start_dau_service (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_dau_service"]
        ],
        "start_elapsed (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_elapsed"]
        ],
        "start_execution (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_execution"]
        ],
        "start_occupied (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_occupied"]
        ],
        "start_parse_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_parse_response"]
        ],
        "start_prepare_qubo (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_prepare_qubo"]
        ],
        "start_prepare_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_prepare_request"]
        ],
        "start_progress_probability (dadk.internal.tuningparameter.tuningparameter property)": [
            [2, "dadk.internal.TuningParameter.TuningParameter.start_progress_probability"]
        ],
        "start_queue (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_queue"]
        ],
        "start_receive_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_receive_response"]
        ],
        "start_save_bqp (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_save_bqp"]
        ],
        "start_save_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_save_request"]
        ],
        "start_save_response (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_save_response"]
        ],
        "start_send_request (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_send_request"]
        ],
        "start_solve (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_solve"]
        ],
        "start_tuning (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_tuning"]
        ],
        "start_waiting (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_waiting"]
        ],
        "start_waiting_2_finish (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_waiting_2_finish"]
        ],
        "start_waiting_2_start (dadk.internal.solvertimes.solvertimes property)": [
            [2, "dadk.internal.SolverTimes.SolverTimes.start_waiting_2_start"]
        ],
        "storage_account_name (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.storage_account_name"]
        ],
        "storage_account_type (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.storage_account_type"]
        ],
        "storage_connection_string (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.storage_connection_string"]
        ],
        "target_energy (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.target_energy"]
        ],
        "target_energy (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.target_energy"]
        ],
        "temperature_decay (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.temperature_decay"]
        ],
        "temperature_end (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.temperature_end"]
        ],
        "temperature_high (dadk.internal.paralleltemperingutilities.temperaturemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModel.temperature_high"]
        ],
        "temperature_interval (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.temperature_interval"]
        ],
        "temperature_list (dadk.internal.paralleltemperingutilities.temperaturemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModel.temperature_list"]
        ],
        "temperature_low (dadk.internal.paralleltemperingutilities.temperaturemodel property)": [
            [2, "dadk.internal.ParallelTemperingUtilities.TemperatureModel.temperature_low"]
        ],
        "temperature_mode (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.temperature_mode"]
        ],
        "temperature_mode_txt (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.temperature_mode_txt"]
        ],
        "temperature_start (dadk.internal.dav2parameter.dav2parameter property)": [
            [2, "dadk.internal.DAv2Parameter.DAv2Parameter.temperature_start"]
        ],
        "temperatures (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.temperatures"]
        ],
        "time_limit_sec (dadk.internal.dav3parameter.dav3parameter property)": [
            [2, "dadk.internal.DAv3Parameter.DAv3Parameter.time_limit_sec"]
        ],
        "time_limit_sec (dadk.internal.dav4parameter.dav4parameter property)": [
            [2, "dadk.internal.DAv4Parameter.DAv4Parameter.time_limit_sec"]
        ],
        "timeout (dadk.internal.connectionparameter.connectionparameter property)": [
            [2, "dadk.internal.ConnectionParameter.ConnectionParameter.timeout"]
        ],
        "valley_energies (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.valley_energies"]
        ],
        "valley_steps (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.valley_steps"]
        ],
        "wait_cycles (dadk.internal.graphicsdata.graphicsdata property)": [
            [2, "dadk.internal.GraphicsData.GraphicsData.wait_cycles"]
        ],
        "cleanupazureblobstorage (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.CleanupAzureBlobStorage"]
        ],
        "cleanupjobs (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.CleanupJobs"]
        ],
        "datetimepicker (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.DatetimePicker"]
        ],
        "directoryselector (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.DirectorySelector"]
        ],
        "fileselector (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.FileSelector"]
        ],
        "numberplot (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.NumberPlot"]
        ],
        "numbertable (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.NumberTable"]
        ],
        "outputtab (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.OutputTab"]
        ],
        "paretoplot (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.ParetoPlot"]
        ],
        "quboeditor (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.QuboEditor"]
        ],
        "setannealerprofile (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.SetAnnealerProfile"]
        ],
        "showsolverparameter() (in module dadk.jupytertools)": [
            [4, "dadk.JupyterTools.ShowSolverParameter"]
        ],
        "taggedguicontrol (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.TaggedGuiControl"]
        ],
        "timepicker (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.TimePicker"]
        ],
        "timereporter (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.TimeReporter"]
        ],
        "timetracker (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.TimeTracker"]
        ],
        "traverse2plot (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.Traverse2Plot"]
        ],
        "traverseplot (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.TraversePlot"]
        ],
        "widgetboundedfloatarray (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetBoundedFloatArray"]
        ],
        "widgetboundedfloatrange (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetBoundedFloatRange"]
        ],
        "widgetboundedintarray (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetBoundedIntArray"]
        ],
        "widgetboundedintrange (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetBoundedIntRange"]
        ],
        "widgetboundednumberarray (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetBoundedNumberArray"]
        ],
        "widgetdefinition (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetDefinition"]
        ],
        "widgetfloatarray (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetFloatArray"]
        ],
        "widgetfloatrange (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetFloatRange"]
        ],
        "widgetgui (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetGui"]
        ],
        "widgetintarray (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetIntArray"]
        ],
        "widgetintrange (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetIntRange"]
        ],
        "widgetnumberarray (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetNumberArray"]
        ],
        "widgettab (class in dadk.jupytertools)": [
            [4, "dadk.JupyterTools.WidgetTab"]
        ],
        "add() (dadk.jupytertools.timetracker method)": [
            [4, "dadk.JupyterTools.TimeTracker.add"]
        ],
        "add_figure() (dadk.jupytertools.numberplot method)": [
            [4, "dadk.JupyterTools.NumberPlot.add_figure"]
        ],
        "add_figure() (dadk.jupytertools.paretoplot method)": [
            [4, "dadk.JupyterTools.ParetoPlot.add_figure"]
        ],
        "add_figure() (dadk.jupytertools.traverse2plot method)": [
            [4, "dadk.JupyterTools.Traverse2Plot.add_figure"]
        ],
        "add_figure() (dadk.jupytertools.traverseplot method)": [
            [4, "dadk.JupyterTools.TraversePlot.add_figure"]
        ],
        "add_tab() (dadk.jupytertools.widgettab method)": [
            [4, "dadk.JupyterTools.WidgetTab.add_tab"]
        ],
        "applier (dadk.jupytertools.taggedguicontrol property)": [
            [4, "dadk.JupyterTools.TaggedGuiControl.applier"]
        ],
        "call_function() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.call_function"]
        ],
        "close() (dadk.jupytertools.timetracker method)": [
            [4, "dadk.JupyterTools.TimeTracker.close"]
        ],
        "columns (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.columns"]
        ],
        "creator (dadk.jupytertools.taggedguicontrol property)": [
            [4, "dadk.JupyterTools.TaggedGuiControl.creator"]
        ],
        "csv_content() (dadk.jupytertools.numbertable method)": [
            [4, "dadk.JupyterTools.NumberTable.csv_content"]
        ],
        "description (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.description"]
        ],
        "disabled (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.disabled"]
        ],
        "display() (dadk.jupytertools.outputtab method)": [
            [4, "dadk.JupyterTools.OutputTab.display"]
        ],
        "display_applier() (dadk.jupytertools.taggedguicontrol method)": [
            [4, "dadk.JupyterTools.TaggedGuiControl.display_applier"]
        ],
        "display_content() (dadk.jupytertools.numbertable method)": [
            [4, "dadk.JupyterTools.NumberTable.display_content"]
        ],
        "display_control() (dadk.jupytertools.numberplot method)": [
            [4, "dadk.JupyterTools.NumberPlot.display_control"]
        ],
        "display_control() (dadk.jupytertools.paretoplot method)": [
            [4, "dadk.JupyterTools.ParetoPlot.display_control"]
        ],
        "display_control() (dadk.jupytertools.traverse2plot method)": [
            [4, "dadk.JupyterTools.Traverse2Plot.display_control"]
        ],
        "display_control() (dadk.jupytertools.traverseplot method)": [
            [4, "dadk.JupyterTools.TraversePlot.display_control"]
        ],
        "display_creator() (dadk.jupytertools.taggedguicontrol method)": [
            [4, "dadk.JupyterTools.TaggedGuiControl.display_creator"]
        ],
        "file (dadk.jupytertools.fileselector property)": [
            [4, "dadk.JupyterTools.FileSelector.file"]
        ],
        "get_active_parameters() (in module dadk.jupytertools)": [
            [4, "dadk.JupyterTools.get_active_parameters"]
        ],
        "get_default_setting() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.get_default_setting"]
        ],
        "get_persistent_setting() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.get_persistent_setting"]
        ],
        "get_summary() (dadk.jupytertools.numbertable method)": [
            [4, "dadk.JupyterTools.NumberTable.get_summary"]
        ],
        "get_value() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.get_value"]
        ],
        "get_widget() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.get_widget"]
        ],
        "gui_default_values() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.gui_default_values"]
        ],
        "gui_reset_values() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.gui_reset_values"]
        ],
        "gui_save_values() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.gui_save_values"]
        ],
        "headers (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.headers"]
        ],
        "label (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.label"]
        ],
        "max (dadk.jupytertools.widgetboundednumberarray property)": [
            [4, "dadk.JupyterTools.WidgetBoundedNumberArray.max"]
        ],
        "min (dadk.jupytertools.widgetboundednumberarray property)": [
            [4, "dadk.JupyterTools.WidgetBoundedNumberArray.min"]
        ],
        "on_change_code (dadk.jupytertools.fileselector property)": [
            [4, "dadk.JupyterTools.FileSelector.on_change_code"]
        ],
        "path (dadk.jupytertools.fileselector property)": [
            [4, "dadk.JupyterTools.FileSelector.path"]
        ],
        "prepare_content() (dadk.jupytertools.numbertable method)": [
            [4, "dadk.JupyterTools.NumberTable.prepare_content"]
        ],
        "prolog() (in module dadk.jupytertools)": [
            [4, "dadk.JupyterTools.prolog"]
        ],
        "register_widget_class() (dadk.jupytertools.widgetgui static method)": [
            [4, "dadk.JupyterTools.WidgetGui.register_widget_class"]
        ],
        "remove_all_tabs() (dadk.jupytertools.widgettab method)": [
            [4, "dadk.JupyterTools.WidgetTab.remove_all_tabs"]
        ],
        "report_fact() (dadk.jupytertools.timereporter method)": [
            [4, "dadk.JupyterTools.TimeReporter.report_fact"]
        ],
        "row_labels (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.row_labels"]
        ],
        "rows (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.rows"]
        ],
        "select_tab() (dadk.jupytertools.widgettab method)": [
            [4, "dadk.JupyterTools.WidgetTab.select_tab"]
        ],
        "set_directory() (dadk.jupytertools.directoryselector method)": [
            [4, "dadk.JupyterTools.DirectorySelector.set_directory"]
        ],
        "set_disabled() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.set_disabled"]
        ],
        "set_persistent_setting() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.set_persistent_setting"]
        ],
        "set_title() (dadk.jupytertools.widgettab method)": [
            [4, "dadk.JupyterTools.WidgetTab.set_title"]
        ],
        "set_value() (dadk.jupytertools.fileselector method)": [
            [4, "dadk.JupyterTools.FileSelector.set_value"]
        ],
        "set_value() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.set_value"]
        ],
        "set_visibility() (dadk.jupytertools.outputtab method)": [
            [4, "dadk.JupyterTools.OutputTab.set_visibility"]
        ],
        "silent (dadk.jupytertools.timereporter property)": [
            [4, "dadk.JupyterTools.TimeReporter.silent"]
        ],
        "step (dadk.jupytertools.widgetboundednumberarray property)": [
            [4, "dadk.JupyterTools.WidgetBoundedNumberArray.step"]
        ],
        "tab_out (dadk.jupytertools.outputtab property)": [
            [4, "dadk.JupyterTools.OutputTab.tab_out"]
        ],
        "take_time() (dadk.jupytertools.timereporter method)": [
            [4, "dadk.JupyterTools.TimeReporter.take_time"]
        ],
        "text_content() (dadk.jupytertools.numbertable method)": [
            [4, "dadk.JupyterTools.NumberTable.text_content"]
        ],
        "trigger_change_handlers() (dadk.jupytertools.widgetgui method)": [
            [4, "dadk.JupyterTools.WidgetGui.trigger_change_handlers"]
        ],
        "update_content() (dadk.jupytertools.numbertable method)": [
            [4, "dadk.JupyterTools.NumberTable.update_content"]
        ],
        "value (dadk.jupytertools.datetimepicker property)": [
            [4, "dadk.JupyterTools.DatetimePicker.value"]
        ],
        "value (dadk.jupytertools.fileselector property)": [
            [4, "dadk.JupyterTools.FileSelector.value"]
        ],
        "value (dadk.jupytertools.timepicker property)": [
            [4, "dadk.JupyterTools.TimePicker.value"]
        ],
        "value (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.value"]
        ],
        "visible (dadk.jupytertools.widgetnumberarray property)": [
            [4, "dadk.JupyterTools.WidgetNumberArray.visible"]
        ],
        "annealinglogsettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings"]
        ],
        "batchsettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.BatchSettings"]
        ],
        "composelogsettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeLogSettings"]
        ],
        "composesettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeSettings"]
        ],
        "optimizer (class in dadk.optimizer)": [
            [5, "dadk.Optimizer.Optimizer"]
        ],
        "optimizer (dadk.optimizer.optimizermodelcomplex property)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.Optimizer"]
        ],
        "optimizermodel (class in dadk.optimizer)": [
            [5, "dadk.Optimizer.OptimizerModel"]
        ],
        "optimizermodelcomplex (class in dadk.optimizer)": [
            [5, "dadk.Optimizer.OptimizerModelComplex"]
        ],
        "optimizersettings (class in dadk.optimizer)": [
            [5, "dadk.Optimizer.OptimizerSettings"]
        ],
        "optimizertab (class in dadk.optimizer)": [
            [5, "dadk.Optimizer.OptimizerTab"]
        ],
        "optimizertabrequirement (class in dadk.optimizer)": [
            [5, "dadk.Optimizer.OptimizerTabRequirement"]
        ],
        "optunasettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.OptunaSettings"]
        ],
        "paretosettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.ParetoSettings"]
        ],
        "samplingsettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.SamplingSettings"]
        ],
        "solvedav2settings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv2Settings"]
        ],
        "solvedav3settings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv3Settings"]
        ],
        "solvedav3csettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv3cSettings"]
        ],
        "solvedav4settings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv4Settings"]
        ],
        "solveguisettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveGUISettings"]
        ],
        "timeseriessettings (class in dadk.optimizer.optimizersettings)": [
            [5, "dadk.Optimizer.OptimizerSettings.TimeseriesSettings"]
        ],
        "annealing_log (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.annealing_log"]
        ],
        "batch (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.batch"]
        ],
        "build_and_solve() (dadk.optimizer.optimizermodelcomplex method)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.build_and_solve"]
        ],
        "build_qubo() (dadk.optimizer.optimizermodelcomplex method)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.build_qubo"]
        ],
        "button_width (dadk.optimizer.optimizersettings.solveguisettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveGUISettings.button_width"]
        ],
        "compose (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.compose"]
        ],
        "compose_log (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.compose_log"]
        ],
        "create_batch() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.create_batch"]
        ],
        "create_summary_excel (dadk.optimizer.optimizersettings.composesettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeSettings.create_summary_excel"]
        ],
        "delete_files (dadk.optimizer.optimizersettings.optunasettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.OptunaSettings.delete_files"]
        ],
        "delete_files (dadk.optimizer.optimizersettings.paretosettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ParetoSettings.delete_files"]
        ],
        "delete_files (dadk.optimizer.optimizersettings.timeseriessettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.TimeseriesSettings.delete_files"]
        ],
        "description_width (dadk.optimizer.optimizersettings.solveguisettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveGUISettings.description_width"]
        ],
        "excel_summary_columns (dadk.optimizer.optimizersettings.composesettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeSettings.excel_summary_columns"]
        ],
        "figsize (dadk.optimizer.optimizersettings.composelogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeLogSettings.figsize"]
        ],
        "filter_limit (dadk.optimizer.optimizersettings.samplingsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SamplingSettings.filter_limit"]
        ],
        "get_results() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.get_results"]
        ],
        "get_time() (dadk.optimizer.optimizermodelcomplex method)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.get_time"]
        ],
        "get_widget() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.get_widget"]
        ],
        "get_widget() (dadk.optimizer.optimizertab method)": [
            [5, "dadk.Optimizer.OptimizerTab.get_widget"]
        ],
        "graphs_figsize (dadk.optimizer.optimizersettings.annealinglogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings.graphs_figsize"]
        ],
        "gui_build() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.gui_build"]
        ],
        "gui_compose (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.gui_compose"]
        ],
        "gui_load (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.gui_load"]
        ],
        "gui_solve() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.gui_solve"]
        ],
        "load() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.load"]
        ],
        "load() (dadk.optimizer.optimizermodelcomplex method)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.load"]
        ],
        "log() (dadk.optimizer.optimizermodelcomplex method)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.log"]
        ],
        "log_data() (dadk.optimizer.optimizermodelcomplex method)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.log_data"]
        ],
        "log_memory_size (dadk.optimizer.optimizersettings.composesettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeSettings.log_memory_size"]
        ],
        "optuna (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.optuna"]
        ],
        "optuna() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.optuna"]
        ],
        "optuna_dirname (dadk.optimizer.optimizermodelcomplex property)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.optuna_dirname"]
        ],
        "parameter_logging (dadk.optimizer.optimizersettings.batchsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.BatchSettings.parameter_logging"]
        ],
        "pareto (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.pareto"]
        ],
        "pareto() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.pareto"]
        ],
        "pareto_dirname (dadk.optimizer.optimizermodelcomplex property)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.pareto_dirname"]
        ],
        "prep_result() (dadk.optimizer.optimizermodelcomplex method)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.prep_result"]
        ],
        "run() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.run"]
        ],
        "sample_size (dadk.optimizer.optimizersettings.samplingsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SamplingSettings.sample_size"]
        ],
        "sampling (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.sampling"]
        ],
        "save_graphs (dadk.optimizer.optimizersettings.annealinglogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings.save_graphs"]
        ],
        "save_graphs (dadk.optimizer.optimizersettings.composelogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeLogSettings.save_graphs"]
        ],
        "save_graphs_figsize (dadk.optimizer.optimizersettings.annealinglogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings.save_graphs_figsize"]
        ],
        "save_graphs_figsize (dadk.optimizer.optimizersettings.composelogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeLogSettings.save_graphs_figsize"]
        ],
        "save_times (dadk.optimizer.optimizersettings.annealinglogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings.save_times"]
        ],
        "save_times_figsize (dadk.optimizer.optimizersettings.annealinglogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings.save_times_figsize"]
        ],
        "select_instance() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.select_instance"]
        ],
        "set_build_qubo_details_reference() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.set_build_qubo_details_reference"]
        ],
        "set_calculated_build_qubo_parameter() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.set_calculated_build_qubo_parameter"]
        ],
        "set_calculated_solver_parameter() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.set_calculated_solver_parameter"]
        ],
        "set_compose_model_details_reference() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.set_compose_model_details_reference"]
        ],
        "set_disabled() (dadk.optimizer.optimizertab method)": [
            [5, "dadk.Optimizer.OptimizerTab.set_disabled"]
        ],
        "set_fixed_solver_parameter() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.set_fixed_solver_parameter"]
        ],
        "set_load_details_reference() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.set_load_details_reference"]
        ],
        "set_prep_result_details_reference() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.set_prep_result_details_reference"]
        ],
        "set_solver_parameter() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.set_solver_parameter"]
        ],
        "show_summary (dadk.optimizer.optimizersettings.composesettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeSettings.show_summary"]
        ],
        "solve_dav2 (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.solve_dav2"]
        ],
        "solve_dav3 (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.solve_dav3"]
        ],
        "solve_dav3c (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.solve_dav3c"]
        ],
        "solve_dav4 (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.solve_dav4"]
        ],
        "solve_gui (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.solve_gui"]
        ],
        "store_graphics (dadk.optimizer.optimizersettings.solvedav2settings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv2Settings.store_graphics"]
        ],
        "summary_columns (dadk.optimizer.optimizersettings.composesettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeSettings.summary_columns"]
        ],
        "tab_build (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.tab_build"]
        ],
        "tab_compose (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.tab_compose"]
        ],
        "tab_load (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.tab_load"]
        ],
        "tab_optuna (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.tab_optuna"]
        ],
        "tab_pareto (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.tab_pareto"]
        ],
        "tab_report() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.tab_report"]
        ],
        "tab_solve (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.tab_solve"]
        ],
        "tab_timeseries (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.tab_timeseries"]
        ],
        "tab_visualization (dadk.optimizer.optimizer property)": [
            [5, "dadk.Optimizer.Optimizer.tab_visualization"]
        ],
        "times_figsize (dadk.optimizer.optimizersettings.annealinglogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings.times_figsize"]
        ],
        "timeseries (dadk.optimizer.optimizersettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.timeseries"]
        ],
        "timeseries() (dadk.optimizer.optimizer method)": [
            [5, "dadk.Optimizer.Optimizer.timeseries"]
        ],
        "timeseries_dirname (dadk.optimizer.optimizermodelcomplex property)": [
            [5, "dadk.Optimizer.OptimizerModelComplex.timeseries_dirname"]
        ],
        "unique_sample_limit (dadk.optimizer.optimizersettings.samplingsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SamplingSettings.unique_sample_limit"]
        ],
        "use_compact (dadk.optimizer.optimizersettings.solvedav2settings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv2Settings.use_compact"]
        ],
        "use_compact (dadk.optimizer.optimizersettings.solvedav3settings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv3Settings.use_compact"]
        ],
        "use_compact (dadk.optimizer.optimizersettings.solvedav3csettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv3cSettings.use_compact"]
        ],
        "use_compact (dadk.optimizer.optimizersettings.solvedav4settings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv4Settings.use_compact"]
        ],
        "use_qubo_matrix (dadk.optimizer.optimizersettings.solvedav2settings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.SolveDAv2Settings.use_qubo_matrix"]
        ],
        "values_per_row (dadk.optimizer.optimizersettings.annealinglogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.AnnealingLogSettings.values_per_row"]
        ],
        "values_per_row (dadk.optimizer.optimizersettings.composelogsettings property)": [
            [5, "dadk.Optimizer.OptimizerSettings.ComposeLogSettings.values_per_row"]
        ],
        "bitarray (class in dadk.solution_solutionlist)": [
            [6, "dadk.Solution_SolutionList.BitArray"]
        ],
        "solution (class in dadk.solution_solutionlist)": [
            [6, "dadk.Solution_SolutionList.Solution"]
        ],
        "solutionlist (class in dadk.solution_solutionlist)": [
            [6, "dadk.Solution_SolutionList.SolutionList"]
        ],
        "varset (class in dadk.solution_solutionlist)": [
            [6, "dadk.Solution_SolutionList.VarSet"]
        ],
        "anneal_time (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.anneal_time"]
        ],
        "call_back (dadk.solution_solutionlist.bitarray property)": [
            [6, "dadk.Solution_SolutionList.BitArray.call_back"]
        ],
        "configuration (dadk.solution_solutionlist.solution property)": [
            [6, "dadk.Solution_SolutionList.Solution.configuration"]
        ],
        "connection_parameter (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.connection_parameter"]
        ],
        "da_parameter (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.da_parameter"]
        ],
        "display_graphs() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.display_graphs"]
        ],
        "draw() (dadk.solution_solutionlist.bitarray method)": [
            [6, "dadk.Solution_SolutionList.BitArray.draw"]
        ],
        "draw() (dadk.solution_solutionlist.solution method)": [
            [6, "dadk.Solution_SolutionList.Solution.draw"]
        ],
        "energy (dadk.solution_solutionlist.solution property)": [
            [6, "dadk.Solution_SolutionList.Solution.energy"]
        ],
        "evaluate() (dadk.solution_solutionlist.bitarray method)": [
            [6, "dadk.Solution_SolutionList.BitArray.evaluate"]
        ],
        "execution_time (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.execution_time"]
        ],
        "extract_bit_array() (dadk.solution_solutionlist.solution method)": [
            [6, "dadk.Solution_SolutionList.Solution.extract_bit_array"]
        ],
        "extract_bit_array() (dadk.solution_solutionlist.varset method)": [
            [6, "dadk.Solution_SolutionList.VarSet.extract_bit_array"]
        ],
        "get_minimum_energy_solution() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.get_minimum_energy_solution"]
        ],
        "get_solution_list() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.get_solution_list"]
        ],
        "get_sorted_solution_list() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.get_sorted_solution_list"]
        ],
        "get_time() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.get_time"]
        ],
        "get_times() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.get_times"]
        ],
        "inequalities (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.inequalities"]
        ],
        "min_solution (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.min_solution"]
        ],
        "name (dadk.solution_solutionlist.bitarray property)": [
            [6, "dadk.Solution_SolutionList.BitArray.name"]
        ],
        "penalty_energy (dadk.solution_solutionlist.solution property)": [
            [6, "dadk.Solution_SolutionList.Solution.penalty_energy"]
        ],
        "penalty_qubo (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.penalty_qubo"]
        ],
        "print_progress() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.print_progress"]
        ],
        "print_stats() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.print_stats"]
        ],
        "qubo (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.qubo"]
        ],
        "search_stats_info() (dadk.solution_solutionlist.solutionlist method)": [
            [6, "dadk.Solution_SolutionList.SolutionList.search_stats_info"]
        ],
        "shape (dadk.solution_solutionlist.bitarray property)": [
            [6, "dadk.Solution_SolutionList.BitArray.shape"]
        ],
        "solver_times (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.solver_times"]
        ],
        "start (dadk.solution_solutionlist.bitarray property)": [
            [6, "dadk.Solution_SolutionList.BitArray.start"]
        ],
        "step (dadk.solution_solutionlist.bitarray property)": [
            [6, "dadk.Solution_SolutionList.BitArray.step"]
        ],
        "stop (dadk.solution_solutionlist.bitarray property)": [
            [6, "dadk.Solution_SolutionList.BitArray.stop"]
        ],
        "tuning_parameter (dadk.solution_solutionlist.solutionlist property)": [
            [6, "dadk.Solution_SolutionList.SolutionList.tuning_parameter"]
        ],
        "var_shape_set (dadk.solution_solutionlist.solution property)": [
            [6, "dadk.Solution_SolutionList.Solution.var_shape_set"]
        ],
        "abstractjob (class in dadk.qubosolverbase.solverbase)": [
            [7, "dadk.QUBOSolverBase.SolverBase.AbstractJob"]
        ],
        "azureblobmixin (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin"]
        ],
        "blob (class in dadk.qubosolverbase.azureblobmixin)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.Blob"]
        ],
        "job (class in dadk.qubosolverbase.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job"]
        ],
        "jobstatus (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.JobStatus"]
        ],
        "jobv2 (class in dadk.qubosolverbase.qubosolverbasev2)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV2.JobV2"]
        ],
        "jobv3 (class in dadk.qubosolverbase.qubosolverbasev3)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.JobV3"]
        ],
        "jobv3c (class in dadk.qubosolverbase.qubosolverbasev3c)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3c.JobV3C"]
        ],
        "jobv4 (class in dadk.qubosolverbase.qubosolverbasev4)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV4.JobV4"]
        ],
        "progressbar (class in dadk.qubosolverbase.azureblobmixin)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.ProgressBar"]
        ],
        "qubosolverbase (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase"]
        ],
        "qubosolverbasev2 (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV2"]
        ],
        "qubosolverbasev3 (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3"]
        ],
        "qubosolverbasev3c (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3c"]
        ],
        "qubosolverbasev4 (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV4"]
        ],
        "qubosolvercpu (class in dadk.qubosolvercpu)": [
            [7, "dadk.QUBOSolverCPU.QUBOSolverCPU"]
        ],
        "qubosolverdav2 (class in dadk.qubosolverdav2)": [
            [7, "dadk.QUBOSolverDAv2.QUBOSolverDAv2"]
        ],
        "qubosolverdav3 (class in dadk.qubosolverdav3)": [
            [7, "dadk.QUBOSolverDAv3.QUBOSolverDAv3"]
        ],
        "qubosolverdav3c (class in dadk.qubosolverdav3c)": [
            [7, "dadk.QUBOSolverDAv3c.QUBOSolverDAv3c"]
        ],
        "qubosolverdav4 (class in dadk.qubosolverdav4)": [
            [7, "dadk.QUBOSolverDAv4.QUBOSolverDAv4"]
        ],
        "qubosolveremulator (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverEmulator"]
        ],
        "restmixin (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.RestMixin"]
        ],
        "solverbase (class in dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.SolverBase"]
        ],
        "blob_name (dadk.qubosolverbase.azureblobmixin.blob property)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.Blob.blob_name"]
        ],
        "bqp_filename (dadk.qubosolverbase.qubosolverbase property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.bqp_filename"]
        ],
        "bqp_filename (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.bqp_filename"]
        ],
        "cancel_job() (dadk.qubosolverbase.restmixin method)": [
            [7, "dadk.QUBOSolverBase.RestMixin.cancel_job"]
        ],
        "check_number_of_bits (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.check_number_of_bits"]
        ],
        "cleanup_jobs() (dadk.qubosolverbase.restmixin method)": [
            [7, "dadk.QUBOSolverBase.RestMixin.cleanup_jobs"]
        ],
        "close() (dadk.qubosolverbase.azureblobmixin.progressbar method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.ProgressBar.close"]
        ],
        "connection_parameter (dadk.qubosolverbase.solverbase property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.connection_parameter"]
        ],
        "container_name (dadk.qubosolverbase.azureblobmixin.blob property)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.Blob.container_name"]
        ],
        "create_container() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.create_container"]
        ],
        "create_sas_token() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.create_sas_token"]
        ],
        "create_solver() (in module dadk.solverfactory)": [
            [7, "dadk.SolverFactory.create_solver"]
        ],
        "da_parameter (dadk.qubosolverbase.qubosolverbasev2 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV2.da_parameter"]
        ],
        "da_parameter (dadk.qubosolverbase.qubosolverbasev2.jobv2 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV2.JobV2.da_parameter"]
        ],
        "da_parameter (dadk.qubosolverbase.qubosolverbasev3 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.da_parameter"]
        ],
        "da_parameter (dadk.qubosolverbase.qubosolverbasev3.jobv3 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.JobV3.da_parameter"]
        ],
        "da_parameter (dadk.qubosolverbase.qubosolverbasev3c property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3c.da_parameter"]
        ],
        "da_parameter (dadk.qubosolverbase.qubosolverbasev3c.jobv3c property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3c.JobV3C.da_parameter"]
        ],
        "da_parameter (dadk.qubosolverbase.qubosolverbasev4 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV4.da_parameter"]
        ],
        "da_parameter (dadk.qubosolverbase.qubosolverbasev4.jobv4 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV4.JobV4.da_parameter"]
        ],
        "delete_blob() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.delete_blob"]
        ],
        "delete_container() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.delete_container"]
        ],
        "delete_job() (dadk.qubosolverbase.restmixin method)": [
            [7, "dadk.QUBOSolverBase.RestMixin.delete_job"]
        ],
        "display_blobs() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.display_blobs"]
        ],
        "display_jobs() (dadk.qubosolverbase.restmixin method)": [
            [7, "dadk.QUBOSolverBase.RestMixin.display_jobs"]
        ],
        "download_blob() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.download_blob"]
        ],
        "download_job() (dadk.qubosolverbase.restmixin method)": [
            [7, "dadk.QUBOSolverBase.RestMixin.download_job"]
        ],
        "file_size_info() (in module dadk.qubosolverbase)": [
            [7, "dadk.QUBOSolverBase.file_size_info"]
        ],
        "fixed_config (dadk.qubosolverbase.qubosolverbasev3 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.fixed_config"]
        ],
        "fixed_config (dadk.qubosolverbase.qubosolverbasev3.jobv3 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.JobV3.fixed_config"]
        ],
        "fixed_config (dadk.qubosolverbase.qubosolverbasev3c property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3c.fixed_config"]
        ],
        "fixed_config (dadk.qubosolverbase.qubosolverbasev4 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV4.fixed_config"]
        ],
        "get_parameter_definitions() (dadk.qubosolvercpu.qubosolvercpu class method)": [
            [7, "dadk.QUBOSolverCPU.QUBOSolverCPU.get_parameter_definitions"]
        ],
        "get_parameter_definitions() (dadk.qubosolverdav2.qubosolverdav2 class method)": [
            [7, "dadk.QUBOSolverDAv2.QUBOSolverDAv2.get_parameter_definitions"]
        ],
        "get_parameter_definitions() (dadk.qubosolverdav3.qubosolverdav3 class method)": [
            [7, "dadk.QUBOSolverDAv3.QUBOSolverDAv3.get_parameter_definitions"]
        ],
        "get_parameter_definitions() (dadk.qubosolverdav3c.qubosolverdav3c class method)": [
            [7, "dadk.QUBOSolverDAv3c.QUBOSolverDAv3c.get_parameter_definitions"]
        ],
        "get_parameter_definitions() (dadk.qubosolverdav4.qubosolverdav4 class method)": [
            [7, "dadk.QUBOSolverDAv4.QUBOSolverDAv4.get_parameter_definitions"]
        ],
        "get_solver_ids() (in module dadk.solverfactory)": [
            [7, "dadk.SolverFactory.get_solver_IDs"]
        ],
        "guidance_config (dadk.qubosolverbase.qubosolverbase property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.guidance_config"]
        ],
        "guidance_config (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.guidance_config"]
        ],
        "has_solver() (in module dadk.solverfactory)": [
            [7, "dadk.SolverFactory.has_solver"]
        ],
        "healthcheck() (dadk.qubosolverbase.qubosolverbase method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.healthcheck"]
        ],
        "inequalities (dadk.qubosolverbase.qubosolverbasev3.jobv3 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.JobV3.inequalities"]
        ],
        "job_id (dadk.qubosolverbase.jobstatus property)": [
            [7, "dadk.QUBOSolverBase.JobStatus.job_id"]
        ],
        "last_modified (dadk.qubosolverbase.azureblobmixin.blob property)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.Blob.last_modified"]
        ],
        "list_blobs() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.list_blobs"]
        ],
        "list_containers() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.list_containers"]
        ],
        "list_jobs() (dadk.qubosolverbase.restmixin method)": [
            [7, "dadk.QUBOSolverBase.RestMixin.list_jobs"]
        ],
        "logger (dadk.qubosolverbase.solverbase property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.logger"]
        ],
        "logger (dadk.qubosolverbase.solverbase.abstractjob property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.AbstractJob.logger"]
        ],
        "max_job_list_retry (dadk.qubosolverbase.solverbase property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.max_job_list_retry"]
        ],
        "minimize() (dadk.qubosolverbase.qubosolverbasev2 method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV2.minimize"]
        ],
        "minimize() (dadk.qubosolverbase.qubosolverbasev3 method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.minimize"]
        ],
        "minimize() (dadk.qubosolverbase.qubosolverbasev3c method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3c.minimize"]
        ],
        "minimize() (dadk.qubosolverbase.qubosolverbasev4 method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV4.minimize"]
        ],
        "penalty_qubo (dadk.qubosolverbase.qubosolverbasev3.jobv3 property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.JobV3.penalty_qubo"]
        ],
        "qubo (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.qubo"]
        ],
        "random_seed (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.random_seed"]
        ],
        "random_seed (dadk.qubosolverbase.solverbase property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.random_seed"]
        ],
        "random_seed_increment (dadk.qubosolverbase.solverbase property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.random_seed_increment"]
        ],
        "register_solver() (in module dadk.solverfactory)": [
            [7, "dadk.SolverFactory.register_solver"]
        ],
        "report_holes (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.report_holes"]
        ],
        "request_size (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.request_size"]
        ],
        "response_size (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.response_size"]
        ],
        "sample() (dadk.qubosolverbase.qubosolverbasev2 method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV2.sample"]
        ],
        "sample() (dadk.qubosolverbase.qubosolverbasev3 method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3.sample"]
        ],
        "sample() (dadk.qubosolverbase.qubosolverbasev3c method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV3c.sample"]
        ],
        "sample() (dadk.qubosolverbase.qubosolverbasev4 method)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBaseV4.sample"]
        ],
        "set() (dadk.qubosolverbase.azureblobmixin.progressbar method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.ProgressBar.set"]
        ],
        "size (dadk.qubosolverbase.azureblobmixin.blob property)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.Blob.size"]
        ],
        "sleep_duration (dadk.qubosolverbase.solverbase property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.sleep_duration"]
        ],
        "sleep_function (dadk.qubosolverbase.solverbase property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.sleep_function"]
        ],
        "solver_max_bits (dadk.qubosolverbase.qubosolverbase property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.solver_max_bits"]
        ],
        "solver_max_bits (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.solver_max_bits"]
        ],
        "start_time (dadk.qubosolverbase.jobstatus property)": [
            [7, "dadk.QUBOSolverBase.JobStatus.start_time"]
        ],
        "stats_info (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.stats_info"]
        ],
        "status (dadk.qubosolverbase.jobstatus property)": [
            [7, "dadk.QUBOSolverBase.JobStatus.status"]
        ],
        "times (dadk.qubosolverbase.solverbase.abstractjob property)": [
            [7, "dadk.QUBOSolverBase.SolverBase.AbstractJob.times"]
        ],
        "timeseries_max_bits (dadk.qubosolverbase.qubosolverbase property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.timeseries_max_bits"]
        ],
        "timeseries_max_bits (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.timeseries_max_bits"]
        ],
        "tuning_parameter (dadk.qubosolverbase.qubosolverbase property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.tuning_parameter"]
        ],
        "tuning_parameter (dadk.qubosolverbase.qubosolverbase.job property)": [
            [7, "dadk.QUBOSolverBase.QUBOSolverBase.Job.tuning_parameter"]
        ],
        "upload_blob() (dadk.qubosolverbase.azureblobmixin method)": [
            [7, "dadk.QUBOSolverBase.AzureBlobMixin.upload_blob"]
        ],
        "coordinatesutils (class in dadk.utils.coordinatesutils)": [
            [8, "dadk.utils.CoordinatesUtils.CoordinatesUtils"]
        ],
        "daodecoder (class in dadk.jsontools)": [
            [8, "dadk.JSONTools.DaoDecoder"]
        ],
        "daoencoder (class in dadk.jsontools)": [
            [8, "dadk.JSONTools.DaoEncoder"]
        ],
        "directorymanager (class in dadk.internal.tools)": [
            [8, "dadk.internal.Tools.DirectoryManager"]
        ],
        "interruptkey (class in dadk.internal.tools)": [
            [8, "dadk.internal.Tools.InterruptKey"]
        ],
        "profileutils (class in dadk.profileutils)": [
            [8, "dadk.ProfileUtils.ProfileUtils"]
        ],
        "tsputils (class in dadk.utils.tsputils)": [
            [8, "dadk.utils.TSPUtils.TSPUtils"]
        ],
        "build_groups() (dadk.utils.coordinatesutils.coordinatesutils class method)": [
            [8, "dadk.utils.CoordinatesUtils.CoordinatesUtils.build_groups"]
        ],
        "copy_to() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.copy_to"]
        ],
        "count_files() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.count_files"]
        ],
        "create() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.create"]
        ],
        "create_qubos() (dadk.utils.tsputils.tsputils class method)": [
            [8, "dadk.utils.TSPUtils.TSPUtils.create_QUBOS"]
        ],
        "default() (dadk.jsontools.daoencoder method)": [
            [8, "dadk.JSONTools.DaoEncoder.default"]
        ],
        "delete_annealer_access_profile() (dadk.profileutils.profileutils class method)": [
            [8, "dadk.ProfileUtils.ProfileUtils.delete_annealer_access_profile"]
        ],
        "dump_json() (in module dadk.jsontools)": [
            [8, "dadk.JSONTools.dump_json"]
        ],
        "dumps_json() (in module dadk.jsontools)": [
            [8, "dadk.JSONTools.dumps_json"]
        ],
        "generate_coordinates() (dadk.utils.coordinatesutils.coordinatesutils class method)": [
            [8, "dadk.utils.CoordinatesUtils.CoordinatesUtils.generate_coordinates"]
        ],
        "get_annealer_access_profile() (dadk.profileutils.profileutils class method)": [
            [8, "dadk.ProfileUtils.ProfileUtils.get_annealer_access_profile"]
        ],
        "interrupt (dadk.internal.tools.interruptkey property)": [
            [8, "dadk.internal.Tools.InterruptKey.interrupt"]
        ],
        "list_annealer_access_profiles() (dadk.profileutils.profileutils class method)": [
            [8, "dadk.ProfileUtils.ProfileUtils.list_annealer_access_profiles"]
        ],
        "load_json() (in module dadk.jsontools)": [
            [8, "dadk.JSONTools.load_json"]
        ],
        "loads_json() (in module dadk.jsontools)": [
            [8, "dadk.JSONTools.loads_json"]
        ],
        "move_to() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.move_to"]
        ],
        "nearest_neighbour() (dadk.utils.tsputils.tsputils class method)": [
            [8, "dadk.utils.TSPUtils.TSPUtils.nearest_neighbour"]
        ],
        "object_hook() (dadk.jsontools.daodecoder class method)": [
            [8, "dadk.JSONTools.DaoDecoder.object_hook"]
        ],
        "path (dadk.internal.tools.directorymanager property)": [
            [8, "dadk.internal.Tools.DirectoryManager.path"]
        ],
        "plot_coordinates() (dadk.utils.coordinatesutils.coordinatesutils class method)": [
            [8, "dadk.utils.CoordinatesUtils.CoordinatesUtils.plot_coordinates"]
        ],
        "plot_coordinates_by_groups() (dadk.utils.coordinatesutils.coordinatesutils class method)": [
            [8, "dadk.utils.CoordinatesUtils.CoordinatesUtils.plot_coordinates_by_groups"]
        ],
        "plot_route() (dadk.utils.tsputils.tsputils class method)": [
            [8, "dadk.utils.TSPUtils.TSPUtils.plot_route"]
        ],
        "plot_routes_by_groups() (dadk.utils.tsputils.tsputils class method)": [
            [8, "dadk.utils.TSPUtils.TSPUtils.plot_routes_by_groups"]
        ],
        "read_json_file() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.read_json_file"]
        ],
        "read_text_file() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.read_text_file"]
        ],
        "register_decoder() (dadk.jsontools.daodecoder class method)": [
            [8, "dadk.JSONTools.DaoDecoder.register_decoder"]
        ],
        "register_encoder() (dadk.jsontools.daoencoder class method)": [
            [8, "dadk.JSONTools.DaoEncoder.register_encoder"]
        ],
        "register_function() (dadk.jsontools.daodecoder class method)": [
            [8, "dadk.JSONTools.DaoDecoder.register_function"]
        ],
        "register_function() (dadk.jsontools.daoencoder class method)": [
            [8, "dadk.JSONTools.DaoEncoder.register_function"]
        ],
        "remove() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.remove"]
        ],
        "remove_files() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.remove_files"]
        ],
        "stop() (dadk.internal.tools.interruptkey method)": [
            [8, "dadk.internal.Tools.InterruptKey.stop"]
        ],
        "store_annealer_access_profile() (dadk.profileutils.profileutils class method)": [
            [8, "dadk.ProfileUtils.ProfileUtils.store_annealer_access_profile"]
        ],
        "update_annealer_access_profiles() (dadk.profileutils.profileutils class method)": [
            [8, "dadk.ProfileUtils.ProfileUtils.update_annealer_access_profiles"]
        ],
        "write_json_file() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.write_json_file"]
        ],
        "write_text_file() (dadk.internal.tools.directorymanager method)": [
            [8, "dadk.internal.Tools.DirectoryManager.write_text_file"]
        ],
        "autotuning (class in dadk._constants)": [
            [9, "dadk._Constants.AutoTuning"]
        ],
        "connectionmethod (class in dadk._constants)": [
            [9, "dadk._Constants.ConnectionMethod"]
        ],
        "graphicsdetail (class in dadk._constants)": [
            [9, "dadk._Constants.GraphicsDetail"]
        ],
        "inequalitysign (class in dadk._constants)": [
            [9, "dadk._Constants.InequalitySign"]
        ],
        "makequboerror (class in dadk._constants)": [
            [9, "dadk._Constants.MakeQuboError"]
        ],
        "makequbonotusedbitwarning (class in dadk._constants)": [
            [9, "dadk._Constants.MakeQuboNotUsedBitWarning"]
        ],
        "makequboroundedtozerowarning (class in dadk._constants)": [
            [9, "dadk._Constants.MakeQuboRoundedToZeroWarning"]
        ],
        "makequbowarning (class in dadk._constants)": [
            [9, "dadk._Constants.MakeQuboWarning"]
        ],
        "onehot (class in dadk._constants)": [
            [9, "dadk._Constants.OneHot"]
        ],
        "parameterlogging (class in dadk._constants)": [
            [9, "dadk._Constants.ParameterLogging"]
        ],
        "qubosizeexceedssolvermaxbits (class in dadk._constants)": [
            [9, "dadk._Constants.QUBOSizeExceedsSolverMaxBits"]
        ],
        "qubosizeexceedstimeseriesmaxbits (class in dadk._constants)": [
            [9, "dadk._Constants.QUBOSizeExceedsTimeseriesMaxBits"]
        ],
        "requestmode (class in dadk._constants)": [
            [9, "dadk._Constants.RequestMode"]
        ],
        "slacktype (class in dadk._constants)": [
            [9, "dadk._Constants.SlackType"]
        ],
        "storageaccounttype (class in dadk._constants)": [
            [9, "dadk._Constants.StorageAccountType"]
        ],
        "activate_output() (in module dadk._constants)": [
            [9, "dadk._Constants.activate_output"]
        ],
        "bits (dadk._constants.qubosizeexceedssolvermaxbits property)": [
            [9, "dadk._Constants.QUBOSizeExceedsSolverMaxBits.bits"]
        ],
        "bits (dadk._constants.qubosizeexceedstimeseriesmaxbits property)": [
            [9, "dadk._Constants.QUBOSizeExceedsTimeseriesMaxBits.bits"]
        ],
        "coefficient (dadk._constants.makequboroundedtozerowarning property)": [
            [9, "dadk._Constants.MakeQuboRoundedToZeroWarning.coefficient"]
        ],
        "configuration_2_string() (in module dadk._constants)": [
            [9, "dadk._Constants.configuration_2_string"]
        ],
        "dadk_version_check() (in module dadk._constants)": [
            [9, "dadk._Constants.dadk_version_check"]
        ],
        "deactivate_output() (in module dadk._constants)": [
            [9, "dadk._Constants.deactivate_output"]
        ],
        "debug_exception() (in module dadk._constants)": [
            [9, "dadk._Constants.debug_exception"]
        ],
        "get_logger() (in module dadk._constants)": [
            [9, "dadk._Constants.get_logger"]
        ],
        "i18n_get() (in module dadk._constants)": [
            [9, "dadk._Constants.i18n_get"]
        ],
        "index (dadk._constants.makequbonotusedbitwarning property)": [
            [9, "dadk._Constants.MakeQuboNotUsedBitWarning.index"]
        ],
        "index (dadk._constants.makequboroundedtozerowarning property)": [
            [9, "dadk._Constants.MakeQuboRoundedToZeroWarning.index"]
        ],
        "index (dadk._constants.makequbowarning property)": [
            [9, "dadk._Constants.MakeQuboWarning.index"]
        ],
        "load_library() (in module dadk._constants)": [
            [9, "dadk._Constants.load_library"]
        ],
        "math_prod() (in module dadk._constants)": [
            [9, "dadk._Constants.math_prod"]
        ],
        "max_bits (dadk._constants.qubosizeexceedssolvermaxbits property)": [
            [9, "dadk._Constants.QUBOSizeExceedsSolverMaxBits.max_bits"]
        ],
        "max_bits (dadk._constants.qubosizeexceedstimeseriesmaxbits property)": [
            [9, "dadk._Constants.QUBOSizeExceedsTimeseriesMaxBits.max_bits"]
        ],
        "merge_dicts() (in module dadk._constants)": [
            [9, "dadk._Constants.merge_dicts"]
        ],
        "name (dadk._constants.qubosizeexceedssolvermaxbits property)": [
            [9, "dadk._Constants.QUBOSizeExceedsSolverMaxBits.name"]
        ],
        "name (dadk._constants.qubosizeexceedstimeseriesmaxbits property)": [
            [9, "dadk._Constants.QUBOSizeExceedsTimeseriesMaxBits.name"]
        ],
        "print_to_output() (in module dadk._constants)": [
            [9, "dadk._Constants.print_to_output"]
        ],
        "register_logging_output() (in module dadk._constants)": [
            [9, "dadk._Constants.register_logging_output"]
        ],
        "register_timeit_output() (in module dadk._constants)": [
            [9, "dadk._Constants.register_timeit_output"]
        ],
        "round_to_n() (in module dadk._constants)": [
            [9, "dadk._Constants.round_to_n"]
        ],
        "string_2_configuration() (in module dadk._constants)": [
            [9, "dadk._Constants.string_2_configuration"]
        ],
        "timeit() (in module dadk._constants)": [
            [9, "dadk._Constants.timeit"]
        ]
    }
})